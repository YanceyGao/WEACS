# cc2530 - net-tree

## CRC16

    如果不知道CRC是多少，可以在代码中，取消代码的注释(task void serial_rxdown())，使用串口打印CRC(注意大小端问题)

## 树形组网实验

    中心节点：0x0000
    其他节点：0x????（除0x0000）
    串口波特率：9600
    数据格式：55 AA 01 00 0B FF FF FF FF FF FF 12 34 5A C4 1E
    data[0]: 目标节点地址高8位(如：12)
    data[1]: 目标节点地址低8位(如：34)
    data[2]: 数据(count)(如：5A)
    最后两位为：CRC16(如：C4 1E)
    说明：中心节点作为控制节点，必须存在!
        其他节点建立好路由之后，定时向父节点发送消息，最后传到root节点并串口打印。
        串口输入控制root节点发送数据给网络中的其他节点，节点收到数据后会串口打印。

## 数据结构

```c
typedef nx_struct T_Msg{
  Comm_Msg_H msg_head;
  CUnit cunit;
} T_Msg;
typedef nx_struct Comm_Msg_H{
  nx_uint8_t tab0;
  nx_uint8_t tab1;
  
  nx_uint8_t id;
  nx_uint8_t seq;
  nx_uint8_t len;
}Comm_Msg_H;
typedef nx_struct CUnit{
  nx_uint16_t addr;
  nx_uint16_t fid;
  nx_uint8_t func;
  nx_uint8_t cmd;
  nx_uint8_t data[64];
}CUnit;
```
