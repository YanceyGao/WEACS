# cc2530 - net-p2p

## 两个节点之间互相通信（点对点通信）

    每隔TIMER_PERIOD_MILLI(2000)ms发送一次消息
    GROUP为：DEFINED_TOS_AM_GROUP=0x20
    信道为：DEFINED_TOS_AM_CHANNEL=20
    root节点号为：DEFINED_TOS_AM_ADDRESS=0x0000
    node节点号为：DEFINED_TOS_AM_ADDRESS=0x1234

## 消息

    接收到消息后，会使用串口打印出来
    串口波特率为：9600
    消息格式为：55 AA 03 F3 09 12 34 FF FF FF FF 34 45 BC
    最后两位为：CRC16

## 数据结构

```c
typedef nx_struct T_Msg {
  Comm_Msg_H msg_head;
  CUnit cunit;
} T_Msg;

typedef nx_struct Comm_Msg_H {
  nx_uint8_t tab0;
  nx_uint8_t tab1;

  nx_uint8_t id;
  nx_uint8_t seq;
  nx_uint8_t len;
} Comm_Msg_H;

typedef nx_struct CUnit {
  nx_uint16_t addr;
  nx_uint16_t fid;
  nx_uint8_t func;
  nx_uint8_t cmd;
  nx_uint8_t data[64];
} CUnit;
```
