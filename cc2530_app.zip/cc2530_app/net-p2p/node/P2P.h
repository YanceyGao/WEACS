#ifndef P2P_H
#define P2P_H


enum {
  AM_BLINKTORADIO = 0x64,
  TIMER_PERIOD_MILLI = 500
};

nx_struct BlinkToRadio{
  nx_uint8_t counter;
};

typedef nx_struct BlinkToRadio BlinkToRadioMsg;

#endif
