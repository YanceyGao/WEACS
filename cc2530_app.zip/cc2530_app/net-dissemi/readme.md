# cc2530 - net-Dissemination

## CRC16

    如果不知道CRC是多少，可以在代码中，取消代码的注释(task void serial_rxdown())，使用串口打印CRC(注意大小端问题)

## 分发协议

    root节点：0x0001
    node节点：0x????（不能为0x0001）
    串口波特率：9600
    数据格式：55 AA 01 00 0A FF FF FF FF FF FF AB CD B8 BF
    最后两位为：CRC16(如：B8 BF)
    说明：串口输入到root节点，root节点分发给其他节点，其他节点串口打印数据

## 数据结构

```c
typedef nx_struct T_Msg {
  Comm_Msg_H msg_head;
  CUnit cunit;
} T_Msg;

typedef nx_struct Comm_Msg_H {
  nx_uint8_t tab0;
  nx_uint8_t tab1;

  nx_uint8_t id;
  nx_uint8_t seq;
  nx_uint8_t len;
} Comm_Msg_H;

typedef nx_struct CUnit {
  nx_uint16_t addr;
  nx_uint16_t fid;
  nx_uint8_t func;
  nx_uint8_t cmd;
  nx_uint8_t data[64];
} CUnit;
```