# cc2530 - TestTimerSync

## 简单时间同步

    root节点：0x0000
    node节点：0x????（除0x0000）
    说明：root节点上电或复位后，广播消息，让node节点重新定时，
      这时候，root节点和node节点，LED0同时开始闪烁。
      一段时间后，各个节点的LED0闪烁不同步了，可以按下root的复位，重新进行时间同步。
