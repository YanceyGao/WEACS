# cc2530 - null

    这是TinyOS最小的代码，只包含了一个空任务