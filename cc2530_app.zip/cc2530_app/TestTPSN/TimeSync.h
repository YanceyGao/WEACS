#ifndef TIMESYNC_H
#define TIMESYNC_H

#define ROOT_ADDRESS    0x0000

#define DEBUG       1   // 是否启用调试模式，向串口输出数据
#define SYNC_INTV   250 // 同步操作间隔
#define DELAY_INTV  500 // 红灯延迟闪烁时间
#define AM_TIMESYNC 6

//同步请求数据包格式
nx_struct struct_syncReqMsg
{
  nx_uint32_t T1;
};
typedef nx_struct struct_syncReqMsg syncReqMsg;

//同步应答数据包格式
nx_struct struct_syncAckMsg
{
  nx_uint32_t T1;
  nx_uint32_t T2;
  nx_uint32_t T3;
};
typedef nx_struct struct_syncAckMsg syncAckMsg;

#if (DEBUG == 1)
extern int sprintf(char *, const char *, ...);
#endif

#endif
