# cc2530 - net-mesh

## CRC16

    如果不知道CRC是多少，可以在代码中，取消代码的注释(task void serial_rxdown())，使用串口打印CRC(注意大小端问题)

## 树形组网实验

    串口波特率：9600
    数据格式：55 AA 01 00 0B FF FF FF FF FF FF 12 34 5A C4 1E
    data[0]: 目标节点地址高8位(如：12)
    data[1]: 目标节点地址低8位(如：34)
    data[2]: 数据(count)(如：5A)
    最后两位为：CRC16(如：C4 1E)
    说明：节点使用的是AODV，一种按需路由。
      串口控制节点向另一个节点发送消息时，如果此节点没有目标节点的路由信息，则会广播请求路由，请求到了后再发送消息；
      后面发送消息给同一个目标节点时，就不用再请求路由信息，而是直接发送。

## 数据结构

```c
typedef nx_struct T_Msg{
  Comm_Msg_H msg_head;
  CUnit cunit;
} T_Msg;
typedef nx_struct Comm_Msg_H{
  nx_uint8_t tab0;
  nx_uint8_t tab1;
  
  nx_uint8_t id;
  nx_uint8_t seq;
  nx_uint8_t len;
}Comm_Msg_H;
typedef nx_struct CUnit{
  nx_uint16_t addr;
  nx_uint16_t fid;
  nx_uint8_t func;
  nx_uint8_t cmd;
  nx_uint8_t data[64];
}CUnit;
```
