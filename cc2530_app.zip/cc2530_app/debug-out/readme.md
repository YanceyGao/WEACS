# cc2530 - debug-out

    这个是测试cc2530的printf输出，每1000ms打印一次
    使用的是USART0，并且关闭了接收功能
    如果需要使用printf函数，添加宏定义
    CFLAGS += -DDEFINED_DEBUG
    CFLAGS += -DDEFINED_DEBUG_BAUD=115200
    对于波特率，可以选择：9600、19200、38400、57600、115200
    想要支持更多的波特率，可以修改 tos/platforms/cc2530zn/PlatformDebugP.nc 文件

## 特别提醒，如果使用printf函数，请不要去使用串口组件，可能会出现数据异常
