#ifndef P2P_H
#define P2P_H


enum {
  AM_BLINKTORADIO = 0x64,
  TIMER_PERIOD_MILLI = 2000
  
};

nx_struct BlinkToRadio{
  nx_uint16_t source_addr;
  nx_uint16_t dest_addr;
  nx_uint8_t counter;
};

typedef nx_struct BlinkToRadio BlinkToRadioMsg;

#endif
