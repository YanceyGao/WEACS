# cc2530 - sensor-relay

## CRC16

    如果不知道CRC是多少，可以在代码中，取消代码的注释(task void serial_rxdown())，使用串口打印CRC(注意大小端问题)

## 继电器

    RelayA：P1_3
    RelayB：P1_5
    波特率：9600
    命令格式：
      55 AA 01 00 09 FF FF 01 01 00 01 00 69 F3 // 关RelayA
      55 AA 01 00 09 FF FF 01 01 00 01 01 79 D2 // 开RelayB
      55 AA 01 00 09 FF FF 01 02 00 01 00 F2 2F // 关RelayA
      55 AA 01 00 09 FF FF 01 02 00 01 01 E2 0E // 开RelayB

```c
id = 0x01;
fid - H8 = 0x01
fid - L8 = 0x01 / 0x02
func = 0x00
cmd = 0x01
data[0] = 0x00 关
data[0] != 0x00 开
```

## 数据结构

```c
typedef nx_struct T_Msg{
  Comm_Msg_H msg_head;
  CUnit cunit;
} T_Msg;
typedef nx_struct Comm_Msg_H{
  nx_uint8_t tab0;
  nx_uint8_t tab1;
  
  nx_uint8_t id;
  nx_uint8_t seq;
  nx_uint8_t len;
}Comm_Msg_H;
typedef nx_struct CUnit{
  nx_uint16_t addr;
  nx_uint16_t fid;
  nx_uint8_t func;
  nx_uint8_t cmd;
  nx_uint8_t data[64];
}CUnit;
```
