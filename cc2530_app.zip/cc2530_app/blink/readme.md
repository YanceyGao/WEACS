# cc2530 - blink

    这是一个LED定时闪烁的程序
        LED0每500ms切换一下状态
        LED1每800ms切换一下状态
        LED2每1000ms切换一下状态