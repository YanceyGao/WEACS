# cc2530 - TestLpl

## 低功耗侦听

    波特率：9600

Mode 0:
0-32s: receive: fully on
       send: every second, to fully on listener

Mode 1:
32-64s: receive: fully on
        send: every second, to low-power-listeners with 100ms interval

Mode 2:
64-96s: receive: low-power-listening with 250ms interval
         send: every second, to low-power-listeners with 250ms interval
Mode 3:
96-128s: receive: low-power-listening with 250ms interval
         send: every second, to fully on listener
Mode 4:
128-160s: receive: low-power-listening with 10ms interval
          send: every second, to low-power-listeners with 10ms interval
Mode 5:
160-192s: receive: low-power-listening with 2000ms interval
          send: every 7 seconds, to low-power-listeners with 2000ms interval