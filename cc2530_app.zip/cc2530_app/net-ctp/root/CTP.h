#ifndef CTP_H
#define CTP_H


enum {
  AM_BLINKTORADIO = 0x64,
  TIMER_PERIOD_MILLI = 2000
  
};

 nx_struct BlinkToRadio{

  nx_uint8_t counter;

};

typedef nx_struct BlinkToRadio BlinkToRadioMsg;

#endif
