# cc2530 - TestTransmitPower

## 链路质量分析

    root节点：0x0000
    node节点：0x????（除0x0000）
    波特率：9600
    说明：通过RSSI值，分析链路质量
      root节，负责接收无线消息，并打印RSSI值
      node节点，变换发送功率，发送消息给root节点
      可以移动节点，设置障碍等，查看RSSI的变化