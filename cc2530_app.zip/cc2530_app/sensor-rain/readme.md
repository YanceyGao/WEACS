# cc2530 - sensor-rain

## 雨滴传感器

    IO：P0_0
    中断：上升沿
    波特率：9600

## 数据结构

```c
typedef nx_struct T_Msg{
  Comm_Msg_H msg_head;
  CUnit cunit;
} T_Msg;
typedef nx_struct Comm_Msg_H{
  nx_uint8_t tab0;
  nx_uint8_t tab1;
  
  nx_uint8_t id;
  nx_uint8_t seq;
  nx_uint8_t len;
}Comm_Msg_H;
typedef nx_struct CUnit{
  nx_uint16_t addr;
  nx_uint16_t fid;
  nx_uint8_t func;
  nx_uint8_t cmd;
  nx_uint8_t data[64];
}CUnit;
```
