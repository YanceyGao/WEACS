﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace PEACSWebService
{
    public class DBConnect
    {
        public SqlConnection OpenConnect()
        {
            //创建连接
            SqlConnectionStringBuilder SqlConStr = new SqlConnectionStringBuilder();
            SqlConStr.DataSource = "127.0.0.1";
            SqlConStr.UserID = "sa";
            SqlConStr.Password = "1021";
            SqlConStr.InitialCatalog = "PEACS.Sys";

            //判断连接是否打开
            SqlConnection Conn = new SqlConnection(SqlConStr.ToString());   //参数是连接数据库的字符串
            if (Conn.State == ConnectionState.Closed)
                Conn.Open();

            return Conn;
        }

        public SqlDataReader TransactSql(SqlConnection Conn, string strSql)
        {
            //执行T-SQL语句
            //DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象,改为方法调用，因此注释掉
            //SqlConnection Conn = this.OpenConnect();  //调用对象中的打开数据库的方法，改为方法调用，因此注释掉
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象
            SqlDataReader readerData = Comm.ExecuteReader(); //返回查询结果

            return readerData;
        }
    }
    public class DataChange
    {
        public DataTable DRToDT(SqlDataReader dataReader)
        {
            ///定义DataTable  
            DataTable datatable = new DataTable();

            try
            {    ///动态添加表的数据列  
                for (int i = 0; i < dataReader.FieldCount; i++)
                {
                    DataColumn myDataColumn = new DataColumn();
                    myDataColumn.DataType = dataReader.GetFieldType(i);
                    myDataColumn.ColumnName = dataReader.GetName(i);
                    datatable.Columns.Add(myDataColumn);
                }
                ///添加表的数据  
                while (dataReader.Read())
                {
                    DataRow myDataRow = datatable.NewRow();
                    for (int i = 0; i < dataReader.FieldCount; i++)
                    {
                        myDataRow[i] = dataReader[i].ToString();
                    }
                    datatable.Rows.Add(myDataRow);
                    myDataRow = null;
                }
                ///关闭数据读取器  
                dataReader.Close();
                return datatable;
            }
            catch (Exception ex)
            {
                ///抛出类型转换错误  
                //SystemError.CreateErrorLog(ex.Message);  
                throw new Exception(ex.Message, ex);
            }
        }
    }
    
}