﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace PEACSWebService
{
    /// <summary>
    /// ExperInfoWebService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class ExperInfoWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        /// <summary>
        /// 获取实验信息
        /// </summary>
        /// <param name="ExperNumber">班级</param>
        [WebMethod(Description = "获取实验信息")]
        public DataTable getExperInfo(string ExperNumber)
        {

            string strSQL = "select * from Experiment where Eno = '" + ExperNumber + "';";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                //数据转存
                DataTable dataTable = new DataTable();
                dataTable.Load(readerData);
                readerData.Close();
                Conn.Dispose();
                dataTable.TableName = "ExperInfo";
                return dataTable;
            }
            catch (Exception e)
            {
                readerData.Close();
                Conn.Dispose();
                return null;
            }
        }

        /// <summary>
        /// 添加实验
        /// </summary>
        /// <param name="ExperNumber">班级</param>
        [WebMethod(Description = "添加实验")]
        public String addExper(String Eno, String Ename, String Eidentify, String EansPass, String EansExecellence)
        {
            String strSql = "insert into Experiment values('" + Eno + "', '" + Ename + "', '" + Eidentify + "', " + EansPass + ", '" + EansExecellence + "', 0, null, null, null);";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
                                                        //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象

            try
            {
                int rowCount = Comm.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return "添加失败";
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }
        }

        /// <summary>
        /// 删除实验
        /// </summary>
        /// <param name="Eno">实验号</param>
        /// <param name="Ename">实验名</param>
        [WebMethod(Description = "删除实验")]
        public String deleteExper(String Eno, String Ename)
        {
            String strSql = "delete from Experiment where Eno = '" + Eno + "' and Ename = '" + Ename + "'";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
                                                        //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象

            GradeWebService gradeWebService = new GradeWebService();
            try
            {
                int rowCount = Comm.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    String dAns = gradeWebService.deleteGrade(Eno, 0);
                    if(dAns != null)
                    {
                        return dAns;
                    }
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return "删除失败，请检查信息是否匹配";
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }

        }

        /// <summary>
        /// 查找实验
        /// </summary>
        /// <param name="key">检索项</param>
        [WebMethod(Description = "查找实验")]
        public DataTable SelectExper(String val, int key)
        {
            String strSQL;
            //实验名查找
            if (key == 0)
            {
                strSQL = "select Eno '实验号', Ename '实验名', Eidentify '实验编码', Eans_pass '通过结果', Eans_execellence '优秀结果', EisFinish '是否完成', Epass '通过人数', Eexcellence '优秀人数', EnotPass '未通过人数' from Experiment where Ename = '" + val + "'";
            }
            else if(key == 1)       //实验号查找
            {
                strSQL = "select Eno '实验号', Ename '实验名', Eidentify '实验编码', Eans_pass '通过结果', Eans_execellence '优秀结果', EisFinish '是否完成', Epass '通过人数', Eexcellence '优秀人数', EnotPass '未通过人数' from Experiment where Eno = '" + val + "'";
            }
            else
                return null;

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                //数据转存
                DataTable dataTable = new DataTable();
                dataTable.Load(readerData);
                readerData.Close();
                Conn.Dispose();
                dataTable.TableName = "ExperInfo";
                return dataTable;
            }
            catch (Exception e)
            {
                readerData.Close();
                Conn.Dispose();
                return null;
            }
        }

        /// <summary>
        /// 修改实验
        /// </summary>
        /// <param name="Eno">实验号</param>
        /// <param name="Ename">实验名</param>
        /// <param name="Ecode">实验编码</param>
        /// <param name="Ecode">实验编码</param>
        [WebMethod(Description = "修改实验")]
        public String alterExper(int key, String Eid, String Eno, String Ename, String Ecode, String EansPass, String EansBetter)
        {
            String strSql;
            if (key == 0)
                strSql = "update Experiment set Eno = '" + Eno + "', Ename = '" + Ename + "', Eidentify = '" + Ecode + "', Eans_pass = '" + EansPass + "', Eans_execellence = '" + EansBetter + "' where Eno = '" + Eid + "'";
            else if (key == 1)
                strSql = "update Experiment set Eno = '" + Eno + "', Ename = '" + Ename + "', Eidentify = '" + Ecode + "', Eans_pass = '" + EansPass + "', Eans_execellence = '" + EansBetter + "' where Ename = '" + Eid + "'";
            else
                return "修改失败";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
                                                        //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象

            try
            {
                int rowCount = Comm.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return "修改失败，请检查输入是否正确";
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }

        }

        /// <summary>
        /// 完成实验
        /// </summary>
        /// <param name="Eno">实验号</param>
        [WebMethod(Description = "完成实验")]
        public String finishExper(String Eno)
        {
            String strSql = "update Experiment set EisFinish = 1 where Eno = '" + Eno + "'";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
                                                        //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象

            try
            {
                int rowCount = Comm.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return "完成失败，请寻找管理员查找问题！";
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }

        }
    }
}
