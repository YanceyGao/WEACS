﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
using Commons;
using PEACSWebService;

namespace PEACSWebService
{
    /// <summary>
    /// UserInfoWebService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class UserInfoWebService : System.Web.Services.WebService
    {

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="user_id">用户名</param>
        /// <param name="user_pwd">密码</param>
        /// <param name="ip_addr">IP地址</param>
        /// <param name="mac_addr">MAC地址</param>
        /// <param name="nowTime">时间</param>
        /// <returns></returns>
        [WebMethod(Description = "登录")]
        public string Login(string user_id, string user_pwd, string ip_addr, string mac_addr, string nowTime)
        {
            string userId;
            string userPwd;
            //密码解密
            userId = user_id;
            userPwd = EncodeHelper.AES_Encrypt(user_pwd);
            //拼接T-SQL语句
            string strSql = "SELECT * FROM UserInfo WHERE user_id = '" + userId + "' AND user_pwd = '" + userPwd + "';";
            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData =  DBConn.TransactSql(Conn, strSql);
            
            //SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象
            //SqlDataReader readerData = Comm.ExecuteReader(); //返回查询结果


            try
            {
                if (readerData.Read())
                {
                    if (readerData["ip_addr"].ToString() == "" || readerData["ip_addr"].ToString() == ip_addr)
                    {
                        if(readerData["mac_addr"].ToString() =="" || readerData["mac_addr"].ToString() == mac_addr)
                        {
                            String lastTime = readerData["last_time"].ToString();
                            readerData.Close();
                            //Conn.Close();
                            string dataInsert = "update UserInfo set last_ip = '" + ip_addr + "', last_time = '" + nowTime + "' where user_id = '" + user_id + "'";
                            SqlDataReader retRead =  DBConn.TransactSql(Conn, dataInsert);
                            try
                            {
                                    retRead.Close();
                                    Conn.Close();
                                    return lastTime;
                            }
                            catch(Exception ex)
                            {
                                retRead.Close();
                                Conn.Close();
                                return ex.Message;
                            }

                        }
                        else
                        {
                            readerData.Close();
                            Conn.Close();
                            return "抱歉，MAC地址受限，不允许在" + mac_addr + "下登录该账户";
                        }
                    }
                    else
                    {
                        readerData.Close();
                        Conn.Close();
                        return "抱歉，IP地址受限，不允许在" + ip_addr + "下登录该账户！";
                    }
                }
            }
            catch(Exception ex)
            {
                readerData.Close();
                Conn.Close();
                return ex.Message;
            }

            readerData.Close();
            Conn.Close();
            return "用户名或密码错误";
        }

        /// <summary>
        /// 用户注册
        /// </summary>
        /// <param name="user_id">用户名</param>
        /// <param name="user_pwd">密码</param>
        /// <param name="tip_pwd">密码提示</param>
        /// <param name="ip_addr">ip地址</param>
        /// <param name="mac_addr">mac地址</param>
        /// <returns>返回注册是否成功</returns>
        [WebMethod(Description = "注册")]
        public string Register(string user_id, string user_pwd, string tip_pwd, string ip_addr, string mac_addr)
        {

            //拼接T-SQL语句
            string strSQL = "insert into UserInfo values('" + user_id + "', '" + user_pwd + "', '" + tip_pwd + "', '" + ip_addr + "', '" + mac_addr + "', null, null);";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlCommand Comm = new SqlCommand(strSQL, Conn); //实例化SqlCommand对象
            int rowCount = 0;

            try
            {
                rowCount = Comm.ExecuteNonQuery();      //执行语句并返回行数
                if (rowCount > 0)
                {
                    Conn.Close();
                    return null;
                }
                else
                {
                    Conn.Close();
                    return "注册失败";
                }
            }
            catch (Exception ex)
            {
                Conn.Close();
                return ex.ToString();
            }
        }

        /// <summary>
        /// 找回密码
        /// </summary>
        /// <param name="userId">用户信息</param>
        [WebMethod(Description ="找回密码")]
        public string ForgetPwd(string userId)
        {
            //拼接T-SQL语句
            string strSQL = "SELECT tip_pwd FROM UserInfo WHERE user_id = '" + userId + "'";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                if (readerData.Read())
                {
                    return readerData["tip_pwd"].ToString();
                }
            }
            catch(Exception e)
            {
                return e.ToString();
            }

            return "-1";
        }

        /// <summary>
        /// 获取菜单数据
        /// </summary>
        /// <param name="key">菜单值</param>
        [WebMethod(Description = "获取菜单数据")]
        public DataTable getMenuData(int key)
        {
            string strSQL = null;

            if (key == 0)        //获取班级菜单数据
                strSQL = "select mu_id, mu_name, isnull(parent_id, '') as parent_id, tv_folder, tv_file from Stu_Menu order by order_no asc";
            else if(key == 1)   //获取实验菜单数据
                strSQL = "select mu_id, mu_name, isnull(parent_id, '') as parent_id, tv_folder, tv_file from Exper_Menu order by order_no asc";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                //数据转存
                //DataChange dataChange = new DataChange();
                //DataTable dataTable = dataChange.DRToDT(readerData);
                //dataTable.Load(readerData, LoadOption.OverwriteChanges);
                DataTable dataTable = new DataTable();
                dataTable.Load(readerData);
                readerData.Close();
                dataTable.TableName = "NodeTree";
                return dataTable;
            }
            catch(Exception e)
            {
                readerData.Close();
                return null;
            }

        }
    }
}
