﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace PEACSWebService
{
    /// <summary>
    /// StuInfoWebService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class StuInfoWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        /// <summary>
        /// 获取学生信息
        /// </summary>
        /// <param name="classNumber">班级</param>
        [WebMethod(Description = "获取学生信息")]
        public DataTable getStuInfo(string classNumber)
        {

            string strSQL = "select Sno '学号', sname '姓名', Sclass '班级', Sage '年龄', Ssex '性别', Sdept '专业', Scol '学院' from Student where Sclass = '" + classNumber + "'";
 
            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                //数据转存
                DataTable dataTable = new DataTable();
                dataTable.Load(readerData);
                readerData.Close();

                dataTable.TableName = "StuInfo";
                return dataTable;
            }
            catch (Exception e)
            {
                readerData.Close();
                return null;
            }
        }

        /// <summary>
        /// 添加班级
        /// </summary>
        /// <param name="className">班级</param>
        /// <param name="Monitor">班长</param>
        /// <param name="Learning">学习委员</param>
        [WebMethod(Description = "添加班级")]
        public String addClass(String classNo, String Monitor, String Learning)
        {
            String strSql = "insert into Class values('" + classNo + "', '" + classNo + "班', 0, '" + Monitor + "', '" + Learning + "');";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象
            int rowCount = 0;

            try
            {
                rowCount = Comm.ExecuteNonQuery();      //执行语句并返回行数
                if (rowCount > 0)
                {
                    Conn.Close();
                    return null;
                }
                else
                {
                    Conn.Close();
                    return "添加失败";
                }
            }
            catch (Exception ex)
            {
                Conn.Close();
                return ex.ToString();
            }

        }

        /// <summary>
        /// 删除班级
        /// </summary>
        /// <param name="className">班级</param>
        [WebMethod(Description = "删除班级")]
        public String deleteClass(String className)
        {
            DataSupport dataSupport = new DataSupport();

            int num = dataSupport.getClassNumber(className);

            if(num == 0)
            {
                String strSql = "delete from Class where Cclass = '" + className + "';";

                //执行T-SQL语句
                DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
                SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
              //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
                SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象

                try
                {
                    int rowCount = Comm.ExecuteNonQuery();
                    if (rowCount > 0)
                    {
                        Conn.Close();
                        return null;
                    }
                    else
                    {
                        Conn.Close();
                        return "删除失败或班级不存在";
                    }
                }
                catch (Exception ex)
                {
                    Conn.Close();
                    return ex.ToString();
                }
            }
            else
            {
                return "当前班级还有学生存在，无法删除班级";
            }

        }

        /// <summary>
        /// 添加学生
        /// </summary>
        /// <param name="Sno">学号</param>
        /// <param name="Sname">姓名</param>
        /// <param name="Sclass">班级</param>
        /// <param name="Sage">年龄</param>
        /// <param name="Ssex">性别</param>
        /// <param name="Sdept">专业</param>
        /// <param name="Scol">学院</param>
        [WebMethod(Description = "添加学生")]
        public String addStudent(String Sno, String Sname, String Sclass, int Sage, String Ssex, String Sdept, String Scol)
        {
            String strSql = "insert into Student values('" + Sno + "', '" + Sname + "', '" + Sclass + "', " + Sage + ", '" + Ssex + "', '" + Sdept + "', '" + Scol + "');";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
          //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象

            try
            {
                int rowCount = Comm.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return "添加失败";
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }

        }

        /// <summary>
        /// 删除学生
        /// </summary>
        /// <param name="Sno">学号</param>
        /// <param name="Sname">姓名</param>
        /// <param name="Sclass">班级</param>
        [WebMethod(Description = "删除学生")]
        public String deleteStudent(String Sno, String Sname, String Sclass)
        {
            String strSql = "delete from Student where Sno = '" + Sno + "' and Sname = '" + Sname + "' and Sclass = '" + Sclass + "'";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
                                                        //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象
            GradeWebService gradeWebService = new GradeWebService();
            try
            {
                int rowCount = Comm.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    String dAns = gradeWebService.deleteGrade(Sno, 1);
                    if (dAns != null)
                    {
                        return dAns;
                    }
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return "删除失败，请检查信息是否匹配";
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }


        }

        /// <summary>
        /// 查找学生
        /// </summary>
        /// <param name="key">检索项</param>
        [WebMethod(Description = "查找学生")]
        public DataTable SelectStudent(String key)
        {
            String strSQL;
            DataSupport dataSupport = new DataSupport();
            if (!dataSupport.isNumberic(key))
                strSQL = "select Sno '学号', sname '姓名', Sclass '班级', Sage '年龄', Ssex '性别', Sdept '专业', Scol '学院' from Student where Sname = '" + key + "'";
            else if(key.Length == 8)
                strSQL = "select Sno '学号', sname '姓名', Sclass '班级', Sage '年龄', Ssex '性别', Sdept '专业', Scol '学院' from Student where Sno = '" + key + "'";
            else if(key.Length == 6)
                strSQL = "select Sno '学号', sname '姓名', Sclass '班级', Sage '年龄', Ssex '性别', Sdept '专业', Scol '学院' from Student where Sclass = '" + key + "'";
            else
                return null;

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                //数据转存
                DataTable dataTable = new DataTable();
                dataTable.Load(readerData);
                readerData.Close();
                Conn.Dispose();
                dataTable.TableName = "StuInfo";
                return dataTable;
            }
            catch (Exception e)
            {
                Conn.Dispose();
                readerData.Close();
                return null;
            }
        }

    }
}
