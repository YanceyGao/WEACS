﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace PEACSWebService
{
    public class DataSupport
    {
        public int getClassNumber(String className)
        {
            string strSQL = "select Cnumber from class where Cclass = '" + className + "'";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            int num = 0;

            if(readerData.Read())
            {
                String str = readerData["Cnumber"].ToString();
                num = Convert.ToInt32(str);
            }

            return num;
        }

        public bool isNumberic(String value)
        {
            return Regex.IsMatch(value, @"^[-+]?\d+(\.\d+)?$");
        }

    }
}