﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace PEACSWebService
{
    /// <summary>
    /// GradeWebService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class GradeWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        /// <summary>
        /// 获取学生成绩信息
        /// </summary>
        /// <param name="classNumber">班级</param>
        [WebMethod(Description = "获取学生成绩信息")]
        public DataTable getGradeInfo(string classNumber)
        {

            string strSQL = "select Grade.Sno '学号', Sname '姓名', Eno '实验号', grade '成绩' from Grade, Student where Grade.Sno like '" + classNumber + "%' and Student.Sno = Grade.Sno;";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                //数据转存
                DataTable dataTable = new DataTable();
                dataTable.Load(readerData);
                readerData.Close();
                Conn.Dispose();
                dataTable.TableName = "GradeInfo";
                return dataTable;
            }
            catch (Exception e)
            {
                readerData.Close();
                Conn.Dispose();
                return null;
            }
        }

        /// <summary>
        /// 查找学生成绩
        /// </summary>
        /// <param name="key">检索项</param>
        [WebMethod(Description = "查找学生成绩")]
        public DataTable SelectGrade(String key)
        {
            String strSQL;
            DataSupport dataSupport = new DataSupport();
            if (!dataSupport.isNumberic(key))
                strSQL = "select Sno '学号', sname '姓名', Sclass '班级', Sage '年龄', Ssex '性别', Sdept '专业', Scol '学院' from Student where Sname = '" + key + "'";
            else if (key.Length == 8)
                strSQL = "select Sno '学号', sname '姓名', Sclass '班级', Sage '年龄', Ssex '性别', Sdept '专业', Scol '学院' from Student where Sno = '" + key + "'";
            else if (key.Length == 6)
                strSQL = "select Sno '学号', sname '姓名', Sclass '班级', Sage '年龄', Ssex '性别', Sdept '专业', Scol '学院' from Student where Sclass = '" + key + "'";
            else
                return null;

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            SqlDataReader readerData = DBConn.TransactSql(Conn, strSQL);

            try
            {
                //数据转存
                DataTable dataTable = new DataTable();
                dataTable.Load(readerData);
                readerData.Close();
                Conn.Dispose();
                dataTable.TableName = "GradeInfo";
                return dataTable;
            }
            catch (Exception e)
            {
                readerData.Close();
                Conn.Dispose();
                return null;
            }
        }

        /// <summary>
        /// 修改学生成绩
        /// </summary>
        /// <param name="Sno">学号</param>
        /// <param name="Eno">实验号</param>
        /// <param name="Egrade">成绩</param>
        [WebMethod(Description = "修改学生成绩")]
        public String alterGrade(String Sno, String Eno, int Egrade)
        {

            String strSql = "update Grade set grade = " + Egrade + "  where Sno = '" + Sno + "' and Eno = '" + Eno + "';";

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
            //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象
            int rowCount = 0;

            try
            {
                rowCount = Comm.ExecuteNonQuery();      //执行语句并返回行数
                if (rowCount > 0)
                {
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return "更新失败";
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }

        }

        /// <summary>
        /// 删除成绩信息
        /// </summary>
        /// <param name="Sno">学号</param>
        /// <param name="Eno">实验号</param>
        [WebMethod(Description = "删除成绩信息")]
        public String deleteGrade(String val, int key)
        {
            String strSql;
            //删除实验信息
            if (key == 0)
            {
                strSql = "delete from Grade where Eno = '" + val + "'";
            }
            else if (key == 1)   //删除学生信息
            {
                strSql = "delete from Grade where Sno = '" + val + "'";
            }
            else
            {
                return "删除失败";
            }
            

            //执行T-SQL语句
            DBConnect DBConn = new DBConnect(); //实例化连接数据库的类的对象
            SqlConnection Conn = DBConn.OpenConnect();  //调用对象中的打开数据库的方法
                                                        //SqlDataReader readerData = DBConn.TransactSql(Conn, strSql);
            SqlCommand Comm = new SqlCommand(strSql, Conn); //实例化SqlCommand对象

            try
            {
                int rowCount = Comm.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    Conn.Dispose();
                    return null;
                }
                else
                {
                    Conn.Dispose();
                    return null;
                }
            }
            catch (Exception ex)
            {
                Conn.Dispose();
                return ex.ToString();
            }

        }

    }
}
