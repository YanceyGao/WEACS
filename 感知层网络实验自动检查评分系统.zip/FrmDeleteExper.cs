﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using 感知层网络实验自动检查评分系统.ExperInfoWebService;
using WeifenLuo.WinFormsUI.Docking;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmDeleteExper : DockContent
    {
        public FrmDeleteExper()
        {
            InitializeComponent();
        }

        private void kryptonButtonDeleteExper_Click(object sender, EventArgs e)
        {
            String Eno = kryptonTextBoxEno.Text.ToString();
            String Ename = kryptonTextBoxEname.Text.ToString();

            ExperInfoWebServiceSoapClient experInfoWebServiceSoapClient = new ExperInfoWebServiceSoapClient();
            String ans = experInfoWebServiceSoapClient.deleteExper(Eno, Ename);

            if(ans == null)
            {
                kryptonLabelAns.Text = "删除成功";
            }
            else
            {
                kryptonLabelAns.Text = ans;
            }
        }
    }
}