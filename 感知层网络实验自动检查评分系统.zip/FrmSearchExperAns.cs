﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmSearchExperAns : DockContent
    {
        //选择操作
        public static int key = -1;

        public static DataTable val;

        Thread invokeThread = null;
        public FrmSearchExperAns()
        {
            InitializeComponent();
        }

        private void FrmSearchExperAns_Load(object sender, EventArgs e)
        {
            StuInfoWebService.StuInfoWebServiceSoapClient stuInfoWebServiceSoapClient = new StuInfoWebService.StuInfoWebServiceSoapClient();

            this.Text = "查询结果";
            ShowDataInListView(listView, val);

            //ChangeSelected();
            CheckForIllegalCrossThreadCalls = false;
            invokeThread = new Thread(new ThreadStart(ChangeSelected));
            invokeThread.Start();
        }

        //表格显式
        public void ShowDataInListView(ListView lv, DataTable dt)
        {
            lv.Clear();
            lv.AllowColumnReorder = true;   //用户可以调整列的位置
            lv.GridLines = true;            //显示行与行之间的分隔线   
            lv.FullRowSelect = true;        //要选择就是一行   
            lv.View = View.Details;         //定义列表显示的方式  
            lv.Scrollable = true;           //需要时候显示滚动条  
            lv.MultiSelect = false;         // 不可以多行选择   
            lv.HeaderStyle = ColumnHeaderStyle.Clickable;
            lv.View = View.Details;
            int RowCount, ColumnCount;
            DataRow dr = null;
            if (dt == null) return;
            RowCount = dt.Rows.Count;
            ColumnCount = dt.Columns.Count;
            //添加列标题名
            for (int i = 0; i < ColumnCount; i++)
            {
                lv.Columns.Add(dt.Columns[i].Caption.Trim(), lv.Width / ColumnCount);
            }
            if (RowCount == 0) return;
            for (int i = 0; i < RowCount; i++)
            {
                dr = dt.Rows[i];
                lv.Items.Add(dr[0].ToString());
                for (int j = 1; j < ColumnCount; j++)
                {
                    lv.Items[i].SubItems.Add(dr[j].ToString());
                }
            }

        }

        private void ChangeSelected()
        {
            while (true)
            {
                if (key == -1)
                    continue;

                int selectedRow;
                switch (key)
                {
                    case 1:
                        if (listView.Items.Count > 0)
                            listView.Items[0].Selected = true;
                        break;
                    case 2:
                        if (listView.SelectedItems.Count > 0)
                        {
                            selectedRow = listView.SelectedItems[0].Index;
                            if (selectedRow > 0)
                            {
                                listView.Items[selectedRow - 1].Selected = true;
                            }
                        }

                        break;
                    case 3:
                        if (listView.SelectedItems.Count > 0)
                        {
                            selectedRow = listView.SelectedItems[0].Index;
                            if (listView.Items.Count > selectedRow + 1)
                            {
                                listView.Items[selectedRow + 1].Selected = true;
                            }
                        }

                        break;
                    case 4:
                        if (listView.Items.Count > 0)
                            listView.Items[listView.Items.Count - 1].Selected = true;
                        break;
                }

                key = -1;
            }

        }

        private void FrmStuInfo_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (invokeThread.IsAlive)
            {
                invokeThread.Abort();
            }
            CheckForIllegalCrossThreadCalls = true;
        }
    }
}