﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmExperiment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExperiment));
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.toolStripContainer = new System.Windows.Forms.ToolStripContainer();
            this.kryptonHeaderGroup2 = new ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup();
            this.buttonSpecHeaderGroupMaxScreen = new ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup();
            this.listView = new System.Windows.Forms.ListView();
            this.labelShow = new System.Windows.Forms.Label();
            this.kryptonHeaderGroup3 = new ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup();
            this.buttonSpecHeaderGroup2 = new ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.kryptonComboBaud = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.kryptonLabelBaud = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonComboData = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.kryptonLabelData = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonComboCheck = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.kryptonLabelCheck = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonComboStop = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.kryptonLabelStop = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelPort = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonComboPort = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.kryptonButtonSelect = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonHeaderGroup1 = new ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup();
            this.buttonSpecHeaderGroup1 = new ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.kryptonLabelClass = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonComboBoxClass = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.kryptonTextBoxName = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelName = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonButtonStart = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButtonEnd = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonLabelCode = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelPassAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxCode = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxPassAns = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxBetterAns = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelBetterAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.toolStripContainer.ContentPanel.SuspendLayout();
            this.toolStripContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup2.Panel)).BeginInit();
            this.kryptonHeaderGroup2.Panel.SuspendLayout();
            this.kryptonHeaderGroup2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup3.Panel)).BeginInit();
            this.kryptonHeaderGroup3.Panel.SuspendLayout();
            this.kryptonHeaderGroup3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboBaud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboCheck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboPort)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1.Panel)).BeginInit();
            this.kryptonHeaderGroup1.Panel.SuspendLayout();
            this.kryptonHeaderGroup1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboBoxClass)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.toolStripContainer);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(1012, 478);
            this.kryptonPanel.TabIndex = 0;
            // 
            // toolStripContainer
            // 
            // 
            // toolStripContainer.ContentPanel
            // 
            this.toolStripContainer.ContentPanel.Controls.Add(this.kryptonHeaderGroup2);
            this.toolStripContainer.ContentPanel.Controls.Add(this.kryptonHeaderGroup3);
            this.toolStripContainer.ContentPanel.Controls.Add(this.kryptonHeaderGroup1);
            this.toolStripContainer.ContentPanel.Size = new System.Drawing.Size(1012, 453);
            this.toolStripContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer.LeftToolStripPanelVisible = false;
            this.toolStripContainer.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer.Name = "toolStripContainer";
            this.toolStripContainer.RightToolStripPanelVisible = false;
            this.toolStripContainer.Size = new System.Drawing.Size(1012, 478);
            this.toolStripContainer.TabIndex = 0;
            this.toolStripContainer.Text = "toolStripContainer1";
            // 
            // kryptonHeaderGroup2
            // 
            this.kryptonHeaderGroup2.AutoSize = true;
            this.kryptonHeaderGroup2.ButtonSpecs.AddRange(new ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup[] {
            this.buttonSpecHeaderGroupMaxScreen});
            this.kryptonHeaderGroup2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonHeaderGroup2.GroupBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ButtonStandalone;
            this.kryptonHeaderGroup2.GroupBorderStyle = ComponentFactory.Krypton.Toolkit.PaletteBorderStyle.ButtonStandalone;
            this.kryptonHeaderGroup2.HeaderStylePrimary = ComponentFactory.Krypton.Toolkit.HeaderStyle.Calendar;
            this.kryptonHeaderGroup2.HeaderVisibleSecondary = false;
            this.kryptonHeaderGroup2.Location = new System.Drawing.Point(0, 145);
            this.kryptonHeaderGroup2.Name = "kryptonHeaderGroup2";
            // 
            // kryptonHeaderGroup2.Panel
            // 
            this.kryptonHeaderGroup2.Panel.Controls.Add(this.listView);
            this.kryptonHeaderGroup2.Panel.Controls.Add(this.labelShow);
            this.kryptonHeaderGroup2.Size = new System.Drawing.Size(1012, 218);
            this.kryptonHeaderGroup2.TabIndex = 7;
            this.kryptonHeaderGroup2.ValuesPrimary.Heading = "实验";
            this.kryptonHeaderGroup2.ValuesPrimary.Image = ((System.Drawing.Image)(resources.GetObject("kryptonHeaderGroup2.ValuesPrimary.Image")));
            // 
            // buttonSpecHeaderGroupMaxScreen
            // 
            this.buttonSpecHeaderGroupMaxScreen.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.WorkspaceMaximize;
            this.buttonSpecHeaderGroupMaxScreen.UniqueName = "709B0A9CF27B40966E8264889A358A25";
            this.buttonSpecHeaderGroupMaxScreen.Click += new System.EventHandler(this.buttonSpecHeaderGroupMaxScreen_Click);
            // 
            // listView
            // 
            this.listView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView.HideSelection = false;
            this.listView.Location = new System.Drawing.Point(0, 73);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(1008, 115);
            this.listView.TabIndex = 1;
            this.listView.UseCompatibleStateImageBehavior = false;
            // 
            // labelShow
            // 
            this.labelShow.BackColor = System.Drawing.Color.Transparent;
            this.labelShow.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelShow.Font = new System.Drawing.Font("幼圆", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelShow.Location = new System.Drawing.Point(0, 0);
            this.labelShow.Name = "labelShow";
            this.labelShow.Size = new System.Drawing.Size(1008, 73);
            this.labelShow.TabIndex = 0;
            this.labelShow.Text = "----------------";
            // 
            // kryptonHeaderGroup3
            // 
            this.kryptonHeaderGroup3.AutoSize = true;
            this.kryptonHeaderGroup3.ButtonSpecs.AddRange(new ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup[] {
            this.buttonSpecHeaderGroup2});
            this.kryptonHeaderGroup3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kryptonHeaderGroup3.GroupBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ButtonStandalone;
            this.kryptonHeaderGroup3.GroupBorderStyle = ComponentFactory.Krypton.Toolkit.PaletteBorderStyle.ButtonStandalone;
            this.kryptonHeaderGroup3.HeaderStylePrimary = ComponentFactory.Krypton.Toolkit.HeaderStyle.Calendar;
            this.kryptonHeaderGroup3.HeaderVisibleSecondary = false;
            this.kryptonHeaderGroup3.Location = new System.Drawing.Point(0, 363);
            this.kryptonHeaderGroup3.Name = "kryptonHeaderGroup3";
            // 
            // kryptonHeaderGroup3.Panel
            // 
            this.kryptonHeaderGroup3.Panel.Controls.Add(this.tableLayoutPanel2);
            this.kryptonHeaderGroup3.Size = new System.Drawing.Size(1012, 90);
            this.kryptonHeaderGroup3.TabIndex = 6;
            this.kryptonHeaderGroup3.ValuesPrimary.Heading = "实验";
            this.kryptonHeaderGroup3.ValuesPrimary.Image = ((System.Drawing.Image)(resources.GetObject("kryptonHeaderGroup3.ValuesPrimary.Image")));
            // 
            // buttonSpecHeaderGroup2
            // 
            this.buttonSpecHeaderGroup2.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowDown;
            this.buttonSpecHeaderGroup2.UniqueName = "709B0A9CF27B40966E8264889A358A25";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoScroll = true;
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.ColumnCount = 7;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.kryptonComboBaud, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.kryptonLabelBaud, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.kryptonComboData, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.kryptonLabelData, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.kryptonComboCheck, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.kryptonLabelCheck, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.kryptonComboStop, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.kryptonLabelStop, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.kryptonLabelPort, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.kryptonComboPort, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.kryptonButtonSelect, 6, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, -2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1008, 62);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // kryptonComboBaud
            // 
            this.kryptonComboBaud.DropDownWidth = 121;
            this.kryptonComboBaud.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600",
            "115200"});
            this.kryptonComboBaud.Location = new System.Drawing.Point(200, 3);
            this.kryptonComboBaud.Name = "kryptonComboBaud";
            this.kryptonComboBaud.Size = new System.Drawing.Size(181, 25);
            this.kryptonComboBaud.TabIndex = 7;
            // 
            // kryptonLabelBaud
            // 
            this.kryptonLabelBaud.Location = new System.Drawing.Point(200, 33);
            this.kryptonLabelBaud.Name = "kryptonLabelBaud";
            this.kryptonLabelBaud.Size = new System.Drawing.Size(60, 24);
            this.kryptonLabelBaud.TabIndex = 1;
            this.kryptonLabelBaud.Values.Text = "波特率";
            // 
            // kryptonComboData
            // 
            this.kryptonComboData.DropDownWidth = 121;
            this.kryptonComboData.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.kryptonComboData.Location = new System.Drawing.Point(387, 3);
            this.kryptonComboData.Name = "kryptonComboData";
            this.kryptonComboData.Size = new System.Drawing.Size(181, 25);
            this.kryptonComboData.TabIndex = 6;
            // 
            // kryptonLabelData
            // 
            this.kryptonLabelData.Location = new System.Drawing.Point(387, 33);
            this.kryptonLabelData.Name = "kryptonLabelData";
            this.kryptonLabelData.Size = new System.Drawing.Size(60, 24);
            this.kryptonLabelData.TabIndex = 2;
            this.kryptonLabelData.Values.Text = "数据位";
            // 
            // kryptonComboCheck
            // 
            this.kryptonComboCheck.DropDownWidth = 121;
            this.kryptonComboCheck.Items.AddRange(new object[] {
            "None",
            "奇 校验",
            "偶 校验",
            "0  校验",
            "1  校验"});
            this.kryptonComboCheck.Location = new System.Drawing.Point(574, 3);
            this.kryptonComboCheck.Name = "kryptonComboCheck";
            this.kryptonComboCheck.Size = new System.Drawing.Size(181, 25);
            this.kryptonComboCheck.TabIndex = 8;
            // 
            // kryptonLabelCheck
            // 
            this.kryptonLabelCheck.Location = new System.Drawing.Point(574, 33);
            this.kryptonLabelCheck.Name = "kryptonLabelCheck";
            this.kryptonLabelCheck.Size = new System.Drawing.Size(60, 24);
            this.kryptonLabelCheck.TabIndex = 3;
            this.kryptonLabelCheck.Values.Text = "校验位";
            // 
            // kryptonComboStop
            // 
            this.kryptonComboStop.DropDownWidth = 121;
            this.kryptonComboStop.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.kryptonComboStop.Location = new System.Drawing.Point(13, 3);
            this.kryptonComboStop.Name = "kryptonComboStop";
            this.kryptonComboStop.Size = new System.Drawing.Size(181, 25);
            this.kryptonComboStop.TabIndex = 9;
            // 
            // kryptonLabelStop
            // 
            this.kryptonLabelStop.Location = new System.Drawing.Point(13, 33);
            this.kryptonLabelStop.Name = "kryptonLabelStop";
            this.kryptonLabelStop.Size = new System.Drawing.Size(60, 24);
            this.kryptonLabelStop.TabIndex = 4;
            this.kryptonLabelStop.Values.Text = "停止位";
            // 
            // kryptonLabelPort
            // 
            this.kryptonLabelPort.Location = new System.Drawing.Point(761, 33);
            this.kryptonLabelPort.Name = "kryptonLabelPort";
            this.kryptonLabelPort.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelPort.TabIndex = 0;
            this.kryptonLabelPort.Values.Text = "串口";
            // 
            // kryptonComboPort
            // 
            this.kryptonComboPort.DropDownWidth = 121;
            this.kryptonComboPort.Location = new System.Drawing.Point(761, 3);
            this.kryptonComboPort.Name = "kryptonComboPort";
            this.kryptonComboPort.Size = new System.Drawing.Size(181, 25);
            this.kryptonComboPort.TabIndex = 5;
            // 
            // kryptonButtonSelect
            // 
            this.kryptonButtonSelect.Location = new System.Drawing.Point(948, 3);
            this.kryptonButtonSelect.Name = "kryptonButtonSelect";
            this.tableLayoutPanel2.SetRowSpan(this.kryptonButtonSelect, 2);
            this.kryptonButtonSelect.Size = new System.Drawing.Size(57, 56);
            this.kryptonButtonSelect.TabIndex = 10;
            this.kryptonButtonSelect.Values.Text = "查找";
            this.kryptonButtonSelect.Click += new System.EventHandler(this.kryptonButtonSelect_Click);
            // 
            // kryptonHeaderGroup1
            // 
            this.kryptonHeaderGroup1.AutoSize = true;
            this.kryptonHeaderGroup1.ButtonSpecs.AddRange(new ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup[] {
            this.buttonSpecHeaderGroup1});
            this.kryptonHeaderGroup1.Dock = System.Windows.Forms.DockStyle.Top;
            this.kryptonHeaderGroup1.GroupBackStyle = ComponentFactory.Krypton.Toolkit.PaletteBackStyle.ButtonStandalone;
            this.kryptonHeaderGroup1.GroupBorderStyle = ComponentFactory.Krypton.Toolkit.PaletteBorderStyle.ButtonStandalone;
            this.kryptonHeaderGroup1.HeaderStylePrimary = ComponentFactory.Krypton.Toolkit.HeaderStyle.Calendar;
            this.kryptonHeaderGroup1.HeaderVisibleSecondary = false;
            this.kryptonHeaderGroup1.Location = new System.Drawing.Point(0, 0);
            this.kryptonHeaderGroup1.Name = "kryptonHeaderGroup1";
            // 
            // kryptonHeaderGroup1.Panel
            // 
            this.kryptonHeaderGroup1.Panel.Controls.Add(this.tableLayoutPanel1);
            this.kryptonHeaderGroup1.Size = new System.Drawing.Size(1012, 145);
            this.kryptonHeaderGroup1.TabIndex = 5;
            this.kryptonHeaderGroup1.ValuesPrimary.Heading = "实验信息";
            this.kryptonHeaderGroup1.ValuesPrimary.Image = ((System.Drawing.Image)(resources.GetObject("kryptonHeaderGroup1.ValuesPrimary.Image")));
            // 
            // buttonSpecHeaderGroup1
            // 
            this.buttonSpecHeaderGroup1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowUp;
            this.buttonSpecHeaderGroup1.UniqueName = "E09A349964B9473277B082CF17F56477";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.kryptonLabelClass, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.kryptonComboBoxClass, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.kryptonTextBoxName, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.kryptonLabelName, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.kryptonButtonStart, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.kryptonButtonEnd, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.kryptonLabelCode, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.kryptonLabelPassAns, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.kryptonTextBoxCode, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.kryptonTextBoxPassAns, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.kryptonTextBoxBetterAns, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.kryptonLabelBetterAns, 3, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1008, 117);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // kryptonLabelClass
            // 
            this.kryptonLabelClass.Dock = System.Windows.Forms.DockStyle.Right;
            this.kryptonLabelClass.Location = new System.Drawing.Point(119, 23);
            this.kryptonLabelClass.Name = "kryptonLabelClass";
            this.kryptonLabelClass.Size = new System.Drawing.Size(92, 24);
            this.kryptonLabelClass.TabIndex = 0;
            this.kryptonLabelClass.Values.Text = "实验班级：";
            // 
            // kryptonComboBoxClass
            // 
            this.kryptonComboBoxClass.DropDownWidth = 174;
            this.kryptonComboBoxClass.Location = new System.Drawing.Point(217, 23);
            this.kryptonComboBoxClass.Name = "kryptonComboBoxClass";
            this.kryptonComboBoxClass.Size = new System.Drawing.Size(174, 25);
            this.kryptonComboBoxClass.TabIndex = 2;
            // 
            // kryptonTextBoxName
            // 
            this.kryptonTextBoxName.Location = new System.Drawing.Point(217, 53);
            this.kryptonTextBoxName.Name = "kryptonTextBoxName";
            this.kryptonTextBoxName.Size = new System.Drawing.Size(174, 27);
            this.kryptonTextBoxName.TabIndex = 1;
            // 
            // kryptonLabelName
            // 
            this.kryptonLabelName.Dock = System.Windows.Forms.DockStyle.Right;
            this.kryptonLabelName.Location = new System.Drawing.Point(119, 53);
            this.kryptonLabelName.Name = "kryptonLabelName";
            this.kryptonLabelName.Size = new System.Drawing.Size(92, 24);
            this.kryptonLabelName.TabIndex = 3;
            this.kryptonLabelName.Values.Text = "实验名称：";
            // 
            // kryptonButtonStart
            // 
            this.kryptonButtonStart.Location = new System.Drawing.Point(23, 83);
            this.kryptonButtonStart.Name = "kryptonButtonStart";
            this.kryptonButtonStart.Size = new System.Drawing.Size(188, 34);
            this.kryptonButtonStart.TabIndex = 4;
            this.kryptonButtonStart.Values.Text = "开始实验";
            this.kryptonButtonStart.Click += new System.EventHandler(this.kryptonButtonStart_Click);
            // 
            // kryptonButtonEnd
            // 
            this.kryptonButtonEnd.Location = new System.Drawing.Point(217, 83);
            this.kryptonButtonEnd.Name = "kryptonButtonEnd";
            this.kryptonButtonEnd.Size = new System.Drawing.Size(174, 34);
            this.kryptonButtonEnd.TabIndex = 5;
            this.kryptonButtonEnd.Values.Text = "结束实验";
            this.kryptonButtonEnd.Click += new System.EventHandler(this.kryptonButtonEnd_Click);
            // 
            // kryptonLabelCode
            // 
            this.kryptonLabelCode.Dock = System.Windows.Forms.DockStyle.Right;
            this.kryptonLabelCode.Location = new System.Drawing.Point(439, 23);
            this.kryptonLabelCode.Name = "kryptonLabelCode";
            this.kryptonLabelCode.Size = new System.Drawing.Size(92, 24);
            this.kryptonLabelCode.TabIndex = 6;
            this.kryptonLabelCode.Values.Text = "实验编码：";
            // 
            // kryptonLabelPassAns
            // 
            this.kryptonLabelPassAns.Dock = System.Windows.Forms.DockStyle.Right;
            this.kryptonLabelPassAns.Location = new System.Drawing.Point(397, 53);
            this.kryptonLabelPassAns.Name = "kryptonLabelPassAns";
            this.kryptonLabelPassAns.Size = new System.Drawing.Size(134, 24);
            this.kryptonLabelPassAns.TabIndex = 7;
            this.kryptonLabelPassAns.Values.Text = "实验结果(通过)：";
            // 
            // kryptonTextBoxCode
            // 
            this.kryptonTextBoxCode.Location = new System.Drawing.Point(537, 23);
            this.kryptonTextBoxCode.Name = "kryptonTextBoxCode";
            this.kryptonTextBoxCode.Size = new System.Drawing.Size(239, 27);
            this.kryptonTextBoxCode.TabIndex = 8;
            // 
            // kryptonTextBoxPassAns
            // 
            this.kryptonTextBoxPassAns.Location = new System.Drawing.Point(537, 53);
            this.kryptonTextBoxPassAns.Name = "kryptonTextBoxPassAns";
            this.kryptonTextBoxPassAns.Size = new System.Drawing.Size(239, 27);
            this.kryptonTextBoxPassAns.TabIndex = 9;
            // 
            // kryptonTextBoxBetterAns
            // 
            this.kryptonTextBoxBetterAns.Location = new System.Drawing.Point(537, 83);
            this.kryptonTextBoxBetterAns.Name = "kryptonTextBoxBetterAns";
            this.kryptonTextBoxBetterAns.Size = new System.Drawing.Size(239, 27);
            this.kryptonTextBoxBetterAns.TabIndex = 10;
            // 
            // kryptonLabelBetterAns
            // 
            this.kryptonLabelBetterAns.Dock = System.Windows.Forms.DockStyle.Right;
            this.kryptonLabelBetterAns.Location = new System.Drawing.Point(397, 83);
            this.kryptonLabelBetterAns.Name = "kryptonLabelBetterAns";
            this.kryptonLabelBetterAns.Size = new System.Drawing.Size(134, 34);
            this.kryptonLabelBetterAns.TabIndex = 11;
            this.kryptonLabelBetterAns.Values.Text = "实验结果(优秀)：";
            // 
            // serialPort
            // 
            this.serialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialPort_DataReceived);
            // 
            // FrmExperiment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1012, 478);
            this.Controls.Add(this.kryptonPanel);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmExperiment";
            this.Text = "FrmExperiment";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmExperiment_FormClosing);
            this.Load += new System.EventHandler(this.FrmExperiment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.toolStripContainer.ContentPanel.ResumeLayout(false);
            this.toolStripContainer.ContentPanel.PerformLayout();
            this.toolStripContainer.ResumeLayout(false);
            this.toolStripContainer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup2.Panel)).EndInit();
            this.kryptonHeaderGroup2.Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup2)).EndInit();
            this.kryptonHeaderGroup2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup3.Panel)).EndInit();
            this.kryptonHeaderGroup3.Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup3)).EndInit();
            this.kryptonHeaderGroup3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboBaud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboCheck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboPort)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1.Panel)).EndInit();
            this.kryptonHeaderGroup1.Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1)).EndInit();
            this.kryptonHeaderGroup1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboBoxClass)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private System.Windows.Forms.ToolStripContainer toolStripContainer;
        private ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup kryptonHeaderGroup3;
        private ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup buttonSpecHeaderGroup2;
        private ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup kryptonHeaderGroup1;
        private ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup buttonSpecHeaderGroup1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelClass;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox kryptonComboBoxClass;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxName;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelName;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonStart;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonEnd;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelCode;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelPassAns;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxCode;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxPassAns;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxBetterAns;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelBetterAns;
        private ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup kryptonHeaderGroup2;
        private ComponentFactory.Krypton.Toolkit.ButtonSpecHeaderGroup buttonSpecHeaderGroupMaxScreen;
        private System.Windows.Forms.Label labelShow;
        private System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox kryptonComboBaud;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelBaud;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox kryptonComboData;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelData;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox kryptonComboCheck;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelCheck;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox kryptonComboStop;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelStop;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelPort;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox kryptonComboPort;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonSelect;
        private System.Windows.Forms.ListView listView;
    }
}

