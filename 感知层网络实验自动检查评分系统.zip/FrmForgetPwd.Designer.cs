﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmForgetPwd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmForgetPwd));
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.BtnCancel = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.BtnEnter = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.LbForget = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.TxtForgetUser = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.BtnCancel);
            this.kryptonPanel.Controls.Add(this.BtnEnter);
            this.kryptonPanel.Controls.Add(this.LbForget);
            this.kryptonPanel.Controls.Add(this.TxtForgetUser);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(332, 253);
            this.kryptonPanel.TabIndex = 0;
            // 
            // BtnCancel
            // 
            this.BtnCancel.Location = new System.Drawing.Point(173, 158);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(80, 46);
            this.BtnCancel.TabIndex = 2;
            this.BtnCancel.Values.Text = "返回";
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnEnter
            // 
            this.BtnEnter.Location = new System.Drawing.Point(75, 158);
            this.BtnEnter.Name = "BtnEnter";
            this.BtnEnter.Size = new System.Drawing.Size(80, 46);
            this.BtnEnter.TabIndex = 1;
            this.BtnEnter.Values.Text = "提交";
            this.BtnEnter.Click += new System.EventHandler(this.BtnEnter_Click);
            // 
            // LbForget
            // 
            this.LbForget.Location = new System.Drawing.Point(80, 55);
            this.LbForget.Name = "LbForget";
            this.LbForget.Size = new System.Drawing.Size(173, 24);
            this.LbForget.TabIndex = 1;
            this.LbForget.Values.Text = "请输入遗失密码的账号";
            // 
            // TxtForgetUser
            // 
            this.TxtForgetUser.Location = new System.Drawing.Point(75, 97);
            this.TxtForgetUser.Name = "TxtForgetUser";
            this.TxtForgetUser.Size = new System.Drawing.Size(182, 27);
            this.TxtForgetUser.TabIndex = 0;
            // 
            // FrmForgetPwd
            // 
            this.AcceptButton = this.BtnEnter;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 253);
            this.Controls.Add(this.kryptonPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximumSize = new System.Drawing.Size(350, 300);
            this.MinimumSize = new System.Drawing.Size(350, 300);
            this.Name = "FrmForgetPwd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "找回密码";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnEnter;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbForget;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtForgetUser;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnCancel;
    }
}

