﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmDeleteStu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonLabelSno = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelSna = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelScla = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonButtonDeleteStu = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonLabelAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxSno = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxSna = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxScla = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxScla);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxSna);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxSno);
            this.kryptonPanel.Controls.Add(this.kryptonLabelAns);
            this.kryptonPanel.Controls.Add(this.kryptonButtonDeleteStu);
            this.kryptonPanel.Controls.Add(this.kryptonLabelScla);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSna);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSno);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(519, 403);
            this.kryptonPanel.TabIndex = 0;
            // 
            // kryptonLabelSno
            // 
            this.kryptonLabelSno.Location = new System.Drawing.Point(73, 74);
            this.kryptonLabelSno.Name = "kryptonLabelSno";
            this.kryptonLabelSno.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelSno.TabIndex = 0;
            this.kryptonLabelSno.Values.Text = "学号";
            // 
            // kryptonLabelSna
            // 
            this.kryptonLabelSna.Location = new System.Drawing.Point(73, 107);
            this.kryptonLabelSna.Name = "kryptonLabelSna";
            this.kryptonLabelSna.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelSna.TabIndex = 1;
            this.kryptonLabelSna.Values.Text = "姓名";
            // 
            // kryptonLabelScla
            // 
            this.kryptonLabelScla.Location = new System.Drawing.Point(73, 140);
            this.kryptonLabelScla.Name = "kryptonLabelScla";
            this.kryptonLabelScla.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelScla.TabIndex = 2;
            this.kryptonLabelScla.Values.Text = "班级";
            // 
            // kryptonButtonDeleteStu
            // 
            this.kryptonButtonDeleteStu.Location = new System.Drawing.Point(73, 185);
            this.kryptonButtonDeleteStu.Name = "kryptonButtonDeleteStu";
            this.kryptonButtonDeleteStu.Size = new System.Drawing.Size(206, 50);
            this.kryptonButtonDeleteStu.TabIndex = 3;
            this.kryptonButtonDeleteStu.Values.Text = "删除";
            this.kryptonButtonDeleteStu.Click += new System.EventHandler(this.kryptonButtonDeleteStu_Click);
            // 
            // kryptonLabelAns
            // 
            this.kryptonLabelAns.Location = new System.Drawing.Point(73, 264);
            this.kryptonLabelAns.Name = "kryptonLabelAns";
            this.kryptonLabelAns.Size = new System.Drawing.Size(6, 2);
            this.kryptonLabelAns.TabIndex = 4;
            this.kryptonLabelAns.Values.Text = "";
            // 
            // kryptonTextBoxSno
            // 
            this.kryptonTextBoxSno.Location = new System.Drawing.Point(123, 71);
            this.kryptonTextBoxSno.Name = "kryptonTextBoxSno";
            this.kryptonTextBoxSno.Size = new System.Drawing.Size(156, 27);
            this.kryptonTextBoxSno.TabIndex = 5;
            // 
            // kryptonTextBoxSna
            // 
            this.kryptonTextBoxSna.Location = new System.Drawing.Point(123, 104);
            this.kryptonTextBoxSna.Name = "kryptonTextBoxSna";
            this.kryptonTextBoxSna.Size = new System.Drawing.Size(156, 27);
            this.kryptonTextBoxSna.TabIndex = 6;
            // 
            // kryptonTextBoxScla
            // 
            this.kryptonTextBoxScla.Location = new System.Drawing.Point(123, 137);
            this.kryptonTextBoxScla.Name = "kryptonTextBoxScla";
            this.kryptonTextBoxScla.Size = new System.Drawing.Size(156, 27);
            this.kryptonTextBoxScla.TabIndex = 7;
            // 
            // FrmDeleteStu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 403);
            this.Controls.Add(this.kryptonPanel);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmDeleteStu";
            this.Text = "FrmDeleteStu";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxScla;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSna;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSno;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelAns;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonDeleteStu;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelScla;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSna;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSno;
    }
}

