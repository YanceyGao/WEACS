﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Commons;
using ComponentFactory.Krypton.Toolkit;
using 感知层网络实验自动检查评分系统.UserInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmRegister : ComponentFactory.Krypton.Toolkit.KryptonForm
    {
        public FrmRegister()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            string user_id;
            string user_pwd;
            string user_pwd1;
            string user_pwd2;
            string tip_pwd;
            string ip_addr;
            string mac_addr;

            user_id = TxtUser.Text.Trim();
            user_pwd1 = TxtPwd1.Text.Trim();
            user_pwd2 = TxtPwd2.Text.Trim();
            tip_pwd = TxtPwdtip.Text.Trim();
            ip_addr = TxtIp_addr.Text.Trim();
            mac_addr = TxtMac_addr.Text.Trim();

            UserInfoWebService.UserInfoWebServiceSoapClient userInfoWebSer = new UserInfoWebServiceSoapClient();

            if (user_id == null)
            {
                MessageBox.Show("用户名不能为空", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (user_pwd1 == null)
            {
                MessageBox.Show("密码不能为空", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!user_pwd1.Equals(user_pwd2))
            {
                MessageBox.Show("重复密码不相同", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //密码加密
            user_pwd = EncodeHelper.AES_Encrypt(user_pwd1);
            string key = userInfoWebSer.Register(user_id, user_pwd, tip_pwd, ip_addr, mac_addr);

            if(key == null)
            {
                MessageBox.Show("注册成功", "信息提示", MessageBoxButtons.OK);
                this.Close();
            }
            else
            {
                MessageBox.Show("注册失败\n" + key, "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            /*      采用本地连接方式
            string user_id;
            string user_pwd1;
            string user_pwd2;
            string tip_pwd;
            string ip_addr;
            string mac_addr;

            user_id = TxtUser.Text.Trim();
            user_pwd1 = TxtPwd1.Text.Trim();
            user_pwd2 = TxtPwd2.Text.Trim();
            tip_pwd = TxtPwdtip.Text.Trim();
            ip_addr = TxtIp_addr.Text.Trim();
            mac_addr = TxtMac_addr.Text.Trim();

            DBConnect dbConn = new DBConnect();       //实例化连接数据库的类的对象

            if (user_id == null)
            {
                MessageBox.Show("用户名不能为空", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (user_pwd1 == null)
            {
                MessageBox.Show("密码不能为空", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!user_pwd1.Equals(user_pwd2))
            {
                MessageBox.Show("重复密码不相同", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Exception key = dbConn.Regisiter(user_id, user_pwd1, tip_pwd, ip_addr, mac_addr);
            if (key == null)
            {
                MessageBox.Show("注册成功", "信息提示", MessageBoxButtons.OK);
                this.Close();
            }
            else
            {
                MessageBox.Show("注册失败", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            */
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}