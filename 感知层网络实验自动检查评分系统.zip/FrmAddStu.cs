﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;
using 感知层网络实验自动检查评分系统.StuInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmAddStu : DockContent
    {
        public FrmAddStu()
        {
            InitializeComponent();
        }

        private void kryptonButtonAddStu_Click(object sender, EventArgs e)
        {
            String Sno = kryptonTextBoxSno.Text;
            String Sna = kryptonTextBoxSna.Text;
            String Scla = kryptonTextBoxScla.Text;
            String ageStr = kryptonTextBoxSage.Text;
            String Ssex = kryptonTextBoxSsex.Text;
            String Sdept = kryptonTextBoxSdept.Text;
            String Scol = kryptonTextBoxScol.Text;

            int Sage = Convert.ToInt32(ageStr);

            StuInfoWebServiceSoapClient stuInfoWebServiceSoapClient = new StuInfoWebServiceSoapClient();
            String ans = stuInfoWebServiceSoapClient.addStudent(Sno, Sna, Scla, Sage, Ssex, Sdept, Scol);

            if (ans == null)
            {
                kryptonLabelAns.Text = "添加成功";
            }
            else
            {
                kryptonLabelAns.Text = ans;
            }
        }
    }
}