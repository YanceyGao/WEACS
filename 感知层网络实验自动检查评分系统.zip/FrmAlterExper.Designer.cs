﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmAlterExper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonButtonEnameSearch = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButtonEnter = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonButtonEnoSearch = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonTextBoxNotPassCount = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxBetterCount = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxPassCount = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxAnsBetter = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxAnsPass = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEcode = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEname = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEno = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelBetterCount = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelNotPassCount = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelPassCount = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelAnsBetter = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelAnsPass = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEcode = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEname = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEno = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.kryptonButtonEnameSearch);
            this.kryptonPanel.Controls.Add(this.kryptonButtonEnter);
            this.kryptonPanel.Controls.Add(this.kryptonButtonEnoSearch);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxNotPassCount);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxBetterCount);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxPassCount);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxAnsBetter);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxAnsPass);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEcode);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEname);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEno);
            this.kryptonPanel.Controls.Add(this.kryptonLabelBetterCount);
            this.kryptonPanel.Controls.Add(this.kryptonLabelNotPassCount);
            this.kryptonPanel.Controls.Add(this.kryptonLabelPassCount);
            this.kryptonPanel.Controls.Add(this.kryptonLabelAnsBetter);
            this.kryptonPanel.Controls.Add(this.kryptonLabelAnsPass);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEcode);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEname);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEno);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(922, 498);
            this.kryptonPanel.TabIndex = 0;
            // 
            // kryptonButtonEnameSearch
            // 
            this.kryptonButtonEnameSearch.Location = new System.Drawing.Point(429, 97);
            this.kryptonButtonEnameSearch.Name = "kryptonButtonEnameSearch";
            this.kryptonButtonEnameSearch.Size = new System.Drawing.Size(141, 33);
            this.kryptonButtonEnameSearch.TabIndex = 19;
            this.kryptonButtonEnameSearch.Values.Text = "查询";
            this.kryptonButtonEnameSearch.Click += new System.EventHandler(this.kryptonButtonEnameSearch_Click);
            // 
            // kryptonButtonEnter
            // 
            this.kryptonButtonEnter.Location = new System.Drawing.Point(435, 371);
            this.kryptonButtonEnter.Name = "kryptonButtonEnter";
            this.kryptonButtonEnter.Size = new System.Drawing.Size(135, 113);
            this.kryptonButtonEnter.TabIndex = 18;
            this.kryptonButtonEnter.Values.Text = "提交";
            this.kryptonButtonEnter.Click += new System.EventHandler(this.kryptonButtonEnter_Click);
            // 
            // kryptonButtonEnoSearch
            // 
            this.kryptonButtonEnoSearch.Location = new System.Drawing.Point(429, 38);
            this.kryptonButtonEnoSearch.Name = "kryptonButtonEnoSearch";
            this.kryptonButtonEnoSearch.Size = new System.Drawing.Size(141, 33);
            this.kryptonButtonEnoSearch.TabIndex = 16;
            this.kryptonButtonEnoSearch.Values.Text = "查询";
            this.kryptonButtonEnoSearch.Click += new System.EventHandler(this.kryptonButtonEnoSearch_Click);
            // 
            // kryptonTextBoxNotPassCount
            // 
            this.kryptonTextBoxNotPassCount.Location = new System.Drawing.Point(185, 457);
            this.kryptonTextBoxNotPassCount.Name = "kryptonTextBoxNotPassCount";
            this.kryptonTextBoxNotPassCount.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxNotPassCount.TabIndex = 15;
            // 
            // kryptonTextBoxBetterCount
            // 
            this.kryptonTextBoxBetterCount.Location = new System.Drawing.Point(185, 398);
            this.kryptonTextBoxBetterCount.Name = "kryptonTextBoxBetterCount";
            this.kryptonTextBoxBetterCount.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxBetterCount.TabIndex = 14;
            // 
            // kryptonTextBoxPassCount
            // 
            this.kryptonTextBoxPassCount.Location = new System.Drawing.Point(185, 339);
            this.kryptonTextBoxPassCount.Name = "kryptonTextBoxPassCount";
            this.kryptonTextBoxPassCount.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxPassCount.TabIndex = 13;
            // 
            // kryptonTextBoxAnsBetter
            // 
            this.kryptonTextBoxAnsBetter.Location = new System.Drawing.Point(185, 280);
            this.kryptonTextBoxAnsBetter.Name = "kryptonTextBoxAnsBetter";
            this.kryptonTextBoxAnsBetter.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxAnsBetter.TabIndex = 12;
            // 
            // kryptonTextBoxAnsPass
            // 
            this.kryptonTextBoxAnsPass.Location = new System.Drawing.Point(185, 221);
            this.kryptonTextBoxAnsPass.Name = "kryptonTextBoxAnsPass";
            this.kryptonTextBoxAnsPass.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxAnsPass.TabIndex = 11;
            // 
            // kryptonTextBoxEcode
            // 
            this.kryptonTextBoxEcode.Location = new System.Drawing.Point(185, 162);
            this.kryptonTextBoxEcode.Name = "kryptonTextBoxEcode";
            this.kryptonTextBoxEcode.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxEcode.TabIndex = 10;
            // 
            // kryptonTextBoxEname
            // 
            this.kryptonTextBoxEname.Location = new System.Drawing.Point(185, 103);
            this.kryptonTextBoxEname.Name = "kryptonTextBoxEname";
            this.kryptonTextBoxEname.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxEname.TabIndex = 9;
            // 
            // kryptonTextBoxEno
            // 
            this.kryptonTextBoxEno.Location = new System.Drawing.Point(185, 44);
            this.kryptonTextBoxEno.Name = "kryptonTextBoxEno";
            this.kryptonTextBoxEno.Size = new System.Drawing.Size(238, 27);
            this.kryptonTextBoxEno.TabIndex = 8;
            // 
            // kryptonLabelBetterCount
            // 
            this.kryptonLabelBetterCount.Location = new System.Drawing.Point(70, 401);
            this.kryptonLabelBetterCount.Name = "kryptonLabelBetterCount";
            this.kryptonLabelBetterCount.Size = new System.Drawing.Size(76, 24);
            this.kryptonLabelBetterCount.TabIndex = 7;
            this.kryptonLabelBetterCount.Values.Text = "优秀人数";
            // 
            // kryptonLabelNotPassCount
            // 
            this.kryptonLabelNotPassCount.Location = new System.Drawing.Point(70, 460);
            this.kryptonLabelNotPassCount.Name = "kryptonLabelNotPassCount";
            this.kryptonLabelNotPassCount.Size = new System.Drawing.Size(92, 24);
            this.kryptonLabelNotPassCount.TabIndex = 6;
            this.kryptonLabelNotPassCount.Values.Text = "未通过人数";
            // 
            // kryptonLabelPassCount
            // 
            this.kryptonLabelPassCount.Location = new System.Drawing.Point(70, 342);
            this.kryptonLabelPassCount.Name = "kryptonLabelPassCount";
            this.kryptonLabelPassCount.Size = new System.Drawing.Size(76, 24);
            this.kryptonLabelPassCount.TabIndex = 5;
            this.kryptonLabelPassCount.Values.Text = "通过人数";
            // 
            // kryptonLabelAnsBetter
            // 
            this.kryptonLabelAnsBetter.Location = new System.Drawing.Point(70, 283);
            this.kryptonLabelAnsBetter.Name = "kryptonLabelAnsBetter";
            this.kryptonLabelAnsBetter.Size = new System.Drawing.Size(76, 24);
            this.kryptonLabelAnsBetter.TabIndex = 4;
            this.kryptonLabelAnsBetter.Values.Text = "优秀结果";
            // 
            // kryptonLabelAnsPass
            // 
            this.kryptonLabelAnsPass.Location = new System.Drawing.Point(70, 224);
            this.kryptonLabelAnsPass.Name = "kryptonLabelAnsPass";
            this.kryptonLabelAnsPass.Size = new System.Drawing.Size(76, 24);
            this.kryptonLabelAnsPass.TabIndex = 3;
            this.kryptonLabelAnsPass.Values.Text = "通过结果";
            // 
            // kryptonLabelEcode
            // 
            this.kryptonLabelEcode.Location = new System.Drawing.Point(70, 165);
            this.kryptonLabelEcode.Name = "kryptonLabelEcode";
            this.kryptonLabelEcode.Size = new System.Drawing.Size(76, 24);
            this.kryptonLabelEcode.TabIndex = 2;
            this.kryptonLabelEcode.Values.Text = "实验编码";
            // 
            // kryptonLabelEname
            // 
            this.kryptonLabelEname.Location = new System.Drawing.Point(70, 106);
            this.kryptonLabelEname.Name = "kryptonLabelEname";
            this.kryptonLabelEname.Size = new System.Drawing.Size(77, 24);
            this.kryptonLabelEname.TabIndex = 1;
            this.kryptonLabelEname.Values.Text = "实  验  名";
            // 
            // kryptonLabelEno
            // 
            this.kryptonLabelEno.Location = new System.Drawing.Point(70, 47);
            this.kryptonLabelEno.Name = "kryptonLabelEno";
            this.kryptonLabelEno.Size = new System.Drawing.Size(77, 24);
            this.kryptonLabelEno.TabIndex = 0;
            this.kryptonLabelEno.Values.Text = "实  验  号";
            // 
            // FrmAlterExper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 498);
            this.Controls.Add(this.kryptonPanel);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmAlterExper";
            this.Text = "FrmAlterExper";
            this.Load += new System.EventHandler(this.FrmAlterExper_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonEnameSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonEnter;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonEnoSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxNotPassCount;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxBetterCount;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxPassCount;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxAnsBetter;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxAnsPass;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEcode;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEname;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEno;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelBetterCount;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelNotPassCount;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelPassCount;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelAnsBetter;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelAnsPass;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEcode;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEname;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEno;
    }
}

