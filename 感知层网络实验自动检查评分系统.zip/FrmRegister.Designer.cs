﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRegister));
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.LbPwdtip = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.TxtPwdtip = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.LbImPwd2 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbImPwd1 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbImUser = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbIp_addr = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbPwd1 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbMac_addr = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbPwd2 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbUser = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbTxtRegister = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.BtnCancel = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.BtnRegister = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.TxtMac_addr = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.TxtIp_addr = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.TxtPwd2 = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.TxtPwd1 = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.TxtUser = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.LbPwdtip);
            this.kryptonPanel.Controls.Add(this.TxtPwdtip);
            this.kryptonPanel.Controls.Add(this.LbImPwd2);
            this.kryptonPanel.Controls.Add(this.LbImPwd1);
            this.kryptonPanel.Controls.Add(this.LbImUser);
            this.kryptonPanel.Controls.Add(this.LbIp_addr);
            this.kryptonPanel.Controls.Add(this.LbPwd1);
            this.kryptonPanel.Controls.Add(this.LbMac_addr);
            this.kryptonPanel.Controls.Add(this.LbPwd2);
            this.kryptonPanel.Controls.Add(this.LbUser);
            this.kryptonPanel.Controls.Add(this.LbTxtRegister);
            this.kryptonPanel.Controls.Add(this.BtnCancel);
            this.kryptonPanel.Controls.Add(this.BtnRegister);
            this.kryptonPanel.Controls.Add(this.TxtMac_addr);
            this.kryptonPanel.Controls.Add(this.TxtIp_addr);
            this.kryptonPanel.Controls.Add(this.TxtPwd2);
            this.kryptonPanel.Controls.Add(this.TxtPwd1);
            this.kryptonPanel.Controls.Add(this.TxtUser);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(332, 353);
            this.kryptonPanel.TabIndex = 0;
            // 
            // LbPwdtip
            // 
            this.LbPwdtip.Location = new System.Drawing.Point(22, 159);
            this.LbPwdtip.Name = "LbPwdtip";
            this.LbPwdtip.Size = new System.Drawing.Size(76, 24);
            this.LbPwdtip.TabIndex = 47;
            this.LbPwdtip.Values.Text = "密码提示";
            // 
            // TxtPwdtip
            // 
            this.TxtPwdtip.Location = new System.Drawing.Point(101, 156);
            this.TxtPwdtip.Name = "TxtPwdtip";
            this.TxtPwdtip.Size = new System.Drawing.Size(197, 27);
            this.TxtPwdtip.TabIndex = 3;
            // 
            // LbImPwd2
            // 
            this.LbImPwd2.Location = new System.Drawing.Point(302, 126);
            this.LbImPwd2.Name = "LbImPwd2";
            this.LbImPwd2.Size = new System.Drawing.Size(18, 24);
            this.LbImPwd2.TabIndex = 45;
            this.LbImPwd2.Values.Text = "*";
            // 
            // LbImPwd1
            // 
            this.LbImPwd1.Location = new System.Drawing.Point(302, 93);
            this.LbImPwd1.Name = "LbImPwd1";
            this.LbImPwd1.Size = new System.Drawing.Size(18, 24);
            this.LbImPwd1.TabIndex = 44;
            this.LbImPwd1.Values.Text = "*";
            // 
            // LbImUser
            // 
            this.LbImUser.Location = new System.Drawing.Point(302, 60);
            this.LbImUser.Name = "LbImUser";
            this.LbImUser.Size = new System.Drawing.Size(18, 24);
            this.LbImUser.TabIndex = 43;
            this.LbImUser.Values.Text = "*";
            // 
            // LbIp_addr
            // 
            this.LbIp_addr.Location = new System.Drawing.Point(22, 192);
            this.LbIp_addr.Name = "LbIp_addr";
            this.LbIp_addr.Size = new System.Drawing.Size(74, 24);
            this.LbIp_addr.TabIndex = 42;
            this.LbIp_addr.Values.Text = "限  制  IP";
            // 
            // LbPwd1
            // 
            this.LbPwd1.Location = new System.Drawing.Point(22, 93);
            this.LbPwd1.Name = "LbPwd1";
            this.LbPwd1.Size = new System.Drawing.Size(78, 24);
            this.LbPwd1.TabIndex = 41;
            this.LbPwd1.Values.Text = "密        码";
            // 
            // LbMac_addr
            // 
            this.LbMac_addr.Location = new System.Drawing.Point(22, 225);
            this.LbMac_addr.Name = "LbMac_addr";
            this.LbMac_addr.Size = new System.Drawing.Size(77, 24);
            this.LbMac_addr.TabIndex = 40;
            this.LbMac_addr.Values.Text = "限制MAC";
            // 
            // LbPwd2
            // 
            this.LbPwd2.Location = new System.Drawing.Point(22, 126);
            this.LbPwd2.Name = "LbPwd2";
            this.LbPwd2.Size = new System.Drawing.Size(76, 24);
            this.LbPwd2.TabIndex = 39;
            this.LbPwd2.Values.Text = "重复密码";
            // 
            // LbUser
            // 
            this.LbUser.Location = new System.Drawing.Point(22, 60);
            this.LbUser.Name = "LbUser";
            this.LbUser.Size = new System.Drawing.Size(77, 24);
            this.LbUser.TabIndex = 38;
            this.LbUser.Values.Text = "用  户  名";
            // 
            // LbTxtRegister
            // 
            this.LbTxtRegister.LabelStyle = ComponentFactory.Krypton.Toolkit.LabelStyle.TitleControl;
            this.LbTxtRegister.Location = new System.Drawing.Point(123, 13);
            this.LbTxtRegister.Name = "LbTxtRegister";
            this.LbTxtRegister.Size = new System.Drawing.Size(63, 35);
            this.LbTxtRegister.TabIndex = 37;
            this.LbTxtRegister.Values.Text = "注册";
            // 
            // BtnCancel
            // 
            this.BtnCancel.Location = new System.Drawing.Point(179, 262);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(119, 67);
            this.BtnCancel.TabIndex = 7;
            this.BtnCancel.Values.Text = "取消";
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnRegister
            // 
            this.BtnRegister.Location = new System.Drawing.Point(22, 262);
            this.BtnRegister.Name = "BtnRegister";
            this.BtnRegister.Size = new System.Drawing.Size(119, 67);
            this.BtnRegister.TabIndex = 6;
            this.BtnRegister.Values.Text = "注册";
            this.BtnRegister.Click += new System.EventHandler(this.BtnRegister_Click);
            // 
            // TxtMac_addr
            // 
            this.TxtMac_addr.Location = new System.Drawing.Point(101, 222);
            this.TxtMac_addr.Name = "TxtMac_addr";
            this.TxtMac_addr.Size = new System.Drawing.Size(197, 27);
            this.TxtMac_addr.TabIndex = 5;
            // 
            // TxtIp_addr
            // 
            this.TxtIp_addr.Location = new System.Drawing.Point(101, 189);
            this.TxtIp_addr.Name = "TxtIp_addr";
            this.TxtIp_addr.Size = new System.Drawing.Size(197, 27);
            this.TxtIp_addr.TabIndex = 4;
            // 
            // TxtPwd2
            // 
            this.TxtPwd2.Location = new System.Drawing.Point(101, 123);
            this.TxtPwd2.MaxLength = 12;
            this.TxtPwd2.Name = "TxtPwd2";
            this.TxtPwd2.PasswordChar = '*';
            this.TxtPwd2.Size = new System.Drawing.Size(197, 27);
            this.TxtPwd2.TabIndex = 2;
            // 
            // TxtPwd1
            // 
            this.TxtPwd1.Location = new System.Drawing.Point(101, 90);
            this.TxtPwd1.MaxLength = 12;
            this.TxtPwd1.Name = "TxtPwd1";
            this.TxtPwd1.PasswordChar = '*';
            this.TxtPwd1.Size = new System.Drawing.Size(197, 27);
            this.TxtPwd1.TabIndex = 1;
            // 
            // TxtUser
            // 
            this.TxtUser.Location = new System.Drawing.Point(101, 57);
            this.TxtUser.MaxLength = 12;
            this.TxtUser.Name = "TxtUser";
            this.TxtUser.Size = new System.Drawing.Size(197, 27);
            this.TxtUser.TabIndex = 0;
            // 
            // FrmRegister
            // 
            this.AcceptButton = this.BtnRegister;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 353);
            this.Controls.Add(this.kryptonPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximumSize = new System.Drawing.Size(350, 400);
            this.MinimumSize = new System.Drawing.Size(350, 400);
            this.Name = "FrmRegister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "注册";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbImPwd1;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbImUser;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbIp_addr;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbPwd1;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbMac_addr;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbPwd2;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbUser;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbTxtRegister;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnCancel;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnRegister;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtMac_addr;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtIp_addr;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtPwd2;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtPwd1;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtUser;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbImPwd2;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbPwdtip;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtPwdtip;
    }
}

