﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            WeifenLuo.WinFormsUI.Docking.DockPanelSkin dockPanelSkin1 = new WeifenLuo.WinFormsUI.Docking.DockPanelSkin();
            WeifenLuo.WinFormsUI.Docking.AutoHideStripSkin autoHideStripSkin1 = new WeifenLuo.WinFormsUI.Docking.AutoHideStripSkin();
            WeifenLuo.WinFormsUI.Docking.DockPanelGradient dockPanelGradient1 = new WeifenLuo.WinFormsUI.Docking.DockPanelGradient();
            WeifenLuo.WinFormsUI.Docking.TabGradient tabGradient1 = new WeifenLuo.WinFormsUI.Docking.TabGradient();
            WeifenLuo.WinFormsUI.Docking.DockPaneStripSkin dockPaneStripSkin1 = new WeifenLuo.WinFormsUI.Docking.DockPaneStripSkin();
            WeifenLuo.WinFormsUI.Docking.DockPaneStripGradient dockPaneStripGradient1 = new WeifenLuo.WinFormsUI.Docking.DockPaneStripGradient();
            WeifenLuo.WinFormsUI.Docking.TabGradient tabGradient2 = new WeifenLuo.WinFormsUI.Docking.TabGradient();
            WeifenLuo.WinFormsUI.Docking.DockPanelGradient dockPanelGradient2 = new WeifenLuo.WinFormsUI.Docking.DockPanelGradient();
            WeifenLuo.WinFormsUI.Docking.TabGradient tabGradient3 = new WeifenLuo.WinFormsUI.Docking.TabGradient();
            WeifenLuo.WinFormsUI.Docking.DockPaneStripToolWindowGradient dockPaneStripToolWindowGradient1 = new WeifenLuo.WinFormsUI.Docking.DockPaneStripToolWindowGradient();
            WeifenLuo.WinFormsUI.Docking.TabGradient tabGradient4 = new WeifenLuo.WinFormsUI.Docking.TabGradient();
            WeifenLuo.WinFormsUI.Docking.TabGradient tabGradient5 = new WeifenLuo.WinFormsUI.Docking.TabGradient();
            WeifenLuo.WinFormsUI.Docking.DockPanelGradient dockPanelGradient3 = new WeifenLuo.WinFormsUI.Docking.DockPanelGradient();
            WeifenLuo.WinFormsUI.Docking.TabGradient tabGradient6 = new WeifenLuo.WinFormsUI.Docking.TabGradient();
            WeifenLuo.WinFormsUI.Docking.TabGradient tabGradient7 = new WeifenLuo.WinFormsUI.Docking.TabGradient();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelEmpty1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelIp = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelEmpty2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelLastLoginTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelLoginTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.qTranslucentWindowComponent = new Qios.DevSuite.Components.QTranslucentWindowComponent(this.components);
            this.qRibbon = new Qios.DevSuite.Components.Ribbon.QRibbon();
            this.qRibbonPage1 = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonPanelHomeOne = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonPanelHomeTwo = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemHomeOpen = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemHomeClose = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qCompositeItem2 = new Qios.DevSuite.Components.QCompositeItem();
            this.qRibbonPageStuManage = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonPanelStuOne = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemStuTree = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuSelect = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuTreeClose = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanelStuTwo = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemClaNew = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemClaDelete = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuNew = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuDelete = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanelStuThree = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemStuStart = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuLast = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuNext = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuEnd = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanelStuFive = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemStuExport = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemStuBack = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPageExperManage = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonPanelExperOne = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemExperTree = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperSelect = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperClose = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanelTwo = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemExperStart = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperLast = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperNext = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperEnd = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanelExperThree = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemExperNew = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperDelete = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperAlter = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemExperBack = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPageHelp = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonPageGradeManage = new Qios.DevSuite.Components.Ribbon.QRibbonPage();
            this.qRibbonPanelGrdeOne = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemGradeTree = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGradeSelect = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGradeClose = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanelGradeTwo = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemGradeStart = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGradeLast = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGradeNext = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGradeEnd = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonPanelGradeThree = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItemGradeExport = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItemGradeBack = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.dockPanelMain = new WeifenLuo.WinFormsUI.Docking.DockPanel();
            this.qRibbonItem5 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.qRibbonItem4 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.saveFileDialogExcel = new System.Windows.Forms.SaveFileDialog();
            this.qCompositeImage = new Qios.DevSuite.Components.QCompositeImage();
            this.qRibbonPanel1 = new Qios.DevSuite.Components.Ribbon.QRibbonPanel();
            this.qRibbonItem2 = new Qios.DevSuite.Components.Ribbon.QRibbonItem();
            this.statusStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbon)).BeginInit();
            this.qRibbon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPage1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageStuManage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageExperManage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageHelp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageGradeManage)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelUser,
            this.toolStripStatusLabelEmpty1,
            this.toolStripStatusLabelIp,
            this.toolStripStatusLabelEmpty2,
            this.toolStripStatusLabelLastLoginTime,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabelLoginTime});
            this.statusStrip.Location = new System.Drawing.Point(0, 461);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1013, 26);
            this.statusStrip.TabIndex = 4;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabelUser
            // 
            this.toolStripStatusLabelUser.Name = "toolStripStatusLabelUser";
            this.toolStripStatusLabelUser.Size = new System.Drawing.Size(69, 20);
            this.toolStripStatusLabelUser.Text = "用户名：";
            // 
            // toolStripStatusLabelEmpty1
            // 
            this.toolStripStatusLabelEmpty1.Name = "toolStripStatusLabelEmpty1";
            this.toolStripStatusLabelEmpty1.Size = new System.Drawing.Size(73, 20);
            this.toolStripStatusLabelEmpty1.Text = "                ";
            // 
            // toolStripStatusLabelIp
            // 
            this.toolStripStatusLabelIp.Name = "toolStripStatusLabelIp";
            this.toolStripStatusLabelIp.Size = new System.Drawing.Size(37, 20);
            this.toolStripStatusLabelIp.Text = "IP：";
            // 
            // toolStripStatusLabelEmpty2
            // 
            this.toolStripStatusLabelEmpty2.Name = "toolStripStatusLabelEmpty2";
            this.toolStripStatusLabelEmpty2.Size = new System.Drawing.Size(73, 20);
            this.toolStripStatusLabelEmpty2.Text = "                ";
            // 
            // toolStripStatusLabelLastLoginTime
            // 
            this.toolStripStatusLabelLastLoginTime.Name = "toolStripStatusLabelLastLoginTime";
            this.toolStripStatusLabelLastLoginTime.Size = new System.Drawing.Size(114, 20);
            this.toolStripStatusLabelLastLoginTime.Text = "上次登录时间：";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(73, 20);
            this.toolStripStatusLabel2.Text = "                ";
            // 
            // toolStripStatusLabelLoginTime
            // 
            this.toolStripStatusLabelLoginTime.Name = "toolStripStatusLabelLoginTime";
            this.toolStripStatusLabelLoginTime.Size = new System.Drawing.Size(114, 20);
            this.toolStripStatusLabelLoginTime.Text = "本次登录时间：";
            // 
            // qRibbon
            // 
            this.qRibbon.ActiveTabPage = this.qRibbonPage1;
            this.qRibbon.ColorScheme.RibbonBackground1.SetColor("VistaBlack", System.Drawing.SystemColors.GradientActiveCaption, false);
            this.qRibbon.ColorScheme.RibbonBackground2.SetColor("VistaBlack", System.Drawing.SystemColors.GradientInactiveCaption, false);
            this.qRibbon.ColorScheme.RibbonBorder.SetColor("VistaBlack", System.Drawing.SystemColors.ActiveBorder, false);
            this.qRibbon.Controls.Add(this.qRibbonPage1);
            this.qRibbon.Controls.Add(this.qRibbonPageStuManage);
            this.qRibbon.Controls.Add(this.qRibbonPageExperManage);
            this.qRibbon.Controls.Add(this.qRibbonPageHelp);
            this.qRibbon.Controls.Add(this.qRibbonPageGradeManage);
            this.qRibbon.Cursor = System.Windows.Forms.Cursors.Default;
            this.qRibbon.Dock = System.Windows.Forms.DockStyle.Top;
            this.qRibbon.Location = new System.Drawing.Point(0, 0);
            this.qRibbon.Name = "qRibbon";
            this.qRibbon.PersistGuid = new System.Guid("2f886599-c56d-419f-be38-b5e36c41dfb0");
            this.qRibbon.Size = new System.Drawing.Size(1013, 166);
            this.qRibbon.TabIndex = 12;
            this.qRibbon.TabStripConfiguration.HelpButtonVisible = false;
            // 
            // qRibbonPage1
            // 
            this.qRibbonPage1.ButtonOrder = 0;
            this.qRibbonPage1.ColorScheme.RibbonPageBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qRibbonPage1.ColorScheme.RibbonPageBackground2.SetColor("VistaBlack", System.Drawing.SystemColors.GradientActiveCaption, false);
            this.qRibbonPage1.Items.Add(this.qRibbonPanelHomeOne);
            this.qRibbonPage1.Items.Add(this.qRibbonPanelHomeTwo);
            this.qRibbonPage1.Items.Add(this.qCompositeItem2);
            this.qRibbonPage1.Location = new System.Drawing.Point(2, 34);
            this.qRibbonPage1.Name = "qRibbonPage1";
            this.qRibbonPage1.PersistGuid = new System.Guid("d866a381-aed6-46a8-b2dc-cb17fe7acea2");
            this.qRibbonPage1.Size = new System.Drawing.Size(1007, 128);
            this.qRibbonPage1.Text = "主页";
            // 
            // qRibbonPanelHomeOne
            // 
            this.qRibbonPanelHomeOne.ColorScheme.CompositeBalloonBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qRibbonPanelHomeOne.Items.Add(this.qCompositeImage);
            this.qRibbonPanelHomeOne.Title = "WSN";
            // 
            // qRibbonPanelHomeTwo
            // 
            this.qRibbonPanelHomeTwo.Items.Add(this.qRibbonItemHomeOpen);
            this.qRibbonPanelHomeTwo.Items.Add(this.qRibbonItemHomeClose);
            this.qRibbonPanelHomeTwo.Title = "起始页";
            // 
            // qRibbonItemHomeOpen
            // 
            this.qRibbonItemHomeOpen.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemHomeOpen.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemHomeOpen.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemHomeOpen.Icon")));
            this.qRibbonItemHomeOpen.Title = "主页";
            this.qRibbonItemHomeOpen.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemHomeOpen_ItemActivated);
            // 
            // qRibbonItemHomeClose
            // 
            this.qRibbonItemHomeClose.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemHomeClose.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemHomeClose.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemHomeClose.Icon")));
            this.qRibbonItemHomeClose.Title = "关闭";
            this.qRibbonItemHomeClose.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemHomeClose_ItemActivated);
            // 
            // qRibbonPageStuManage
            // 
            this.qRibbonPageStuManage.ButtonOrder = 1;
            this.qRibbonPageStuManage.ColorScheme.RibbonPageBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qRibbonPageStuManage.ColorScheme.RibbonPageBackground2.SetColor("VistaBlack", System.Drawing.SystemColors.GradientActiveCaption, false);
            this.qRibbonPageStuManage.ColorScheme.RibbonPageBorder.SetColor("VistaBlack", System.Drawing.SystemColors.ActiveBorder, false);
            this.qRibbonPageStuManage.Items.Add(this.qRibbonPanelStuOne);
            this.qRibbonPageStuManage.Items.Add(this.qRibbonPanelStuTwo);
            this.qRibbonPageStuManage.Items.Add(this.qRibbonPanelStuThree);
            this.qRibbonPageStuManage.Items.Add(this.qRibbonPanelStuFive);
            this.qRibbonPageStuManage.Location = new System.Drawing.Point(2, 34);
            this.qRibbonPageStuManage.Name = "qRibbonPageStuManage";
            this.qRibbonPageStuManage.PersistGuid = new System.Guid("a52d80c2-3201-4303-9c49-89a13eccac66");
            this.qRibbonPageStuManage.Size = new System.Drawing.Size(1007, 128);
            this.qRibbonPageStuManage.Text = "学生管理";
            // 
            // qRibbonPanelStuOne
            // 
            this.qRibbonPanelStuOne.Items.Add(this.qRibbonItemStuTree);
            this.qRibbonPanelStuOne.Items.Add(this.qRibbonItemStuSelect);
            this.qRibbonPanelStuOne.Items.Add(this.qRibbonItemStuTreeClose);
            this.qRibbonPanelStuOne.Title = "功能";
            // 
            // qRibbonItemStuTree
            // 
            this.qRibbonItemStuTree.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuTree.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuTree.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuTree.Icon")));
            this.qRibbonItemStuTree.Title = "菜单栏";
            this.qRibbonItemStuTree.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuTree_ItemActivated);
            // 
            // qRibbonItemStuSelect
            // 
            this.qRibbonItemStuSelect.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuSelect.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuSelect.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuSelect.Icon")));
            this.qRibbonItemStuSelect.Title = "查询";
            this.qRibbonItemStuSelect.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuSelect_ItemActivated);
            // 
            // qRibbonItemStuTreeClose
            // 
            this.qRibbonItemStuTreeClose.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuTreeClose.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuTreeClose.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuTreeClose.Icon")));
            this.qRibbonItemStuTreeClose.Title = "关闭";
            this.qRibbonItemStuTreeClose.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuTreeClose_ItemActivated);
            // 
            // qRibbonPanelStuTwo
            // 
            this.qRibbonPanelStuTwo.Items.Add(this.qRibbonItemClaNew);
            this.qRibbonPanelStuTwo.Items.Add(this.qRibbonItemClaDelete);
            this.qRibbonPanelStuTwo.Items.Add(this.qRibbonItemStuNew);
            this.qRibbonPanelStuTwo.Items.Add(this.qRibbonItemStuDelete);
            this.qRibbonPanelStuTwo.Title = "操作";
            // 
            // qRibbonItemClaNew
            // 
            this.qRibbonItemClaNew.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemClaNew.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemClaNew.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemClaNew.Icon")));
            this.qRibbonItemClaNew.Title = "新建班级";
            this.qRibbonItemClaNew.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemClaNew_ItemActivated);
            // 
            // qRibbonItemClaDelete
            // 
            this.qRibbonItemClaDelete.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemClaDelete.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemClaDelete.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemClaDelete.Icon")));
            this.qRibbonItemClaDelete.Title = "删除班级";
            this.qRibbonItemClaDelete.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemClaDelete_ItemActivated);
            // 
            // qRibbonItemStuNew
            // 
            this.qRibbonItemStuNew.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuNew.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuNew.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuNew.Icon")));
            this.qRibbonItemStuNew.Title = "添加学生";
            this.qRibbonItemStuNew.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuNew_ItemActivated);
            // 
            // qRibbonItemStuDelete
            // 
            this.qRibbonItemStuDelete.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuDelete.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuDelete.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuDelete.Icon")));
            this.qRibbonItemStuDelete.Title = "删除学生";
            this.qRibbonItemStuDelete.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuDelete_ItemActivated);
            // 
            // qRibbonPanelStuThree
            // 
            this.qRibbonPanelStuThree.Items.Add(this.qRibbonItemStuStart);
            this.qRibbonPanelStuThree.Items.Add(this.qRibbonItemStuLast);
            this.qRibbonPanelStuThree.Items.Add(this.qRibbonItemStuNext);
            this.qRibbonPanelStuThree.Items.Add(this.qRibbonItemStuEnd);
            this.qRibbonPanelStuThree.Title = "选择";
            // 
            // qRibbonItemStuStart
            // 
            this.qRibbonItemStuStart.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuStart.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuStart.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuStart.Icon")));
            this.qRibbonItemStuStart.Title = "起始";
            this.qRibbonItemStuStart.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuStart_ItemActivated);
            // 
            // qRibbonItemStuLast
            // 
            this.qRibbonItemStuLast.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuLast.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuLast.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuLast.Icon")));
            this.qRibbonItemStuLast.Title = "上一个";
            this.qRibbonItemStuLast.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuLast_ItemActivated);
            // 
            // qRibbonItemStuNext
            // 
            this.qRibbonItemStuNext.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuNext.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuNext.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuNext.Icon")));
            this.qRibbonItemStuNext.Title = "下一个";
            this.qRibbonItemStuNext.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuNext_ItemActivated);
            // 
            // qRibbonItemStuEnd
            // 
            this.qRibbonItemStuEnd.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuEnd.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuEnd.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuEnd.Icon")));
            this.qRibbonItemStuEnd.Title = "末尾";
            this.qRibbonItemStuEnd.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuEnd_ItemActivated);
            // 
            // qRibbonPanelStuFive
            // 
            this.qRibbonPanelStuFive.Items.Add(this.qRibbonItemStuExport);
            this.qRibbonPanelStuFive.Items.Add(this.qRibbonItemStuBack);
            this.qRibbonPanelStuFive.Title = "文件";
            // 
            // qRibbonItemStuExport
            // 
            this.qRibbonItemStuExport.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuExport.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuExport.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuExport.Icon")));
            this.qRibbonItemStuExport.Title = "导出";
            this.qRibbonItemStuExport.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuExport_ItemActivated);
            // 
            // qRibbonItemStuBack
            // 
            this.qRibbonItemStuBack.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemStuBack.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemStuBack.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemStuBack.Icon")));
            this.qRibbonItemStuBack.Title = "退出";
            this.qRibbonItemStuBack.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemStuBack_ItemActivated);
            // 
            // qRibbonPageExperManage
            // 
            this.qRibbonPageExperManage.ButtonOrder = 2;
            this.qRibbonPageExperManage.ColorScheme.RibbonPageBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qRibbonPageExperManage.ColorScheme.RibbonPageBackground2.SetColor("VistaBlack", System.Drawing.SystemColors.GradientActiveCaption, false);
            this.qRibbonPageExperManage.Items.Add(this.qRibbonPanelExperOne);
            this.qRibbonPageExperManage.Items.Add(this.qRibbonPanelTwo);
            this.qRibbonPageExperManage.Items.Add(this.qRibbonPanelExperThree);
            this.qRibbonPageExperManage.Location = new System.Drawing.Point(2, 34);
            this.qRibbonPageExperManage.Name = "qRibbonPageExperManage";
            this.qRibbonPageExperManage.PersistGuid = new System.Guid("d69329fd-d638-4adf-8fa5-31071301a877");
            this.qRibbonPageExperManage.Size = new System.Drawing.Size(1007, 128);
            this.qRibbonPageExperManage.Text = "实验管理";
            // 
            // qRibbonPanelExperOne
            // 
            this.qRibbonPanelExperOne.Items.Add(this.qRibbonItemExperTree);
            this.qRibbonPanelExperOne.Items.Add(this.qRibbonItemExperSelect);
            this.qRibbonPanelExperOne.Items.Add(this.qRibbonItemExperClose);
            this.qRibbonPanelExperOne.Title = "功能";
            // 
            // qRibbonItemExperTree
            // 
            this.qRibbonItemExperTree.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperTree.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperTree.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperTree.Icon")));
            this.qRibbonItemExperTree.Title = "菜单栏";
            this.qRibbonItemExperTree.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperTree_ItemActivated);
            // 
            // qRibbonItemExperSelect
            // 
            this.qRibbonItemExperSelect.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperSelect.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperSelect.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperSelect.Icon")));
            this.qRibbonItemExperSelect.Title = "查询";
            this.qRibbonItemExperSelect.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperSelect_ItemActivated);
            // 
            // qRibbonItemExperClose
            // 
            this.qRibbonItemExperClose.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperClose.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperClose.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperClose.Icon")));
            this.qRibbonItemExperClose.Title = "关闭";
            this.qRibbonItemExperClose.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperClose_ItemActivated);
            // 
            // qRibbonPanelTwo
            // 
            this.qRibbonPanelTwo.Items.Add(this.qRibbonItemExperStart);
            this.qRibbonPanelTwo.Items.Add(this.qRibbonItemExperLast);
            this.qRibbonPanelTwo.Items.Add(this.qRibbonItemExperNext);
            this.qRibbonPanelTwo.Items.Add(this.qRibbonItemExperEnd);
            this.qRibbonPanelTwo.Title = "选择";
            // 
            // qRibbonItemExperStart
            // 
            this.qRibbonItemExperStart.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperStart.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperStart.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperStart.Icon")));
            this.qRibbonItemExperStart.Title = "起始";
            this.qRibbonItemExperStart.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperStart_ItemActivated);
            // 
            // qRibbonItemExperLast
            // 
            this.qRibbonItemExperLast.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperLast.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperLast.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperLast.Icon")));
            this.qRibbonItemExperLast.Title = "上一个";
            this.qRibbonItemExperLast.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperLast_ItemActivated);
            // 
            // qRibbonItemExperNext
            // 
            this.qRibbonItemExperNext.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperNext.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperNext.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperNext.Icon")));
            this.qRibbonItemExperNext.Title = "下一个";
            this.qRibbonItemExperNext.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperNext_ItemActivated);
            // 
            // qRibbonItemExperEnd
            // 
            this.qRibbonItemExperEnd.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperEnd.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperEnd.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperEnd.Icon")));
            this.qRibbonItemExperEnd.Title = "末尾";
            this.qRibbonItemExperEnd.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperEnd_ItemActivated);
            // 
            // qRibbonPanelExperThree
            // 
            this.qRibbonPanelExperThree.Items.Add(this.qRibbonItemExperNew);
            this.qRibbonPanelExperThree.Items.Add(this.qRibbonItemExperDelete);
            this.qRibbonPanelExperThree.Items.Add(this.qRibbonItemExperAlter);
            this.qRibbonPanelExperThree.Items.Add(this.qRibbonItemExperBack);
            this.qRibbonPanelExperThree.Title = "操作";
            // 
            // qRibbonItemExperNew
            // 
            this.qRibbonItemExperNew.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperNew.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperNew.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperNew.Icon")));
            this.qRibbonItemExperNew.Title = "添加实验";
            this.qRibbonItemExperNew.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperNew_ItemActivated);
            // 
            // qRibbonItemExperDelete
            // 
            this.qRibbonItemExperDelete.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperDelete.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperDelete.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperDelete.Icon")));
            this.qRibbonItemExperDelete.Title = "删除实验";
            this.qRibbonItemExperDelete.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperDelete_ItemActivated);
            // 
            // qRibbonItemExperAlter
            // 
            this.qRibbonItemExperAlter.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperAlter.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperAlter.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperAlter.Icon")));
            this.qRibbonItemExperAlter.Title = "修改实验";
            this.qRibbonItemExperAlter.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperAlter_ItemActivated);
            // 
            // qRibbonItemExperBack
            // 
            this.qRibbonItemExperBack.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemExperBack.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemExperBack.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemExperBack.Icon")));
            this.qRibbonItemExperBack.Title = "退出";
            this.qRibbonItemExperBack.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemExperBack_ItemActivated);
            // 
            // qRibbonPageHelp
            // 
            this.qRibbonPageHelp.ButtonOrder = 4;
            this.qRibbonPageHelp.ColorScheme.RibbonPageBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qRibbonPageHelp.ColorScheme.RibbonPageBackground2.SetColor("VistaBlack", System.Drawing.SystemColors.GradientActiveCaption, false);
            this.qRibbonPageHelp.Items.Add(this.qRibbonPanel1);
            this.qRibbonPageHelp.Location = new System.Drawing.Point(2, 34);
            this.qRibbonPageHelp.Name = "qRibbonPageHelp";
            this.qRibbonPageHelp.PersistGuid = new System.Guid("4c334491-7cb2-40f1-92d3-dcf4abe0a912");
            this.qRibbonPageHelp.Size = new System.Drawing.Size(1007, 128);
            this.qRibbonPageHelp.Text = "帮助";
            // 
            // qRibbonPageGradeManage
            // 
            this.qRibbonPageGradeManage.ButtonOrder = 3;
            this.qRibbonPageGradeManage.ColorScheme.RibbonPageBackground1.SetColor("VistaBlack", System.Drawing.Color.White, false);
            this.qRibbonPageGradeManage.ColorScheme.RibbonPageBackground2.SetColor("VistaBlack", System.Drawing.SystemColors.GradientActiveCaption, false);
            this.qRibbonPageGradeManage.Items.Add(this.qRibbonPanelGrdeOne);
            this.qRibbonPageGradeManage.Items.Add(this.qRibbonPanelGradeTwo);
            this.qRibbonPageGradeManage.Items.Add(this.qRibbonPanelGradeThree);
            this.qRibbonPageGradeManage.Location = new System.Drawing.Point(2, 34);
            this.qRibbonPageGradeManage.Name = "qRibbonPageGradeManage";
            this.qRibbonPageGradeManage.PersistGuid = new System.Guid("82719bb0-2635-45d1-b2ab-a92ba1a04642");
            this.qRibbonPageGradeManage.Size = new System.Drawing.Size(1007, 128);
            this.qRibbonPageGradeManage.Text = "成绩管理";
            // 
            // qRibbonPanelGrdeOne
            // 
            this.qRibbonPanelGrdeOne.Items.Add(this.qRibbonItemGradeTree);
            this.qRibbonPanelGrdeOne.Items.Add(this.qRibbonItemGradeSelect);
            this.qRibbonPanelGrdeOne.Items.Add(this.qRibbonItemGradeClose);
            this.qRibbonPanelGrdeOne.Title = "功能";
            // 
            // qRibbonItemGradeTree
            // 
            this.qRibbonItemGradeTree.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeTree.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeTree.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeTree.Icon")));
            this.qRibbonItemGradeTree.Title = "菜单栏";
            this.qRibbonItemGradeTree.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeTree_ItemActivated);
            // 
            // qRibbonItemGradeSelect
            // 
            this.qRibbonItemGradeSelect.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeSelect.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeSelect.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeSelect.Icon")));
            this.qRibbonItemGradeSelect.Title = "查询";
            this.qRibbonItemGradeSelect.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeSelect_ItemActivated);
            // 
            // qRibbonItemGradeClose
            // 
            this.qRibbonItemGradeClose.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeClose.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeClose.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeClose.Icon")));
            this.qRibbonItemGradeClose.Title = "关闭";
            this.qRibbonItemGradeClose.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeClose_ItemActivated);
            // 
            // qRibbonPanelGradeTwo
            // 
            this.qRibbonPanelGradeTwo.Items.Add(this.qRibbonItemGradeStart);
            this.qRibbonPanelGradeTwo.Items.Add(this.qRibbonItemGradeLast);
            this.qRibbonPanelGradeTwo.Items.Add(this.qRibbonItemGradeNext);
            this.qRibbonPanelGradeTwo.Items.Add(this.qRibbonItemGradeEnd);
            this.qRibbonPanelGradeTwo.Title = "选择";
            // 
            // qRibbonItemGradeStart
            // 
            this.qRibbonItemGradeStart.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeStart.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeStart.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeStart.Icon")));
            this.qRibbonItemGradeStart.Title = "起始";
            this.qRibbonItemGradeStart.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeStart_ItemActivated);
            // 
            // qRibbonItemGradeLast
            // 
            this.qRibbonItemGradeLast.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeLast.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeLast.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeLast.Icon")));
            this.qRibbonItemGradeLast.Title = "上一个";
            this.qRibbonItemGradeLast.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeLast_ItemActivated);
            // 
            // qRibbonItemGradeNext
            // 
            this.qRibbonItemGradeNext.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeNext.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeNext.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeNext.Icon")));
            this.qRibbonItemGradeNext.Title = "下一个";
            this.qRibbonItemGradeNext.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeNext_ItemActivated);
            // 
            // qRibbonItemGradeEnd
            // 
            this.qRibbonItemGradeEnd.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeEnd.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeEnd.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeEnd.Icon")));
            this.qRibbonItemGradeEnd.Title = "末尾";
            this.qRibbonItemGradeEnd.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeEnd_ItemActivated);
            // 
            // qRibbonPanelGradeThree
            // 
            this.qRibbonPanelGradeThree.Items.Add(this.qRibbonItemGradeExport);
            this.qRibbonPanelGradeThree.Items.Add(this.qRibbonItemGradeBack);
            this.qRibbonPanelGradeThree.Title = "文件";
            // 
            // qRibbonItemGradeExport
            // 
            this.qRibbonItemGradeExport.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeExport.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeExport.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeExport.Icon")));
            this.qRibbonItemGradeExport.Title = "导出";
            // 
            // qRibbonItemGradeBack
            // 
            this.qRibbonItemGradeBack.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItemGradeBack.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItemGradeBack.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItemGradeBack.Icon")));
            this.qRibbonItemGradeBack.Title = "退出";
            this.qRibbonItemGradeBack.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItemGradeBack_ItemActivated);
            // 
            // dockPanelMain
            // 
            this.dockPanelMain.ActiveAutoHideContent = null;
            this.dockPanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanelMain.DockBackColor = System.Drawing.SystemColors.Control;
            this.dockPanelMain.Location = new System.Drawing.Point(0, 166);
            this.dockPanelMain.Name = "dockPanelMain";
            this.dockPanelMain.Size = new System.Drawing.Size(1013, 295);
            dockPanelGradient1.EndColor = System.Drawing.SystemColors.ControlLight;
            dockPanelGradient1.StartColor = System.Drawing.SystemColors.ControlLight;
            autoHideStripSkin1.DockStripGradient = dockPanelGradient1;
            tabGradient1.EndColor = System.Drawing.SystemColors.Control;
            tabGradient1.StartColor = System.Drawing.SystemColors.Control;
            tabGradient1.TextColor = System.Drawing.SystemColors.ControlDarkDark;
            autoHideStripSkin1.TabGradient = tabGradient1;
            autoHideStripSkin1.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            dockPanelSkin1.AutoHideStripSkin = autoHideStripSkin1;
            tabGradient2.EndColor = System.Drawing.SystemColors.ControlLightLight;
            tabGradient2.StartColor = System.Drawing.SystemColors.ControlLightLight;
            tabGradient2.TextColor = System.Drawing.SystemColors.ControlText;
            dockPaneStripGradient1.ActiveTabGradient = tabGradient2;
            dockPanelGradient2.EndColor = System.Drawing.SystemColors.Control;
            dockPanelGradient2.StartColor = System.Drawing.SystemColors.Control;
            dockPaneStripGradient1.DockStripGradient = dockPanelGradient2;
            tabGradient3.EndColor = System.Drawing.SystemColors.ControlLight;
            tabGradient3.StartColor = System.Drawing.SystemColors.ControlLight;
            tabGradient3.TextColor = System.Drawing.SystemColors.ControlText;
            dockPaneStripGradient1.InactiveTabGradient = tabGradient3;
            dockPaneStripSkin1.DocumentGradient = dockPaneStripGradient1;
            dockPaneStripSkin1.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            tabGradient4.EndColor = System.Drawing.SystemColors.ActiveCaption;
            tabGradient4.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            tabGradient4.StartColor = System.Drawing.SystemColors.GradientActiveCaption;
            tabGradient4.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            dockPaneStripToolWindowGradient1.ActiveCaptionGradient = tabGradient4;
            tabGradient5.EndColor = System.Drawing.SystemColors.Control;
            tabGradient5.StartColor = System.Drawing.SystemColors.Control;
            tabGradient5.TextColor = System.Drawing.SystemColors.ControlText;
            dockPaneStripToolWindowGradient1.ActiveTabGradient = tabGradient5;
            dockPanelGradient3.EndColor = System.Drawing.SystemColors.ControlLight;
            dockPanelGradient3.StartColor = System.Drawing.SystemColors.ControlLight;
            dockPaneStripToolWindowGradient1.DockStripGradient = dockPanelGradient3;
            tabGradient6.EndColor = System.Drawing.SystemColors.InactiveCaption;
            tabGradient6.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            tabGradient6.StartColor = System.Drawing.SystemColors.GradientInactiveCaption;
            tabGradient6.TextColor = System.Drawing.SystemColors.InactiveCaptionText;
            dockPaneStripToolWindowGradient1.InactiveCaptionGradient = tabGradient6;
            tabGradient7.EndColor = System.Drawing.Color.Transparent;
            tabGradient7.StartColor = System.Drawing.Color.Transparent;
            tabGradient7.TextColor = System.Drawing.SystemColors.ControlDarkDark;
            dockPaneStripToolWindowGradient1.InactiveTabGradient = tabGradient7;
            dockPaneStripSkin1.ToolWindowGradient = dockPaneStripToolWindowGradient1;
            dockPanelSkin1.DockPaneStripSkin = dockPaneStripSkin1;
            this.dockPanelMain.Skin = dockPanelSkin1;
            this.dockPanelMain.TabIndex = 13;
            // 
            // qRibbonItem5
            // 
            this.qRibbonItem5.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItem5.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItem5.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem5.Icon")));
            this.qRibbonItem5.Title = "查询";
            // 
            // qRibbonItem4
            // 
            this.qRibbonItem4.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItem4.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItem4.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem4.Icon")));
            this.qRibbonItem4.Title = "新建";
            // 
            // qCompositeImage
            // 
            this.qCompositeImage.Image = global::感知层网络实验自动检查评分系统.Properties.Resources.LOGO1;
            // 
            // qRibbonPanel1
            // 
            this.qRibbonPanel1.Items.Add(this.qRibbonItem2);
            this.qRibbonPanel1.Title = "帮助";
            // 
            // qRibbonItem2
            // 
            this.qRibbonItem2.Configuration.Direction = Qios.DevSuite.Components.QPartDirection.Vertical;
            this.qRibbonItem2.Configuration.IconConfiguration.IconSize = new System.Drawing.Size(48, 48);
            this.qRibbonItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("qRibbonItem2.Icon")));
            this.qRibbonItem2.Title = "联系作者";
            this.qRibbonItem2.ItemActivated += new Qios.DevSuite.Components.QCompositeEventHandler(this.qRibbonItem2_ItemActivated);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 487);
            this.Controls.Add(this.dockPanelMain);
            this.Controls.Add(this.qRibbon);
            this.Controls.Add(this.statusStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "感知层网络实验自动检查评分系统";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbon)).EndInit();
            this.qRibbon.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPage1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageStuManage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageExperManage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageHelp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qRibbonPageGradeManage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelUser;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelEmpty1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelIp;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelEmpty2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLastLoginTime;
        private Qios.DevSuite.Components.QTranslucentWindowComponent qTranslucentWindowComponent;
        private Qios.DevSuite.Components.Ribbon.QRibbon qRibbon;
        private Qios.DevSuite.Components.Ribbon.QRibbonPage qRibbonPageStuManage;
        private WeifenLuo.WinFormsUI.Docking.DockPanel dockPanelMain;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelStuOne;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuTree;
        private Qios.DevSuite.Components.Ribbon.QRibbonPage qRibbonPage1;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelHomeOne;
        private Qios.DevSuite.Components.QCompositeImage qCompositeImage;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelHomeTwo;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemHomeOpen;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemHomeClose;
        private Qios.DevSuite.Components.QCompositeItem qCompositeItem2;
        private Qios.DevSuite.Components.Ribbon.QRibbonPage qRibbonPageExperManage;
        private Qios.DevSuite.Components.Ribbon.QRibbonPage qRibbonPageHelp;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuSelect;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelStuTwo;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemClaNew;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemClaDelete;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem5;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuNew;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuDelete;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelStuThree;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuTreeClose;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuStart;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuLast;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuNext;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuEnd;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelStuFive;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuExport;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemStuBack;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem4;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelExperOne;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperTree;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperSelect;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperClose;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelLoginTime;
        private System.Windows.Forms.SaveFileDialog saveFileDialogExcel;
        private Qios.DevSuite.Components.Ribbon.QRibbonPage qRibbonPageGradeManage;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelGrdeOne;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeTree;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeSelect;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeClose;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelGradeTwo;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeStart;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeLast;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeNext;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeEnd;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelGradeThree;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeExport;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemGradeBack;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelTwo;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperStart;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperLast;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperNext;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperEnd;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanelExperThree;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperNew;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperDelete;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperAlter;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItemExperBack;
        private Qios.DevSuite.Components.Ribbon.QRibbonPanel qRibbonPanel1;
        private Qios.DevSuite.Components.Ribbon.QRibbonItem qRibbonItem2;
    }
}

