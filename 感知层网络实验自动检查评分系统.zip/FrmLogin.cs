﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using 感知层网络实验自动检查评分系统.UserInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmLogin : ComponentFactory.Krypton.Toolkit.KryptonForm
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            //采用局域网连接方式
            string user_id;
            string user_pwd;
            string ip_addr;
            string nowTime;
            string mac_addr;
            user_id = TxtUser.Text.Trim();
            user_pwd = TxtPwd.Text.Trim();

            GetSysInfo getSysInfo = new GetSysInfo();       //实例化连接数据库的类的对象
            ip_addr = getSysInfo.getIpAddr()[0];
            nowTime = getSysInfo.getNowTime();
            mac_addr = getSysInfo.getMacAddr();

            UserInfoWebService.UserInfoWebServiceSoapClient userInfoWebSer = new UserInfoWebServiceSoapClient();
            string key = userInfoWebSer.Login(user_id, user_pwd, ip_addr, mac_addr, nowTime);

            if (DateTime.TryParse(key, out _))
            {
                FrmMain.user_id = user_id;
                FrmMain.user_ip = ip_addr;
                FrmMain.last_time = key;
                FrmMain.login_time = getSysInfo.getNowTime();
                this.DialogResult = System.Windows.Forms.DialogResult.Yes;
            }
            else
            {
                MessageBox.Show(key, "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            /*          采用本地连接方式
            string user_id;
            string user_pwd;
            user_id = TxtUser.Text;
            user_pwd = TxtPwd.Text;

            DBConnect dbConn = new DBConnect();       //实例化连接数据库的类的对象
            string key = dbConn.Login(user_id, user_pwd);

            if (!key.Equals(""))
            {
                MessageBox.Show(key, "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                FrmMain.user_id = user_id;
                FrmMain.user_ip = dbConn.getIpAddr()[0];
                this.DialogResult = System.Windows.Forms.DialogResult.Yes;
            }
            */
        }

        private void LkLbRegister_LinkClicked(object sender, EventArgs e)
        {
            FrmRegister frm = new FrmRegister();
            frm.ShowDialog();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LkLbForget_LinkClicked(object sender, EventArgs e)
        {
            FrmForgetPwd frm = new FrmForgetPwd();
            frm.ShowDialog();
        }

        private void BtnSetting_Click(object sender, EventArgs e)
        {
            FrmSetting frm = new FrmSetting();
            frm.ShowDialog();
        }
    }
}