﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmSearchClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.ComChoise = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            this.BtSearch = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.TxtClaorStu = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.LbClaorStu = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ComChoise)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.ComChoise);
            this.kryptonPanel.Controls.Add(this.BtSearch);
            this.kryptonPanel.Controls.Add(this.TxtClaorStu);
            this.kryptonPanel.Controls.Add(this.LbClaorStu);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(389, 307);
            this.kryptonPanel.TabIndex = 0;
            // 
            // ComChoise
            // 
            this.ComChoise.DropDownWidth = 178;
            this.ComChoise.Items.AddRange(new object[] {
            "班级查找",
            "学生查找"});
            this.ComChoise.Location = new System.Drawing.Point(64, 33);
            this.ComChoise.Name = "ComChoise";
            this.ComChoise.Size = new System.Drawing.Size(258, 25);
            this.ComChoise.TabIndex = 5;
            this.ComChoise.Text = "班级查找";
            // 
            // BtSearch
            // 
            this.BtSearch.Location = new System.Drawing.Point(64, 152);
            this.BtSearch.Name = "BtSearch";
            this.BtSearch.Size = new System.Drawing.Size(258, 68);
            this.BtSearch.TabIndex = 2;
            this.BtSearch.Values.Text = "查找";
            this.BtSearch.Click += new System.EventHandler(this.BtSearch_Click);
            // 
            // TxtClaorStu
            // 
            this.TxtClaorStu.Location = new System.Drawing.Point(152, 90);
            this.TxtClaorStu.Name = "TxtClaorStu";
            this.TxtClaorStu.Size = new System.Drawing.Size(170, 27);
            this.TxtClaorStu.TabIndex = 1;
            // 
            // LbClaorStu
            // 
            this.LbClaorStu.Location = new System.Drawing.Point(64, 93);
            this.LbClaorStu.Name = "LbClaorStu";
            this.LbClaorStu.Size = new System.Drawing.Size(82, 24);
            this.LbClaorStu.TabIndex = 0;
            this.LbClaorStu.Values.Text = "班级/学号";
            // 
            // FrmSearchClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 307);
            this.Controls.Add(this.kryptonPanel);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmSearchClass";
            this.Text = "FrmSearchClass";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ComChoise)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox ComChoise;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtClaorStu;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbClaorStu;
    }
}

