﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmSetting : ComponentFactory.Krypton.Toolkit.KryptonForm
    {
        public FrmSetting()
        {
            InitializeComponent();
        }

    }
}