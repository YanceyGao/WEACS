﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace 感知层网络实验自动检查评分系统
{
    class GetSysInfo
    {
        DBConnect Connect = new DBConnect();

        public string getNowTime()
        {
            string nowTime = DateTime.Now.ToString();
            return nowTime;
        }

        public string getMacAddr()
        {
            try
            {
                NetworkInterface[] networkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
                foreach (NetworkInterface network in networkInterfaces)
                {
                    return BitConverter.ToString(network.GetPhysicalAddress().GetAddressBytes());
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            return "00-00-00-00-00-00";
        }

        public string[] getIpAddr()
        {
            string[] ip_addr = new string[0x0f];       //最大IP地址数量为16
            string hostName = Dns.GetHostName();        //获取本地主机名
            IPHostEntry IpEntry = Dns.GetHostEntry(hostName);   //通过主机名解析IP地址
            int count = 0;

            for (int i = IpEntry.AddressList.Length - 1; i >= 0; i--)
            {
                //从IP地址列表中筛选出IPv4类型的地址
                //AddressFamily.InterNetwork表示此IP为IPv4
                //AddressFamily.InterNetworkV6表示此IP为IPv6
                if (IpEntry.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                {
                    ip_addr[count] = IpEntry.AddressList[i].ToString();
                    count++;
                }
            }

            return ip_addr;
        }

        public string[] GetClass()
        {
            DataTable dtClass;
            int classCount = 0;
            string tempStr = "Cla_";
            string[] ClassData = new string[0x0f];

            //拼接T-SQL语句
            string strSQL = "select * from syscolumns where id = object_id('Class');";
            dtClass = Connect.SqlConnect(strSQL);
            for(int i = 0; i < dtClass.Rows.Count; i++)
            {
                if (dtClass.Rows[i].ItemArray[0].ToString() == "Cno")
                    continue;
                ClassData[classCount] = dtClass.Rows[i].ItemArray[0].ToString();

                ClassData[classCount] = ClassData[classCount].Replace(tempStr, "");
                classCount++;
            }

            return ClassData;
        }

        //public string[] GetStuInfo()
        //{
        //    DataTable dtStuInfo;
        //    string[] stuInfo = new string[0xff];
        //    int stuCount = 0;

        //    string strSQL = "select * from ";

        //    for(int i = 0; i < dtStuInfo.Rows.Count; i++)
        //    {

        //    }


        //}

        public int GetExper()
        {
            DataTable dtExper;
            int experCount = 0;
            string tempStr = "Cla_";
            string[] ExperData = new string[0x0f];

            //拼接T-SQL语句
            string strSQL = "select * from syscolumns where id = object_id('Experiment');";
            dtExper = Connect.SqlConnect(strSQL);
            for (int i = 0; i < dtExper.Rows.Count; i++)
            {
                if (dtExper.Rows[i].ItemArray[0].ToString() == "Sno")
                    continue;

                experCount++;
            }

            return experCount;
        }
    }
}
