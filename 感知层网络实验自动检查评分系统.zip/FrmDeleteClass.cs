﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;
using 感知层网络实验自动检查评分系统.StuInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmDeleteClass : DockContent
    {
        public FrmDeleteClass()
        {
            InitializeComponent();
        }

        private void BtDelete_Click(object sender, EventArgs e)
        {
            String className = TxtClass.Text;

            StuInfoWebServiceSoapClient stu = new StuInfoWebServiceSoapClient();
            String ans = stu.deleteClass(className);

            if(ans == null)
            {
                LbAns.Text = "删除成功";
            }
            else
            {
                LbAns.Text = ans;
            }
        }
    }
}