﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmSearchExper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonLabelEnoorEname = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxEnoorEname = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonButtonSearch = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonLabelSearch = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonComboBoxSearch = new ComponentFactory.Krypton.Toolkit.KryptonComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboBoxSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.kryptonComboBoxSearch);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSearch);
            this.kryptonPanel.Controls.Add(this.kryptonButtonSearch);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEnoorEname);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEnoorEname);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(572, 418);
            this.kryptonPanel.TabIndex = 0;
            // 
            // kryptonLabelEnoorEname
            // 
            this.kryptonLabelEnoorEname.Location = new System.Drawing.Point(63, 130);
            this.kryptonLabelEnoorEname.Name = "kryptonLabelEnoorEname";
            this.kryptonLabelEnoorEname.Size = new System.Drawing.Size(131, 24);
            this.kryptonLabelEnoorEname.TabIndex = 0;
            this.kryptonLabelEnoorEname.Values.Text = "实验号/实验名：";
            // 
            // kryptonTextBoxEnoorEname
            // 
            this.kryptonTextBoxEnoorEname.Location = new System.Drawing.Point(200, 127);
            this.kryptonTextBoxEnoorEname.Name = "kryptonTextBoxEnoorEname";
            this.kryptonTextBoxEnoorEname.Size = new System.Drawing.Size(263, 27);
            this.kryptonTextBoxEnoorEname.TabIndex = 2;
            // 
            // kryptonButtonSearch
            // 
            this.kryptonButtonSearch.Location = new System.Drawing.Point(63, 197);
            this.kryptonButtonSearch.Name = "kryptonButtonSearch";
            this.kryptonButtonSearch.Size = new System.Drawing.Size(248, 50);
            this.kryptonButtonSearch.TabIndex = 3;
            this.kryptonButtonSearch.Values.Text = "查询";
            this.kryptonButtonSearch.Click += new System.EventHandler(this.kryptonButtonSearch_Click);
            // 
            // kryptonLabelSearch
            // 
            this.kryptonLabelSearch.Location = new System.Drawing.Point(102, 61);
            this.kryptonLabelSearch.Name = "kryptonLabelSearch";
            this.kryptonLabelSearch.Size = new System.Drawing.Size(92, 24);
            this.kryptonLabelSearch.TabIndex = 4;
            this.kryptonLabelSearch.Values.Text = "查询选择：";
            // 
            // kryptonComboBoxSearch
            // 
            this.kryptonComboBoxSearch.DropDownWidth = 263;
            this.kryptonComboBoxSearch.Items.AddRange(new object[] {
            "实验号查询",
            "实验名查询"});
            this.kryptonComboBoxSearch.Location = new System.Drawing.Point(200, 60);
            this.kryptonComboBoxSearch.Name = "kryptonComboBoxSearch";
            this.kryptonComboBoxSearch.Size = new System.Drawing.Size(263, 25);
            this.kryptonComboBoxSearch.TabIndex = 5;
            this.kryptonComboBoxSearch.Text = "实验号查询";
            // 
            // FrmSearchExper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 418);
            this.Controls.Add(this.kryptonPanel);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmSearchExper";
            this.Text = "FrmSearchExper";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonComboBoxSearch)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEnoorEname;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEnoorEname;
        private ComponentFactory.Krypton.Toolkit.KryptonComboBox kryptonComboBoxSearch;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSearch;
    }
}

