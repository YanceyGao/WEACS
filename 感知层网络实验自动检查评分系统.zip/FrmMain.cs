﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;

namespace 感知层网络实验自动检查评分系统
{

    public partial class FrmMain : ComponentFactory.Krypton.Toolkit.KryptonForm
    {
        public static string user_id;
        public static string user_ip;
        public static string last_time;
        public static string login_time;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            string txtUser = toolStripStatusLabelUser.Text + user_id;
            string txtIp = toolStripStatusLabelIp.Text + user_ip;
            string txtLastTime = toolStripStatusLabelLastLoginTime.Text + last_time;
            string txtNowTime = toolStripStatusLabelLoginTime.Text + login_time;
            
            toolStripStatusLabelUser.Text = txtUser;
            toolStripStatusLabelIp.Text = txtIp;
            toolStripStatusLabelLastLoginTime.Text = txtLastTime;
            toolStripStatusLabelLoginTime.Text = txtNowTime;

            FrmHome home = new FrmHome();
            home.Show(dockPanelMain);
        }
        /*已弃用
        private void SToolStripMenuItemSelectExperiment_Click(object sender, EventArgs e)
        {
            //FrmStuMenu.key = 1;
            FrmStuMenu menu = new FrmStuMenu();
            //打开停靠菜单
            menu.Show(dockPanelMain, DockState.DockLeft);
            //关闭欢迎页面
            foreach(Form frm in Application.OpenForms)
            {
                if(frm.Name == "FrmHome")
                {
                    frm.Close();
                    break;
                }
            }
            
            dockPanelMain.DockLeftPortion = 240;
        }

        private void SToolStripMenuItemStuInfo_Click(object sender, EventArgs e)
        {
            //FrmStuMenu.key = 2;
            FrmStuMenu menu = new FrmStuMenu();
            menu.Show(dockPanelMain, DockState.DockLeft);
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.Name == "FrmHome")
                {
                    frm.Close();
                    break;
                }
            }

            dockPanelMain.DockLeftPortion = 240;
        }
        */

        //Stu停靠菜单的打开
        private void qRibbonItemStuTree_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmStuMenu frm = new FrmStuMenu();
            //frm.key = 2;
            String name = frm.Name; //获取菜单窗体名称
            //检索有没有打开项
            foreach(DockContent item in dockPanelMain.Contents)
            {
                if(item.Name == name)
                {
                    item.Close();
                    break;
                }
            }

            frm.Show(dockPanelMain, DockState.DockLeft);
            dockPanelMain.DockLeftPortion = 240.0;
        }
        //Home界面的打开
        private void qRibbonItemHomeOpen_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmHome frm = new FrmHome();
            String name = frm.Name;

            foreach(DockContent item in dockPanelMain.Contents)
            {
                if(item.Name == name)
                {
                    return;
                }
            }
            frm.Show(dockPanelMain);
        }
        //Home界面的关闭
        private void qRibbonItemHomeClose_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            Form form = ActiveMdiChild;
            if(form != null)
                form.Close();

            //foreach(DockContent item in dockPanelMain.Contents)
            //{
            //    if(item.Name == "FrmHome")
            //    {
            //        item.Close();
            //        break;
            //    }
            //}
        }
        //Stu停靠菜单的关闭按钮
        private void qRibbonItemStuTreeClose_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            foreach(DockContent item in dockPanelMain.Contents)
            {
                if(item.Name == "FrmStuMenu")
                {
                    item.Close();
                    break;
                }
            }
        }
        //学生返回按钮
        private void qRibbonItemStuBack_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            //对于打开的停靠窗口进行判断，处于激活态的关闭
            foreach (DockContent item in dockPanelMain.Contents)
            {
                if (item.IsActivated)
                {
                    item.Close();
                    break;
                }
            }

        }
        //添加班级按钮
        private void qRibbonItemClaNew_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmAddClass frm = new FrmAddClass();
            frm.Text = "添加班级";
            frm.Show(dockPanelMain);
        }
        //删除班级按钮
        private void qRibbonItemClaDelete_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmDeleteClass frm = new FrmDeleteClass();
            frm.Text = "删除班级";
            frm.Show(dockPanelMain);
        }
        //查找学生按钮
        private void qRibbonItemStuSelect_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmSearchClass frm = new FrmSearchClass();
            frm.Text = "查找";
            frm.Show(dockPanelMain);
        }
        //添加学生按钮
        private void qRibbonItemStuNew_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmAddStu frm = new FrmAddStu();
            frm.Text = "添加学生";
            frm.Show(dockPanelMain);
        }
        //删除学生按钮
        private void qRibbonItemStuDelete_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmDeleteStu frm = new FrmDeleteStu();
            frm.Text = "删除学生";
            frm.Show(dockPanelMain);
        }
        //选中首行按钮
        private void qRibbonItemStuStart_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmStuInfo.key = 1;
        }
        //向上一行按钮
        private void qRibbonItemStuLast_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmStuInfo.key = 2;
        }
        //向下一行按钮
        private void qRibbonItemStuNext_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmStuInfo.key = 3;
        }
        //选中末行按钮
        private void qRibbonItemStuEnd_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmStuInfo.key = 4;
        }
        //学生信息导出按钮，暂时写不出来
        private void qRibbonItemStuExport_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {

        }
        //实验菜单按钮
        private void qRibbonItemExperTree_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmExperMenu frm = new FrmExperMenu();
            frm.Text = "实验菜单";
            //frm.key = 2;
            String name = frm.Name; //获取菜单窗体名称
            //检索有没有打开项
            foreach (DockContent item in dockPanelMain.Contents)
            {
                if (item.Name == name)
                {
                    item.Close();
                    break;
                }
            }

            frm.Show(dockPanelMain, DockState.DockLeft);
            dockPanelMain.DockLeftPortion = 240.0;
        }
        //实验菜单关闭按钮
        private void qRibbonItemExperClose_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            foreach (DockContent item in dockPanelMain.Contents)
            {
                if (item.Name == "FrmExperMenu")
                {
                    item.Close();
                    break;
                }
            }
        }
        //实验返回按钮
        private void qRibbonItemExperBack_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            //对于打开的停靠窗口进行判断，处于激活态的关闭
            foreach (DockContent item in dockPanelMain.Contents)
            {
                if (item.IsActivated)
                {
                    item.Close();
                    break;
                }
            }
        }
        //成绩返回按钮
        private void qRibbonItemGradeBack_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            //对于打开的停靠窗口进行判断，处于激活态的关闭
            foreach (DockContent item in dockPanelMain.Contents)
            {
                if (item.IsActivated)
                {
                    item.Close();
                    break;
                }
            }
        }
        //成绩菜单按钮
        private void qRibbonItemGradeTree_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmGradeMenu frm = new FrmGradeMenu();
            frm.Text = "成绩菜单";
            //frm.key = 2;
            String name = frm.Name; //获取菜单窗体名称
            //检索有没有打开项
            foreach (DockContent item in dockPanelMain.Contents)
            {
                if (item.Name == name)
                {
                    item.Close();
                    break;
                }
            }

            frm.Show(dockPanelMain, DockState.DockLeft);
            dockPanelMain.DockLeftPortion = 240.0;
        }
        //成绩菜单关闭
        private void qRibbonItemGradeClose_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            foreach (DockContent item in dockPanelMain.Contents)
            {
                if (item.Name == "FrmGradeMenu")
                {
                    item.Close();
                    break;
                }
            }
        }
        //成绩查询按钮
        private void qRibbonItemGradeSelect_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmSearchGrade frm = new FrmSearchGrade();
            frm.Text = "查找";
            frm.Show(dockPanelMain);
        }
        //成绩选行
        private void qRibbonItemGradeStart_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmGradeInfo.key = 1;
        }

        private void qRibbonItemGradeLast_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmGradeInfo.key = 2;
        }

        private void qRibbonItemGradeNext_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmGradeInfo.key = 3;
        }

        private void qRibbonItemGradeEnd_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmGradeInfo.key = 4;
        }
        //添加实验
        private void qRibbonItemExperNew_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmAddExper frm = new FrmAddExper();
            frm.Text = "添加实验";
            frm.Show(dockPanelMain);
        }
        //删除实验
        private void qRibbonItemExperDelete_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmDeleteExper frm = new FrmDeleteExper();
            frm.Text = "删除实验";
            frm.Show(dockPanelMain);
        }
        //查询实验
        private void qRibbonItemExperSelect_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmSearchExper frm = new FrmSearchExper();
            frm.Text = "查询实验";
            frm.Show(dockPanelMain);
        }
        //实验选行
        private void qRibbonItemExperStart_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmSearchExperAns.key = 1;
        }

        private void qRibbonItemExperLast_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmSearchExperAns.key = 2;
        }

        private void qRibbonItemExperNext_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmSearchExperAns.key = 3;
        }
        
        private void qRibbonItemExperEnd_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmSearchExperAns.key = 4;
        }
        //修改实验
        private void qRibbonItemExperAlter_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmAlterExper frm = new FrmAlterExper();
            frm.Text = "修改实验";
            frm.Show(dockPanelMain);
        }

        private void qRibbonItem2_ItemActivated(object sender, Qios.DevSuite.Components.QCompositeEventArgs e)
        {
            FrmHelp frm = new FrmHelp();
            frm.Text = "联系作者";
            frm.Show(dockPanelMain);

        }
    }
}