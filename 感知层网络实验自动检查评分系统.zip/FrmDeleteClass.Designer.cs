﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmDeleteClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.LbClass = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.TxtClass = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.LbAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.BtDelete = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.BtDelete);
            this.kryptonPanel.Controls.Add(this.LbAns);
            this.kryptonPanel.Controls.Add(this.TxtClass);
            this.kryptonPanel.Controls.Add(this.LbClass);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(389, 307);
            this.kryptonPanel.TabIndex = 0;
            // 
            // LbClass
            // 
            this.LbClass.Location = new System.Drawing.Point(54, 55);
            this.LbClass.Name = "LbClass";
            this.LbClass.Size = new System.Drawing.Size(44, 24);
            this.LbClass.TabIndex = 0;
            this.LbClass.Values.Text = "班级";
            // 
            // TxtClass
            // 
            this.TxtClass.Location = new System.Drawing.Point(169, 52);
            this.TxtClass.Name = "TxtClass";
            this.TxtClass.Size = new System.Drawing.Size(154, 27);
            this.TxtClass.TabIndex = 1;
            // 
            // LbAns
            // 
            this.LbAns.Location = new System.Drawing.Point(54, 208);
            this.LbAns.Name = "LbAns";
            this.LbAns.Size = new System.Drawing.Size(6, 2);
            this.LbAns.TabIndex = 2;
            this.LbAns.Values.Text = "";
            // 
            // BtDelete
            // 
            this.BtDelete.Location = new System.Drawing.Point(54, 116);
            this.BtDelete.Name = "BtDelete";
            this.BtDelete.Size = new System.Drawing.Size(269, 59);
            this.BtDelete.TabIndex = 3;
            this.BtDelete.Values.Text = "删除";
            this.BtDelete.Click += new System.EventHandler(this.BtDelete_Click);
            // 
            // FrmDeleteClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 307);
            this.Controls.Add(this.kryptonPanel);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmDeleteClass";
            this.Text = "FrmDeleteClass";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtDelete;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbAns;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtClass;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbClass;
    }
}

