﻿using Commons;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace 感知层网络实验自动检查评分系统
{
    class DBConnect
    {
        //创建连接
        private string ConStr = "Data Source=LAPTOP-1P7QJR2L;Initial Catalog=PEACS.Sys;Integrated Security=True";

        //创建连接数据库的方法
        public SqlConnection OpenConnect()
        {
            //判断连接是否打开
            SqlConnection conn = new SqlConnection(@ConStr);   //参数是连接数据库的字符串
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
            return conn;
        }

        //已舍弃，局域网实现
        /*
        public string ForgetPwd(string user_id)
        {
            DataTable dtTip;
            string tip;

            //拼接T-SQL语句
            string strSQL = "SELECT tip_pwd FROM UserInfo WHERE user_id = '" + user_id + "'";
            dtTip = SqlConnect(strSQL);
            tip = dtTip.Rows[0].ItemArray[0].ToString();

            return tip;
        }
        */

        /*已舍弃，通过局域网实现
        public string Login(string user_id, string user_pwd)
        {
            bool ip_key = false;
            string ipCode = "";
            string[] ipList = getIpAddr();
            DataTable dtSql;

            //密码解密
            user_pwd = EncodeHelper.AES_Encrypt(user_pwd);
            //拼接T-SQL语句
            string strSQL = "SELECT * FROM UserInfo WHERE user_id = '" + user_id + "' AND user_pwd = '" + user_pwd + "'";

            dtSql = SqlConnect(strSQL);

            if (dtSql == null || dtSql.Rows.Count <= 0)
            {
                return "用户名或密码错误";
            }

            if (dtSql.Rows[0].ItemArray[2].ToString() == "")
            {
                ip_key = true;
            }
            else
            {
                for (int i = 0; i < ipList.Length; i++)
                {
                    if (dtSql.Rows[0].ItemArray[2].ToString() == ipList[i])
                    {
                        ipCode = getIpAddr()[i];
                        ip_key = true;
                    }
                }
            }

            //则说明验证通过
            if (ip_key == true)
            {
                if (ipCode == "")
                    ipCode = ipList[0];
                string ipInsert = "update UserInfo set last_ip = '" + ipCode + "' where user_id = '" + user_id + "'";
                SqlConnect(ipInsert);
                return "";
            }

            return "IP地址受限，不允许在" + ipList[0] + "下登录账户";
        }
        */

        public DataTable SqlConnect(String strSQL)
        {
            DataTable dtSql = new DataTable();

            SqlConnection con = OpenConnect();      //调用对象中的打开数据库的方法
            SqlCommand comm = new SqlCommand(strSQL);  //实例化SqlCommand对象
            comm.Connection = con;
            comm.CommandType = CommandType.Text;
            comm.CommandText = strSQL;
            SqlDataAdapter msda;
            msda = new SqlDataAdapter(comm);
            msda.Fill(dtSql);
            con.Close();

            return dtSql;
        }

        /*已迁移至GetData类
        public string getNowTime()
        {
            string nowTime = DateTime.Now.ToString();
            return nowTime;
        }
        */
        /*已迁移至GetData类
        public string getMacAddr()
        {
            try
            {
                NetworkInterface[] networkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
                foreach(NetworkInterface network in networkInterfaces)
                {
                    return BitConverter.ToString(network.GetPhysicalAddress().GetAddressBytes());
                }
            }
            catch(Exception ex)
            {
                return ex.Message;
            }

            return "00-00-00-00-00-00";
        }
        */
        /*已迁移至GetData类
        public string[] getIpAddr()
        {
            string[] ip_addr = new string[0x0f];       //最大IP地址数量为16
            string hostName = Dns.GetHostName();        //获取本地主机名
            IPHostEntry IpEntry = Dns.GetHostEntry(hostName);   //通过主机名解析IP地址
            int count = 0;

            for (int i = IpEntry.AddressList.Length - 1; i >= 0; i--)
            {
                //从IP地址列表中筛选出IPv4类型的地址
                //AddressFamily.InterNetwork表示此IP为IPv4
                //AddressFamily.InterNetworkV6表示此IP为IPv6
                if (IpEntry.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                {
                    ip_addr[count] = IpEntry.AddressList[i].ToString();
                    count++;
                }
            }

            return ip_addr;
        }
        */

        /*已放弃使用，通过局域网实现
        public Exception Regisiter(string user_id, string user_pwd, string tip_pwd, string ip_addr, string mac_addr)
        {
            DataTable dtSql = new DataTable();
            Exception er = new Exception();

            //密码加密
            user_pwd = EncodeHelper.AES_Encrypt(user_pwd);

            //拼接T-SQL语句
            string strSQL = "insert into UserInfo values('" + user_id + "', '" + user_pwd + "', '" + ip_addr + "', '" + mac_addr + "', null, null, '" + tip_pwd +"')";

            try
            {
                SqlConnection con = OpenConnect();      //调用对象中的打开数据库的方法
                SqlCommand comm = new SqlCommand(strSQL);  //实例化SqlCommand对象
                comm.Connection = con;
                comm.CommandType = CommandType.Text;
                comm.CommandText = strSQL;
                SqlDataAdapter msda;
                msda = new SqlDataAdapter(comm);
                msda.Fill(dtSql);
                con.Close();
            }
            catch (Exception e)
            {
                return e;
            }
            return null;
        }
        */

    }
}
