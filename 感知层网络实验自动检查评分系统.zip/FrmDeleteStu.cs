﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using 感知层网络实验自动检查评分系统.StuInfoWebService;
using WeifenLuo.WinFormsUI.Docking;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmDeleteStu : DockContent
    {
        public FrmDeleteStu()
        {
            InitializeComponent();
        }

        private void kryptonButtonDeleteStu_Click(object sender, EventArgs e)
        {
            String Sno = kryptonTextBoxSno.Text;
            String Sna = kryptonTextBoxSna.Text;
            String Scla = kryptonTextBoxScla.Text;

            StuInfoWebServiceSoapClient stuInfoWebServiceSoapClient = new StuInfoWebServiceSoapClient();
            String ans = stuInfoWebServiceSoapClient.deleteStudent(Sno, Sna, Scla);

            if (ans == null)
            {
                kryptonLabelAns.Text = "删除成功";
            }
            else
            {
                kryptonLabelAns.Text = ans;
            }
        }
    }
}