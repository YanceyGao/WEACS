﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.TxtUser = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.TxtPwd = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.BtnLogin = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.BtnCancel = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.LkLbRegister = new ComponentFactory.Krypton.Toolkit.KryptonLinkLabel();
            this.LkLbForget = new ComponentFactory.Krypton.Toolkit.KryptonLinkLabel();
            this.LbUser = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbPwd = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.BtnSetting = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.SuspendLayout();
            // 
            // TxtUser
            // 
            this.TxtUser.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.TxtUser.Location = new System.Drawing.Point(222, 144);
            this.TxtUser.MaxLength = 12;
            this.TxtUser.Name = "TxtUser";
            this.TxtUser.Size = new System.Drawing.Size(192, 27);
            this.TxtUser.TabIndex = 0;
            // 
            // TxtPwd
            // 
            this.TxtPwd.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.TxtPwd.Location = new System.Drawing.Point(222, 190);
            this.TxtPwd.MaxLength = 12;
            this.TxtPwd.Name = "TxtPwd";
            this.TxtPwd.PasswordChar = '*';
            this.TxtPwd.Size = new System.Drawing.Size(192, 27);
            this.TxtPwd.TabIndex = 1;
            // 
            // BtnLogin
            // 
            this.BtnLogin.Location = new System.Drawing.Point(156, 248);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.Size = new System.Drawing.Size(118, 38);
            this.BtnLogin.TabIndex = 2;
            this.BtnLogin.Values.Text = "登录";
            this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.Location = new System.Drawing.Point(363, 248);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(118, 38);
            this.BtnCancel.TabIndex = 3;
            this.BtnCancel.Values.Text = "取消";
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // LkLbRegister
            // 
            this.LkLbRegister.Location = new System.Drawing.Point(420, 147);
            this.LkLbRegister.Name = "LkLbRegister";
            this.LkLbRegister.Size = new System.Drawing.Size(61, 24);
            this.LkLbRegister.TabIndex = 4;
            this.LkLbRegister.Values.Text = "注    册";
            this.LkLbRegister.LinkClicked += new System.EventHandler(this.LkLbRegister_LinkClicked);
            // 
            // LkLbForget
            // 
            this.LkLbForget.Location = new System.Drawing.Point(420, 193);
            this.LkLbForget.Name = "LkLbForget";
            this.LkLbForget.Size = new System.Drawing.Size(92, 24);
            this.LkLbForget.TabIndex = 5;
            this.LkLbForget.Values.Text = "忘记密码？";
            this.LkLbForget.LinkClicked += new System.EventHandler(this.LkLbForget_LinkClicked);
            // 
            // LbUser
            // 
            this.LbUser.Location = new System.Drawing.Point(156, 147);
            this.LbUser.Name = "LbUser";
            this.LbUser.Size = new System.Drawing.Size(60, 24);
            this.LbUser.TabIndex = 6;
            this.LbUser.Values.Text = "用户名";
            // 
            // LbPwd
            // 
            this.LbPwd.Location = new System.Drawing.Point(156, 193);
            this.LbPwd.Name = "LbPwd";
            this.LbPwd.Size = new System.Drawing.Size(61, 24);
            this.LbPwd.TabIndex = 7;
            this.LbPwd.Values.Text = "密    码";
            // 
            // BtnSetting
            // 
            this.BtnSetting.Location = new System.Drawing.Point(528, 321);
            this.BtnSetting.Name = "BtnSetting";
            this.BtnSetting.Size = new System.Drawing.Size(98, 38);
            this.BtnSetting.TabIndex = 8;
            this.BtnSetting.Values.Text = "设置";
            this.BtnSetting.Click += new System.EventHandler(this.BtnSetting_Click);
            // 
            // FrmLogin
            // 
            this.AcceptButton = this.BtnLogin;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::感知层网络实验自动检查评分系统.Properties.Resources._01;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(638, 371);
            this.Controls.Add(this.BtnSetting);
            this.Controls.Add(this.LbPwd);
            this.Controls.Add(this.LbUser);
            this.Controls.Add(this.LkLbForget);
            this.Controls.Add(this.LkLbRegister);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnLogin);
            this.Controls.Add(this.TxtPwd);
            this.Controls.Add(this.TxtUser);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "登录";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtUser;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtPwd;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnLogin;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnCancel;
        private ComponentFactory.Krypton.Toolkit.KryptonLinkLabel LkLbRegister;
        private ComponentFactory.Krypton.Toolkit.KryptonLinkLabel LkLbForget;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbUser;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbPwd;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnSetting;
    }
}

