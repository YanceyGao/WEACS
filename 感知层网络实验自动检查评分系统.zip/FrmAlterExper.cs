﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;
using 感知层网络实验自动检查评分系统.ExperInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmAlterExper : DockContent
    {
        //存储查询值
        String val = "";
        int key = -1;
        public FrmAlterExper()
        {
            InitializeComponent();
        }

        private void FrmAlterExper_Load(object sender, EventArgs e)
        {
            kryptonTextBoxPassCount.Enabled = false;
            kryptonTextBoxBetterCount.Enabled = false;
            kryptonTextBoxNotPassCount.Enabled = false;
        }

        private void kryptonButtonEnoSearch_Click(object sender, EventArgs e)
        {
            ExperInfoWebService.ExperInfoWebServiceSoapClient experInfoWebServiceSoapClient = new ExperInfoWebServiceSoapClient();
            String Eno = kryptonTextBoxEno.Text;
            DataTable data = experInfoWebServiceSoapClient.SelectExper(Eno, 1);

            if(data == null || data.Rows.Count == 0)
            {
                MessageBox.Show("请检查输入内容是否匹配", "ERROR", MessageBoxButtons.OK);
                return;
            }

            kryptonTextBoxEname.Text = data.Rows[0][1].ToString();
            kryptonTextBoxEcode.Text = data.Rows[0][2].ToString();
            kryptonTextBoxAnsPass.Text = data.Rows[0][3].ToString();
            kryptonTextBoxAnsBetter.Text = data.Rows[0][4].ToString();
            kryptonTextBoxPassCount.Text = data.Rows[0][6].ToString();
            kryptonTextBoxBetterCount.Text = data.Rows[0][7].ToString();
            kryptonTextBoxNotPassCount.Text = data.Rows[0][8].ToString();

            val = Eno;
            key = 0;

        }

        private void kryptonButtonEnameSearch_Click(object sender, EventArgs e)
        {
            ExperInfoWebService.ExperInfoWebServiceSoapClient experInfoWebServiceSoapClient = new ExperInfoWebServiceSoapClient();
            String Ename = kryptonTextBoxEname.Text;
            DataTable data = experInfoWebServiceSoapClient.SelectExper(Ename, 0);

            if (data == null || data.Rows.Count == 0)
            {
                MessageBox.Show("请检查输入内容是否匹配", "ERROR", MessageBoxButtons.OK);
                return;
            }

            kryptonTextBoxEno.Text = data.Rows[0][0].ToString();
            kryptonTextBoxEcode.Text = data.Rows[0][2].ToString();
            kryptonTextBoxAnsPass.Text = data.Rows[0][3].ToString();
            kryptonTextBoxAnsBetter.Text = data.Rows[0][4].ToString();
            kryptonTextBoxPassCount.Text = data.Rows[0][6].ToString();
            kryptonTextBoxBetterCount.Text = data.Rows[0][7].ToString();
            kryptonTextBoxNotPassCount.Text = data.Rows[0][8].ToString();

            val = Ename;
            key = 1;
        }

        private void kryptonButtonEnter_Click(object sender, EventArgs e)
        {
            ExperInfoWebServiceSoapClient experInfoWebServiceSoapClient = new ExperInfoWebServiceSoapClient();

            String Eno = kryptonTextBoxEno.Text;
            String Ename = kryptonTextBoxEname.Text;
            String Ecode = kryptonTextBoxEcode.Text;
            String EansPass = kryptonTextBoxAnsPass.Text;
            String EansBetter = kryptonTextBoxAnsBetter.Text;
  


            String ans = experInfoWebServiceSoapClient.alterExper(key, val, Eno, Ename, Ecode, EansPass, EansBetter);

            if(ans == null)
            {
                MessageBox.Show("修改成功", "SUCCESS", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show(ans, "ERROR", MessageBoxButtons.OK);
            }
        }

    }
}