﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Controls;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;
using 感知层网络实验自动检查评分系统.GradeWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmSearchGrade : DockContent
    {
        public FrmSearchGrade()
        {
            InitializeComponent();
        }

        private void BtSearch_Click(object sender, EventArgs e)
        {
            String key = ComChoise.Text;
            String val = TxtClaorStu.Text;
            GradeWebServiceSoapClient gradeWebServiceSoapClient = new GradeWebServiceSoapClient();

            if (key == "班级查找")
            {
                DataTable dataTable = gradeWebServiceSoapClient.SelectGrade(val);

                if(dataTable == null)
                {
                    MessageBox.Show("输入错误", "Error", MessageBoxButtons.OK);
                    return;
                }

                if (dataTable.Rows.Count == 0)
                {
                    MessageBox.Show("该班级不存在或班级中没有学生", "Warning", MessageBoxButtons.OK);
                    return;
                }

                FrmGradeInfo frm = new FrmGradeInfo();
                FrmGradeInfo.classNumber = val;
                frm.Text = val + "班";



                FrmMain main = (FrmMain)this.Parent.Parent;   //获取当前窗体的父窗体
                frm.MdiParent = main;           //设置子窗体的父窗体
                frm.DockHandler.Show(DockPanel);         //打开子窗体

            }
            else if (key == "学生查找")
            {
                DataTable dataTable = gradeWebServiceSoapClient.SelectGrade(val);

                if (dataTable == null)
                {
                    MessageBox.Show("输入错误", "Error", MessageBoxButtons.OK);
                    return;
                }

                if (dataTable.Rows.Count == 0)
                {
                    MessageBox.Show("该学生不存在，请检查输入是否正确", "Warning", MessageBoxButtons.OK);
                    return;
                }

                FrmGradeInfo frm = new FrmGradeInfo();
                FrmGradeInfo.val = dataTable;

                FrmMain main = (FrmMain)this.Parent.Parent;   //获取当前窗体的父窗体
                frm.MdiParent = main;           //设置子窗体的父窗体
                frm.DockHandler.Show(DockPanel);         //打开子窗体
            }
        }
    }
}