﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmHome : DockContent
    {
        public FrmHome()
        {
            InitializeComponent();
        }

        private void FrmHome_Load(object sender, EventArgs e)
        {
            LbWelcome.Text = "欢迎使用感知层网络实验自动检查评分系统！";

            DataHelper dataHelper = new DataHelper();
            String[] info = dataHelper.homeSysInfo();
            for(int i = 0; i < 36; i++)
            {
                kryptonLabelSYsInfo.Text = kryptonLabelSYsInfo.Text + info[i] + "\n";
            }
            
        }
    }
}