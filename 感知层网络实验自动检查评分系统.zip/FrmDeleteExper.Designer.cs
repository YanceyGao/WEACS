﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmDeleteExper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonButtonDeleteExper = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonLabelEno = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEname = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxEno = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEname = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.kryptonLabelAns);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEname);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEno);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEname);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEno);
            this.kryptonPanel.Controls.Add(this.kryptonButtonDeleteExper);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(675, 441);
            this.kryptonPanel.TabIndex = 0;
            // 
            // kryptonButtonDeleteExper
            // 
            this.kryptonButtonDeleteExper.Location = new System.Drawing.Point(83, 215);
            this.kryptonButtonDeleteExper.Name = "kryptonButtonDeleteExper";
            this.kryptonButtonDeleteExper.Size = new System.Drawing.Size(232, 56);
            this.kryptonButtonDeleteExper.TabIndex = 0;
            this.kryptonButtonDeleteExper.Values.Text = "删除实验";
            this.kryptonButtonDeleteExper.Click += new System.EventHandler(this.kryptonButtonDeleteExper_Click);
            // 
            // kryptonLabelEno
            // 
            this.kryptonLabelEno.Location = new System.Drawing.Point(83, 69);
            this.kryptonLabelEno.Name = "kryptonLabelEno";
            this.kryptonLabelEno.Size = new System.Drawing.Size(60, 24);
            this.kryptonLabelEno.TabIndex = 1;
            this.kryptonLabelEno.Values.Text = "实验号";
            // 
            // kryptonLabelEname
            // 
            this.kryptonLabelEname.Location = new System.Drawing.Point(83, 134);
            this.kryptonLabelEname.Name = "kryptonLabelEname";
            this.kryptonLabelEname.Size = new System.Drawing.Size(60, 24);
            this.kryptonLabelEname.TabIndex = 2;
            this.kryptonLabelEname.Values.Text = "实验名";
            // 
            // kryptonTextBoxEno
            // 
            this.kryptonTextBoxEno.Location = new System.Drawing.Point(149, 66);
            this.kryptonTextBoxEno.Name = "kryptonTextBoxEno";
            this.kryptonTextBoxEno.Size = new System.Drawing.Size(223, 27);
            this.kryptonTextBoxEno.TabIndex = 3;
            // 
            // kryptonTextBoxEname
            // 
            this.kryptonTextBoxEname.Location = new System.Drawing.Point(149, 131);
            this.kryptonTextBoxEname.Name = "kryptonTextBoxEname";
            this.kryptonTextBoxEname.Size = new System.Drawing.Size(223, 27);
            this.kryptonTextBoxEname.TabIndex = 4;
            // 
            // kryptonLabelAns
            // 
            this.kryptonLabelAns.Location = new System.Drawing.Point(83, 313);
            this.kryptonLabelAns.Name = "kryptonLabelAns";
            this.kryptonLabelAns.Size = new System.Drawing.Size(6, 2);
            this.kryptonLabelAns.TabIndex = 5;
            this.kryptonLabelAns.Values.Text = "";
            // 
            // FrmDeleteExper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 441);
            this.Controls.Add(this.kryptonPanel);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmDeleteExper";
            this.Text = "FrmDeleteExper";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelAns;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEname;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEno;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEname;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEno;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonDeleteExper;
    }
}

