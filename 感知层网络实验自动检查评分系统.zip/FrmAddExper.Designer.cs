﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmAddExper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonLabelAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonButtonAddExper = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonTextBoxEansbetter = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEansPass = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEcode = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEname = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxEno = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelEansBetter = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEansPass = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEcode = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEname = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabelEno = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.kryptonLabelAns);
            this.kryptonPanel.Controls.Add(this.kryptonButtonAddExper);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEansbetter);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEansPass);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEcode);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEname);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxEno);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEansBetter);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEansPass);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEcode);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEname);
            this.kryptonPanel.Controls.Add(this.kryptonLabelEno);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(679, 474);
            this.kryptonPanel.TabIndex = 0;
            // 
            // kryptonLabelAns
            // 
            this.kryptonLabelAns.Location = new System.Drawing.Point(57, 399);
            this.kryptonLabelAns.Name = "kryptonLabelAns";
            this.kryptonLabelAns.Size = new System.Drawing.Size(6, 2);
            this.kryptonLabelAns.TabIndex = 11;
            this.kryptonLabelAns.Values.Text = "";
            // 
            // kryptonButtonAddExper
            // 
            this.kryptonButtonAddExper.Location = new System.Drawing.Point(57, 307);
            this.kryptonButtonAddExper.Name = "kryptonButtonAddExper";
            this.kryptonButtonAddExper.Size = new System.Drawing.Size(292, 65);
            this.kryptonButtonAddExper.TabIndex = 10;
            this.kryptonButtonAddExper.Values.Text = "添加实验";
            this.kryptonButtonAddExper.Click += new System.EventHandler(this.kryptonButtonAddExper_Click);
            // 
            // kryptonTextBoxEansbetter
            // 
            this.kryptonTextBoxEansbetter.Location = new System.Drawing.Point(172, 247);
            this.kryptonTextBoxEansbetter.Name = "kryptonTextBoxEansbetter";
            this.kryptonTextBoxEansbetter.Size = new System.Drawing.Size(407, 27);
            this.kryptonTextBoxEansbetter.TabIndex = 9;
            // 
            // kryptonTextBoxEansPass
            // 
            this.kryptonTextBoxEansPass.Location = new System.Drawing.Point(172, 197);
            this.kryptonTextBoxEansPass.Name = "kryptonTextBoxEansPass";
            this.kryptonTextBoxEansPass.Size = new System.Drawing.Size(407, 27);
            this.kryptonTextBoxEansPass.TabIndex = 8;
            // 
            // kryptonTextBoxEcode
            // 
            this.kryptonTextBoxEcode.Location = new System.Drawing.Point(172, 147);
            this.kryptonTextBoxEcode.Name = "kryptonTextBoxEcode";
            this.kryptonTextBoxEcode.Size = new System.Drawing.Size(407, 27);
            this.kryptonTextBoxEcode.TabIndex = 7;
            // 
            // kryptonTextBoxEname
            // 
            this.kryptonTextBoxEname.Location = new System.Drawing.Point(172, 97);
            this.kryptonTextBoxEname.Name = "kryptonTextBoxEname";
            this.kryptonTextBoxEname.Size = new System.Drawing.Size(407, 27);
            this.kryptonTextBoxEname.TabIndex = 6;
            // 
            // kryptonTextBoxEno
            // 
            this.kryptonTextBoxEno.Location = new System.Drawing.Point(172, 47);
            this.kryptonTextBoxEno.Name = "kryptonTextBoxEno";
            this.kryptonTextBoxEno.Size = new System.Drawing.Size(407, 27);
            this.kryptonTextBoxEno.TabIndex = 5;
            // 
            // kryptonLabelEansBetter
            // 
            this.kryptonLabelEansBetter.Location = new System.Drawing.Point(57, 250);
            this.kryptonLabelEansBetter.Name = "kryptonLabelEansBetter";
            this.kryptonLabelEansBetter.Size = new System.Drawing.Size(76, 24);
            this.kryptonLabelEansBetter.TabIndex = 4;
            this.kryptonLabelEansBetter.Values.Text = "优秀结果";
            // 
            // kryptonLabelEansPass
            // 
            this.kryptonLabelEansPass.Location = new System.Drawing.Point(57, 200);
            this.kryptonLabelEansPass.Name = "kryptonLabelEansPass";
            this.kryptonLabelEansPass.Size = new System.Drawing.Size(76, 24);
            this.kryptonLabelEansPass.TabIndex = 3;
            this.kryptonLabelEansPass.Values.Text = "通过结果";
            // 
            // kryptonLabelEcode
            // 
            this.kryptonLabelEcode.Location = new System.Drawing.Point(57, 150);
            this.kryptonLabelEcode.Name = "kryptonLabelEcode";
            this.kryptonLabelEcode.Size = new System.Drawing.Size(78, 24);
            this.kryptonLabelEcode.TabIndex = 2;
            this.kryptonLabelEcode.Values.Text = "编        码";
            // 
            // kryptonLabelEname
            // 
            this.kryptonLabelEname.Location = new System.Drawing.Point(57, 100);
            this.kryptonLabelEname.Name = "kryptonLabelEname";
            this.kryptonLabelEname.Size = new System.Drawing.Size(77, 24);
            this.kryptonLabelEname.TabIndex = 1;
            this.kryptonLabelEname.Values.Text = "实  验  名";
            // 
            // kryptonLabelEno
            // 
            this.kryptonLabelEno.Location = new System.Drawing.Point(57, 50);
            this.kryptonLabelEno.Name = "kryptonLabelEno";
            this.kryptonLabelEno.Size = new System.Drawing.Size(77, 24);
            this.kryptonLabelEno.TabIndex = 0;
            this.kryptonLabelEno.Values.Text = "实  验  号";
            // 
            // FrmAddExper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 474);
            this.Controls.Add(this.kryptonPanel);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmAddExper";
            this.Text = "FrmAddExper";
            this.Load += new System.EventHandler(this.FrmAddExper_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonAddExper;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEansbetter;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEansPass;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEcode;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEname;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxEno;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEansBetter;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEansPass;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEcode;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEname;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelEno;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelAns;
    }
}

