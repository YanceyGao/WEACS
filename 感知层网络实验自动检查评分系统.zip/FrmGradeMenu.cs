﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmGradeMenu : DockContent
    {
        private const int GRADEKEY = 0;
        DataTable dataTable;

        public FrmGradeMenu()
        {
            InitializeComponent();
        }

        private void FrmGradeMenu_Load(object sender, EventArgs e)
        {
            UserInfoWebService.UserInfoWebServiceSoapClient userInfoWebServiceSoapClient = new UserInfoWebService.UserInfoWebServiceSoapClient();
            dataTable = userInfoWebServiceSoapClient.getMenuData(GRADEKEY);
            BindRoot();
        }

        //获取根节点
        private void BindRoot()
        {
            //从表中查出parentId为空的行
            DataRow[] ro = dataTable.Select("parent_id = ''");
            foreach (DataRow dr in ro)
            {
                TreeNode node = new TreeNode();
                node.Tag = dr;
                node.Text = dr["mu_name"].ToString();
                node.ImageIndex = 0;
                node.SelectedImageIndex = 1;
                TreeView.Nodes.Add(node);
                AddChild(node);
            }
        }

        //绑定子节点
        private void AddChild(TreeNode root)
        {
            DataRow dr = (DataRow)root.Tag;     //获取与根节点关联的行
            string pId = dr["mu_id"].ToString();    //获取根节点的mu_id

            //从表中查询出parent_id=mu_id的节点
            DataRow[] rows = dataTable.Select("parent_id = '" + pId + "'");
            if (rows.Length == 0)
            {
                root.ImageIndex = 4;
                root.SelectedImageIndex = 5;
                root.ToolTipText = dr["tv_file"].ToString();    //绑定文件名
                root.Name = dr["tv_folder"].ToString();         //绑定目录名
                return;
            }

            foreach (DataRow drow in rows)       //遍历添加子节点
            {
                TreeNode node = new TreeNode();
                node.Tag = drow;
                node.Text = drow["mu_name"].ToString();
                node.ImageIndex = 2;
                node.SelectedImageIndex = 3;
                root.Nodes.Add(node);
                AddChild(node);
            }

        }

        private void TreeView_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            string fileName = TreeView.SelectedNode.ToolTipText;        //取出文件key

            FrmGradeInfo frm = new FrmGradeInfo();
            string name = frm.Name;
            FrmGradeInfo.classNumber = fileName;  //加载文件key
            FrmMain main = (FrmMain)this.Parent.Parent.Parent.Parent;   //获取当前窗体的父窗体

            //foreach (DockContent item in DockPanel.Contents)
            //{
            //    if (item.Name == name)
            //    {
            //        item.Close();
            //        break;
            //    }
            //}

            frm.MdiParent = main;           //设置子窗体的父窗体
            frm.DockHandler.Show(DockPanel);         //打开子窗体
        }

    }
}