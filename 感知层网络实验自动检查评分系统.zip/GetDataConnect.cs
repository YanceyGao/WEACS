﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 感知层网络实验自动检查评分系统
{
    class GetDataConnect
    {

    }
}
