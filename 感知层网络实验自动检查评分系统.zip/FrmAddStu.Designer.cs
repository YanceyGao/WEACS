﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmAddStu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonLabelSno = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxSno = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBoxSna = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelSna = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxSage = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelSage = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxScla = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelScla = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxSdept = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelSdept = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxSsex = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelSsex = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonTextBoxScol = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabelScol = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonButtonAddStu = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonLabelAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.kryptonLabelAns);
            this.kryptonPanel.Controls.Add(this.kryptonButtonAddStu);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxScol);
            this.kryptonPanel.Controls.Add(this.kryptonLabelScol);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxSsex);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSsex);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxSdept);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSdept);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxScla);
            this.kryptonPanel.Controls.Add(this.kryptonLabelScla);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxSage);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSage);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxSna);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSna);
            this.kryptonPanel.Controls.Add(this.kryptonTextBoxSno);
            this.kryptonPanel.Controls.Add(this.kryptonLabelSno);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(584, 438);
            this.kryptonPanel.TabIndex = 0;
            // 
            // kryptonLabelSno
            // 
            this.kryptonLabelSno.Location = new System.Drawing.Point(55, 47);
            this.kryptonLabelSno.Name = "kryptonLabelSno";
            this.kryptonLabelSno.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelSno.TabIndex = 0;
            this.kryptonLabelSno.Values.Text = "学号";
            // 
            // kryptonTextBoxSno
            // 
            this.kryptonTextBoxSno.Location = new System.Drawing.Point(105, 44);
            this.kryptonTextBoxSno.Name = "kryptonTextBoxSno";
            this.kryptonTextBoxSno.Size = new System.Drawing.Size(164, 27);
            this.kryptonTextBoxSno.TabIndex = 1;
            // 
            // kryptonTextBoxSna
            // 
            this.kryptonTextBoxSna.Location = new System.Drawing.Point(105, 77);
            this.kryptonTextBoxSna.Name = "kryptonTextBoxSna";
            this.kryptonTextBoxSna.Size = new System.Drawing.Size(164, 27);
            this.kryptonTextBoxSna.TabIndex = 3;
            // 
            // kryptonLabelSna
            // 
            this.kryptonLabelSna.Location = new System.Drawing.Point(55, 80);
            this.kryptonLabelSna.Name = "kryptonLabelSna";
            this.kryptonLabelSna.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelSna.TabIndex = 2;
            this.kryptonLabelSna.Values.Text = "姓名";
            // 
            // kryptonTextBoxSage
            // 
            this.kryptonTextBoxSage.Location = new System.Drawing.Point(105, 143);
            this.kryptonTextBoxSage.Name = "kryptonTextBoxSage";
            this.kryptonTextBoxSage.Size = new System.Drawing.Size(164, 27);
            this.kryptonTextBoxSage.TabIndex = 5;
            // 
            // kryptonLabelSage
            // 
            this.kryptonLabelSage.Location = new System.Drawing.Point(55, 146);
            this.kryptonLabelSage.Name = "kryptonLabelSage";
            this.kryptonLabelSage.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelSage.TabIndex = 4;
            this.kryptonLabelSage.Values.Text = "年龄";
            // 
            // kryptonTextBoxScla
            // 
            this.kryptonTextBoxScla.Location = new System.Drawing.Point(105, 110);
            this.kryptonTextBoxScla.Name = "kryptonTextBoxScla";
            this.kryptonTextBoxScla.Size = new System.Drawing.Size(164, 27);
            this.kryptonTextBoxScla.TabIndex = 7;
            // 
            // kryptonLabelScla
            // 
            this.kryptonLabelScla.Location = new System.Drawing.Point(55, 113);
            this.kryptonLabelScla.Name = "kryptonLabelScla";
            this.kryptonLabelScla.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelScla.TabIndex = 6;
            this.kryptonLabelScla.Values.Text = "班级";
            // 
            // kryptonTextBoxSdept
            // 
            this.kryptonTextBoxSdept.Location = new System.Drawing.Point(105, 209);
            this.kryptonTextBoxSdept.Name = "kryptonTextBoxSdept";
            this.kryptonTextBoxSdept.Size = new System.Drawing.Size(164, 27);
            this.kryptonTextBoxSdept.TabIndex = 9;
            // 
            // kryptonLabelSdept
            // 
            this.kryptonLabelSdept.Location = new System.Drawing.Point(55, 212);
            this.kryptonLabelSdept.Name = "kryptonLabelSdept";
            this.kryptonLabelSdept.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelSdept.TabIndex = 8;
            this.kryptonLabelSdept.Values.Text = "专业";
            // 
            // kryptonTextBoxSsex
            // 
            this.kryptonTextBoxSsex.Location = new System.Drawing.Point(105, 176);
            this.kryptonTextBoxSsex.Name = "kryptonTextBoxSsex";
            this.kryptonTextBoxSsex.Size = new System.Drawing.Size(164, 27);
            this.kryptonTextBoxSsex.TabIndex = 11;
            // 
            // kryptonLabelSsex
            // 
            this.kryptonLabelSsex.Location = new System.Drawing.Point(55, 179);
            this.kryptonLabelSsex.Name = "kryptonLabelSsex";
            this.kryptonLabelSsex.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelSsex.TabIndex = 10;
            this.kryptonLabelSsex.Values.Text = "性别";
            // 
            // kryptonTextBoxScol
            // 
            this.kryptonTextBoxScol.Location = new System.Drawing.Point(105, 242);
            this.kryptonTextBoxScol.Name = "kryptonTextBoxScol";
            this.kryptonTextBoxScol.Size = new System.Drawing.Size(164, 27);
            this.kryptonTextBoxScol.TabIndex = 13;
            // 
            // kryptonLabelScol
            // 
            this.kryptonLabelScol.Location = new System.Drawing.Point(55, 245);
            this.kryptonLabelScol.Name = "kryptonLabelScol";
            this.kryptonLabelScol.Size = new System.Drawing.Size(44, 24);
            this.kryptonLabelScol.TabIndex = 12;
            this.kryptonLabelScol.Values.Text = "学院";
            // 
            // kryptonButtonAddStu
            // 
            this.kryptonButtonAddStu.Location = new System.Drawing.Point(55, 300);
            this.kryptonButtonAddStu.Name = "kryptonButtonAddStu";
            this.kryptonButtonAddStu.Size = new System.Drawing.Size(214, 52);
            this.kryptonButtonAddStu.TabIndex = 14;
            this.kryptonButtonAddStu.Values.Text = "添加学生";
            this.kryptonButtonAddStu.Click += new System.EventHandler(this.kryptonButtonAddStu_Click);
            // 
            // kryptonLabelAns
            // 
            this.kryptonLabelAns.Location = new System.Drawing.Point(55, 380);
            this.kryptonLabelAns.Name = "kryptonLabelAns";
            this.kryptonLabelAns.Size = new System.Drawing.Size(6, 2);
            this.kryptonLabelAns.TabIndex = 15;
            this.kryptonLabelAns.Values.Text = "";
            // 
            // FrmAddStu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 438);
            this.Controls.Add(this.kryptonPanel);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmAddStu";
            this.Text = "FrmAddStu";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelAns;
        private ComponentFactory.Krypton.Toolkit.KryptonButton kryptonButtonAddStu;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxScol;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelScol;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSsex;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSsex;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSdept;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSdept;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxScla;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelScla;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSage;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSage;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSna;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSna;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBoxSno;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabelSno;
    }
}

