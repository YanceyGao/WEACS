﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using 感知层网络实验自动检查评分系统.ExperInfoWebService;
using WeifenLuo.WinFormsUI.Docking;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmSearchExper : DockContent
    {
        public FrmSearchExper()
        {
            InitializeComponent();
        }

        private void kryptonButtonSearch_Click(object sender, EventArgs e)
        {
            String key = kryptonComboBoxSearch.Text;
            String val = kryptonTextBoxEnoorEname.Text;
            ExperInfoWebServiceSoapClient experInfoWebServiceSoapClient = new ExperInfoWebServiceSoapClient();

            DataTable dataTable;
            if (key.Equals("实验号查询"))
            {
                dataTable = experInfoWebServiceSoapClient.SelectExper(val, 1);
            }
            else if(key.Equals("实验名查询"))
            {
                dataTable = experInfoWebServiceSoapClient.SelectExper(val, 0);
            }
            else
            {
                dataTable = null;
            }

            if (dataTable == null)
            {
                MessageBox.Show("输入错误", "Error", MessageBoxButtons.OK);
                return;
            }

            if (dataTable.Rows.Count == 0)
            {
                MessageBox.Show("该实验不存在，请检查输入是否正确", "Warning", MessageBoxButtons.OK);
                return;
            }

            FrmSearchExperAns frm = new FrmSearchExperAns();
            FrmSearchExperAns.val = dataTable;

            FrmMain main = (FrmMain)this.Parent.Parent;   //获取当前窗体的父窗体
            frm.MdiParent = main;           //设置子窗体的父窗体
            frm.DockHandler.Show(DockPanel);         //打开子窗体
        }
    }
}