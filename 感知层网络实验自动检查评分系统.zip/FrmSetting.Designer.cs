﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSetting));
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.BtnSave = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.BtnTestUrl = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.kryptonTextBox4 = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBox3 = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBox2 = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonTextBox1 = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.LabTxtUrl = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LabTxtPwd = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LabTxtUser = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LabTxtDbName = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbTxtSetting = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.TxtBoxSQLAddress = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.LabTxtSqlAddress = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.BtnSave);
            this.kryptonPanel.Controls.Add(this.BtnTestUrl);
            this.kryptonPanel.Controls.Add(this.kryptonTextBox4);
            this.kryptonPanel.Controls.Add(this.kryptonTextBox3);
            this.kryptonPanel.Controls.Add(this.kryptonTextBox2);
            this.kryptonPanel.Controls.Add(this.kryptonTextBox1);
            this.kryptonPanel.Controls.Add(this.LabTxtUrl);
            this.kryptonPanel.Controls.Add(this.LabTxtPwd);
            this.kryptonPanel.Controls.Add(this.LabTxtUser);
            this.kryptonPanel.Controls.Add(this.LabTxtDbName);
            this.kryptonPanel.Controls.Add(this.LbTxtSetting);
            this.kryptonPanel.Controls.Add(this.TxtBoxSQLAddress);
            this.kryptonPanel.Controls.Add(this.LabTxtSqlAddress);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(281, 317);
            this.kryptonPanel.TabIndex = 0;
            // 
            // BtnSave
            // 
            this.BtnSave.Location = new System.Drawing.Point(166, 262);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(103, 43);
            this.BtnSave.TabIndex = 48;
            this.BtnSave.Values.Text = "保存修改";
            // 
            // BtnTestUrl
            // 
            this.BtnTestUrl.Location = new System.Drawing.Point(12, 262);
            this.BtnTestUrl.Name = "BtnTestUrl";
            this.BtnTestUrl.Size = new System.Drawing.Size(105, 43);
            this.BtnTestUrl.TabIndex = 47;
            this.BtnTestUrl.Values.Text = "测试链接";
            // 
            // kryptonTextBox4
            // 
            this.kryptonTextBox4.Location = new System.Drawing.Point(94, 211);
            this.kryptonTextBox4.Name = "kryptonTextBox4";
            this.kryptonTextBox4.Size = new System.Drawing.Size(175, 27);
            this.kryptonTextBox4.TabIndex = 46;
            // 
            // kryptonTextBox3
            // 
            this.kryptonTextBox3.Location = new System.Drawing.Point(94, 178);
            this.kryptonTextBox3.Name = "kryptonTextBox3";
            this.kryptonTextBox3.Size = new System.Drawing.Size(175, 27);
            this.kryptonTextBox3.TabIndex = 45;
            // 
            // kryptonTextBox2
            // 
            this.kryptonTextBox2.Location = new System.Drawing.Point(94, 145);
            this.kryptonTextBox2.Name = "kryptonTextBox2";
            this.kryptonTextBox2.Size = new System.Drawing.Size(175, 27);
            this.kryptonTextBox2.TabIndex = 44;
            // 
            // kryptonTextBox1
            // 
            this.kryptonTextBox1.Location = new System.Drawing.Point(94, 112);
            this.kryptonTextBox1.Name = "kryptonTextBox1";
            this.kryptonTextBox1.Size = new System.Drawing.Size(175, 27);
            this.kryptonTextBox1.TabIndex = 43;
            // 
            // LabTxtUrl
            // 
            this.LabTxtUrl.Location = new System.Drawing.Point(12, 211);
            this.LabTxtUrl.Name = "LabTxtUrl";
            this.LabTxtUrl.Size = new System.Drawing.Size(76, 24);
            this.LabTxtUrl.TabIndex = 42;
            this.LabTxtUrl.Values.Text = "验证网址";
            // 
            // LabTxtPwd
            // 
            this.LabTxtPwd.Location = new System.Drawing.Point(12, 181);
            this.LabTxtPwd.Name = "LabTxtPwd";
            this.LabTxtPwd.Size = new System.Drawing.Size(78, 24);
            this.LabTxtPwd.TabIndex = 41;
            this.LabTxtPwd.Values.Text = "密        码";
            // 
            // LabTxtUser
            // 
            this.LabTxtUser.Location = new System.Drawing.Point(12, 148);
            this.LabTxtUser.Name = "LabTxtUser";
            this.LabTxtUser.Size = new System.Drawing.Size(77, 24);
            this.LabTxtUser.TabIndex = 40;
            this.LabTxtUser.Values.Text = "登  录  名";
            // 
            // LabTxtDbName
            // 
            this.LabTxtDbName.Location = new System.Drawing.Point(12, 109);
            this.LabTxtDbName.Name = "LabTxtDbName";
            this.LabTxtDbName.Size = new System.Drawing.Size(76, 24);
            this.LabTxtDbName.TabIndex = 39;
            this.LabTxtDbName.Values.Text = "数据库名";
            // 
            // LbTxtSetting
            // 
            this.LbTxtSetting.LabelStyle = ComponentFactory.Krypton.Toolkit.LabelStyle.TitleControl;
            this.LbTxtSetting.Location = new System.Drawing.Point(94, 24);
            this.LbTxtSetting.Name = "LbTxtSetting";
            this.LbTxtSetting.Size = new System.Drawing.Size(63, 35);
            this.LbTxtSetting.TabIndex = 38;
            this.LbTxtSetting.Values.Text = "设置";
            // 
            // TxtBoxSQLAddress
            // 
            this.TxtBoxSQLAddress.Location = new System.Drawing.Point(94, 79);
            this.TxtBoxSQLAddress.Name = "TxtBoxSQLAddress";
            this.TxtBoxSQLAddress.Size = new System.Drawing.Size(175, 27);
            this.TxtBoxSQLAddress.TabIndex = 1;
            // 
            // LabTxtSqlAddress
            // 
            this.LabTxtSqlAddress.Location = new System.Drawing.Point(12, 79);
            this.LabTxtSqlAddress.Name = "LabTxtSqlAddress";
            this.LabTxtSqlAddress.Size = new System.Drawing.Size(71, 24);
            this.LabTxtSqlAddress.TabIndex = 0;
            this.LabTxtSqlAddress.Values.Text = "SQL地址";
            // 
            // FrmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 317);
            this.Controls.Add(this.kryptonPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "连接设置";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtBoxSQLAddress;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LabTxtSqlAddress;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbTxtSetting;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LabTxtUrl;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LabTxtPwd;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LabTxtUser;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LabTxtDbName;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnSave;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtnTestUrl;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox4;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox3;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox2;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox kryptonTextBox1;
    }
}

