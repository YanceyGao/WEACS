﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Windows.Documents;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;
using 感知层网络实验自动检查评分系统.ExperInfoWebService;
using 感知层网络实验自动检查评分系统.UserInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmExperiment : DockContent
    {
        private const int BUFFERSIZE = 14;
        //外部调用实验项
        public static int key;
        //静态数据源变量
        private static DataHelper dataHelper = new DataHelper();
        private static DataTable dataTable = dataHelper.CreateTable();

        //显式类型
        public static String code;
        public static String experNumber;
        public static DataTable val;

        //要删除的行
        public static int lineNumber = -1;

        //实验状态
        public static Boolean Experstatus = false;

        public FrmExperiment()
        {
            InitializeComponent();
        }

        private void FrmExperiment_Load(object sender, EventArgs e)
        {
            ExperInfoWebServiceSoapClient experInfoWebService = new ExperInfoWebServiceSoapClient();
            val = experInfoWebService.getExperInfo(experNumber);

            UserInfoWebServiceSoapClient userInfoWebServiceSoapClient = new UserInfoWebServiceSoapClient();
            DataTable classSelect = userInfoWebServiceSoapClient.getMenuData(0);

            //自动填入班级选择
            List<String> ts = getDataFromDatatable(classSelect);
            kryptonComboBoxClass.DataSource = ts;
            
            kryptonTextBoxName.Text = val.Rows[0][1].ToString();
            kryptonTextBoxCode.Text = val.Rows[0][2].ToString();
            kryptonTextBoxPassAns.Text = val.Rows[0][3].ToString();
            kryptonTextBoxBetterAns.Text = val.Rows[0][4].ToString();

            code = val.Rows[0][2].ToString();

            listView.Clear();
            listView.AllowColumnReorder = true;   //用户可以调整列的位置
            listView.GridLines = true;            //显示行与行之间的分隔线   
            listView.FullRowSelect = true;        //要选择就是一行   
            listView.View = View.Details;         //定义列表显示的方式  
            listView.Scrollable = true;           //需要时候显示滚动条  
            listView.MultiSelect = false;         // 不可以多行选择   
            listView.HeaderStyle = ColumnHeaderStyle.Clickable;
            listView.View = View.Details;
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                listView.Columns.Add(dataTable.Columns[i].Caption.Trim(), listView.Width / dataTable.Columns.Count);
            }

            kryptonComboPort.Text = "COM1";
            kryptonComboBaud.Text = "115200";
            kryptonComboData.Text = "8";
            kryptonComboCheck.Text = "None";
            kryptonComboStop.Text = "1";

            kryptonComboPort.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames());
            SearchPort(serialPort, kryptonComboPort);

            kryptonButtonEnd.Enabled = false;
        }

        //解析dataTable数据
        private List<String> getDataFromDatatable(DataTable dataTable)
        {
            List<String> list = new List<string>();

            foreach(DataRow dr in dataTable.Rows)
            {
                list.Add(dr["mu_id"].ToString());
            }

            return list;
        }

        private void kryptonButtonStart_Click(object sender, EventArgs e)
        {
            try
            {
                //将可能产生异常的代码放置在try块中
                //根据当前串口属性来判断是否打开
                if (!serialPort.IsOpen)
                {
                    //串口已经处于关闭状态，则设置好串口属性后打开
                    kryptonComboBoxClass.Enabled = false;
                    kryptonTextBoxName.Enabled = false;
                    kryptonTextBoxCode.Enabled = false;
                    kryptonTextBoxPassAns.Enabled = false;
                    kryptonTextBoxBetterAns.Enabled = false;

                    kryptonComboPort.Enabled = false;
                    kryptonComboBaud.Enabled = false;
                    kryptonComboData.Enabled = false;
                    kryptonComboCheck.Enabled = false;
                    kryptonComboStop.Enabled = false;

                    serialPort.PortName = kryptonComboPort.Text;
                    serialPort.BaudRate = Convert.ToInt32(kryptonComboBaud.Text);
                    serialPort.DataBits = Convert.ToInt16(kryptonComboData.Text);

                    if (kryptonComboCheck.Text.Equals("None"))
                        serialPort.Parity = System.IO.Ports.Parity.None;
                    else if (kryptonComboCheck.Text.Equals("Odd"))
                        serialPort.Parity = System.IO.Ports.Parity.Odd;
                    else if (kryptonComboCheck.Text.Equals("Even"))
                        serialPort.Parity = System.IO.Ports.Parity.Even;
                    else if (kryptonComboCheck.Text.Equals("Mark"))
                        serialPort.Parity = System.IO.Ports.Parity.Mark;
                    else if (kryptonComboCheck.Text.Equals("Space"))
                        serialPort.Parity = System.IO.Ports.Parity.Space;

                    if (kryptonComboStop.Text.Equals("1"))
                        serialPort.StopBits = System.IO.Ports.StopBits.One;
                    else if (kryptonComboStop.Text.Equals("1.5"))
                        serialPort.StopBits = System.IO.Ports.StopBits.OnePointFive;
                    else if (kryptonComboStop.Text.Equals("2"))
                        serialPort.StopBits = System.IO.Ports.StopBits.Two;

                    serialPort.Open();

                    Experstatus = true;
                    kryptonButtonStart.Enabled = false;
                    kryptonButtonEnd.Enabled = true;
                }
            }
            catch(Exception ex)
            {
                //捕获可能发生的异常并进行处理

                //捕获到异常，创建一个新的对象，之前的不可以再用
                serialPort = new System.IO.Ports.SerialPort();
                //刷新COM口选项
                kryptonComboPort.Items.Clear();
                kryptonComboPort.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames());

                //响铃并显示异常给用户
                System.Media.SystemSounds.Beep.Play();
                kryptonButtonStart.Enabled = true;
                kryptonButtonEnd.Enabled = true;
                MessageBox.Show(ex.Message);
                kryptonComboPort.Enabled = true;
                kryptonComboBaud.Enabled = true;
                kryptonComboData.Enabled = true;
                kryptonComboCheck.Enabled = true;
                kryptonComboStop.Enabled = true;
            }
        }

        private void kryptonButtonEnd_Click(object sender, EventArgs e)
        {
            try
            {
                //如果串口打开，就关闭更新，没有打开，只更新
                if (serialPort.IsOpen)
                {
                    serialPort.Close(); 
                }

                dataHelper.finishExper(dataTable, experNumber);

                ExperViewUpdate();
            }
            catch (Exception ex)
            {
                //捕获可能发生的异常并进行处理

                //捕获到异常，创建一个新的对象，之前的不可以再用
                serialPort = new System.IO.Ports.SerialPort();
                //刷新COM口选项
                kryptonComboPort.Items.Clear();
                kryptonComboPort.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames());

                //响铃并显示异常给用户
                System.Media.SystemSounds.Beep.Play();
                kryptonButtonStart.Enabled = true;
                kryptonButtonEnd.Enabled = false;
                MessageBox.Show(ex.Message);
                kryptonComboPort.Enabled = true;
                kryptonComboBaud.Enabled = true;
                kryptonComboData.Enabled = true;
                kryptonComboCheck.Enabled = true;
                kryptonComboStop.Enabled = true;
            }

        }
        //全屏按钮暂时未实现
        private void buttonSpecHeaderGroupMaxScreen_Click(object sender, EventArgs e)
        {
            this.Height = Screen.PrimaryScreen.WorkingArea.Height;
            this.Width = Screen.PrimaryScreen.WorkingArea.Width;
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {   
                if (!Experstatus)
                {
                    Experstatus = true;
                    return;
                }

                //读取延时，防止获取数据缺失
                //System.Threading.Thread.Sleep(100);

                //因为要访问UI资源，所以需要使用invoke方式同步ui
                this.Invoke((EventHandler)(delegate
                {
                    byte[] buf = new byte[BUFFERSIZE];
                    serialPort.Read(buf, 0, BUFFERSIZE);

                    String recData = dataHelper.ByteToHexStr(buf);

                    //String recData = serialPort.ReadExisting().ToString();

                    DataRow dataRow = dataHelper.DataAnalysis(dataTable, recData, kryptonTextBoxCode.Text, kryptonComboBoxClass.Text, kryptonTextBoxPassAns.Text, kryptonTextBoxBetterAns.Text);

                    if(dataRow == null)
                    {
                        return;
                    }

                    if(lineNumber != -1)
                    {
                        listView.Items.Remove(listView.Items[lineNumber + 1]);
                        lineNumber = -1;
                    }

                    listView.Items.Clear();
                    dataHelper.listViewAddItems(dataTable, listView);

                    //listView.Items.Add(new ListViewItem(dataRow["Line"].ToString())
                    //{
                    //    SubItems = { dataRow["Sno"].ToString(),
                    //               dataRow["Sname"].ToString(),
                    //               dataRow["passGrade"].ToString(),
                    //               dataRow["hardGrade"].ToString(),
                    //               dataRow["Sgrade"].ToString()
                    //}
                    //});

                    if (Experstatus)
                        labelShow.Text = dataRow["Line"].ToString() + " " + dataRow["Sno"].ToString()
                                    + " " + dataRow["Sname"].ToString() + " " + dataRow["passGrade"].ToString()
                                    + " " + dataRow["hardGrade"].ToString() + " " + dataRow["Sgrade"].ToString();

                })
                );
            }
            catch(Exception ex)
            {
                //响铃并显示异常给用户
                System.Media.SystemSounds.Beep.Play();
                MessageBox.Show(ex.Message);
            }
        }

        private void SearchPort(SerialPort MyPort, KryptonComboBox MyBox)
        {
            String Buffer;
            Boolean flag = false;

            for (int i = 1; i < 20; i++)
            {
                try
                {
                    Buffer = "COM" + i.ToString();
                    MyPort.PortName = Buffer;
                    MyPort.Open();
                    MyBox.Text = Buffer;
                    flag = true;
                    MyPort.Close();
                    return;
                }
                catch { }

                if (!flag)
                {
                    MyBox.Text = "";
                }
            }
        }

        //界面更新
        private void ExperViewUpdate()
        {
            kryptonButtonStart.Enabled = true;
            kryptonButtonEnd.Enabled = false;

            Experstatus = false;
            kryptonComboBoxClass.Enabled = true;
            kryptonTextBoxName.Enabled = true;
            kryptonTextBoxCode.Enabled = true;
            kryptonTextBoxPassAns.Enabled = true;
            kryptonTextBoxBetterAns.Enabled = true;

            kryptonComboPort.Enabled = true;
            kryptonComboBaud.Enabled = true;
            kryptonComboData.Enabled = true;
            kryptonComboCheck.Enabled = true;
            kryptonComboStop.Enabled = true;

            labelShow.Text = "----------------";
        }

        private void FrmExperiment_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                MessageBox.Show("实验未结束，不能关闭窗口！");
                e.Cancel = true;
            }

            dataTable.Clear();
        }

        private void kryptonButtonSelect_Click(object sender, EventArgs e)
        {
            SearchPort(serialPort, kryptonComboPort);
        }
    }
}