﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using 感知层网络实验自动检查评分系统.ExperInfoWebService;
using 感知层网络实验自动检查评分系统.GradeWebService;
using 感知层网络实验自动检查评分系统.StuInfoWebService;
using 感知层网络实验自动检查评分系统.UserInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    class DataHelper
    {
        private static int countPass = 0;
        private static int countHard = 0;

        private Boolean judgeProject(String packageHead, String code)
        {

            //判断编码方式
            if (!packageHead.Equals(code))
            {
                return false;
            }

            return true;
        }

        public DataRow DataAnalysis(DataTable ans, String recData, String code, String classNumber, String passAns, String hardAns)
        {
            //判断字符串是否为空
            if (recData == null)
            {
                MessageBox.Show("接收出错", "ERROR");
                FrmExperiment.Experstatus = false;
                return null;
            }

            String packageHead = recData.Substring(0, 6);

            String packageCode = recData.Substring(10, 4);

            String packageData = recData.Substring(22);

            packageData.Replace("\0", "");

            if (!judgeProject(packageHead, code))
                return null;

            DataTable dataTable = isStudent(packageCode, classNumber.Substring(0, 4));

            if(dataTable == null)
                return null;

            String Sno = dataTable.Rows[0][0].ToString();
            DataRow row = IsExist(ans, Sno);
            row["Sno"] = Sno;

            String stuName = dataTable.Rows[0][1].ToString();
            row["Sname"] = stuName;

            int gradePass = 80 - 2 * countPass;
            countPass++;
            int existGradePass = Convert.ToInt32(row["passGrade"].ToString());
            if (existGradePass == 0)
            {
                if (gradePass < 60)
                    row["passGrade"] = 60;
                else
                    row["passGrade"] = gradePass;
            }
            else
            {
                if (gradePass < 60 && existGradePass < gradePass)
                    row["passGrade"] = 60;
                else if(gradePass >= 60 && existGradePass < gradePass)
                    row["passGrade"] = gradePass;
            }

            if((packageData != "" || packageData != null) && packageData.Length == 6)
            {
                int gradeHard = 20 - 2 * countHard;

                if(packageData.Substring(0, 2).Equals("00"))
                {
                    gradeHard = gradeHard / 2;
                }

                countHard++;
                int existGradeHard = Convert.ToInt32(row["hardGrade"].ToString());
                if(existGradeHard == 0)
                {
                    if (gradeHard < 10)
                        row["hardGrade"] = 10;
                    else
                        row["hardGrade"] = gradeHard;
                }
                else
                {
                    if (gradeHard < 10 && existGradeHard < gradeHard)
                        row["hardGrade"] = 10;
                    else if(gradeHard >= 10 && existGradeHard < gradeHard)
                        row["hardGrade"] = gradeHard;
                }
                
            }

            row["Sgrade"] = Convert.ToInt32(row["passGrade"].ToString()) + Convert.ToInt32(row["hardGrade"].ToString());

            return row;
        }

        private DataTable isStudent(String packageCode, String college)
        {
            String temp = packageCode.Replace(" ", "");
            String Sno = college + temp;

            StuInfoWebServiceSoapClient stuInfoWebServiceSoapClient = new StuInfoWebServiceSoapClient();
            DataTable result = stuInfoWebServiceSoapClient.SelectStudent(Sno);

            if(result.Rows.Count > 0)
            {
                return result;
            }
            else
            {
                return null;
            }
        }

        private DataRow IsExist(DataTable dt, String Sno)
        {
            DataRow[] dataRows = dt.Select("Sno='" + Sno + "'");

            if (dt.Select("Sno='" + Sno + "'").Count() > 0)
            {
                Int32 lineNumber = Convert.ToInt32(dataRows[0]["Line"].ToString());
                DataRow dataRow = dt.Rows[lineNumber];           

                return dataRow;
            }
            else
            {
                DataRow dataRow = dt.NewRow();
                dt.Rows.Add(dataRow);
                dataRow["passGrade"] = 0;
                dataRow["hardGrade"] = 0;
                dataRow["Sgrade"] = 0;

                return dataRow;
            }
        }
        //暂时无用
        private Boolean DataCheck(String data, String ans)
        {
            if (data.Equals(ans))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public DataTable CreateTable()
        {
            DataTable dataTable = new DataTable("Grade");

            DataColumn Line = new DataColumn();
            Line.DataType = System.Type.GetType("System.Int32");
            Line.ColumnName = "Line";
            Line.AutoIncrement = true;
            Line.AutoIncrementSeed = 0;
            Line.AutoIncrementStep = 1;
            dataTable.Columns.Add(Line);

            DataColumn Sno = new DataColumn();
            Sno.DataType = System.Type.GetType("System.String");
            Sno.ColumnName = "Sno";
            Sno.AutoIncrement = false;
            dataTable.Columns.Add(Sno);

            DataColumn Sname = new DataColumn();
            Sname.DataType = System.Type.GetType("System.String");
            Sname.ColumnName = "Sname";
            Sname.AutoIncrement = false;
            dataTable.Columns.Add(Sname);

            DataColumn passGrade = new DataColumn();
            passGrade.DataType = System.Type.GetType("System.Int32");
            passGrade.ColumnName = "passGrade";
            passGrade.AutoIncrement = false;
            dataTable.Columns.Add(passGrade);

            DataColumn hardGrade = new DataColumn();
            hardGrade.DataType = System.Type.GetType("System.Int32");
            hardGrade.ColumnName = "hardGrade";
            hardGrade.AutoIncrement = false;
            dataTable.Columns.Add(hardGrade);


            DataColumn Sgrade = new DataColumn();
            Sgrade.DataType = System.Type.GetType("System.Int32");
            Sgrade.ColumnName = "Sgrade";
            Sgrade.AutoIncrement = false;
            dataTable.Columns.Add(Sgrade);

            //创建主键
            DataColumn[] keys = new DataColumn[1];
            keys[0] = Line;
            dataTable.PrimaryKey = keys;

            return dataTable;
        }

        public string ByteToHexStr(byte[] bytes) //函数,字节数组转16进制字符串
        {
            string returnStr = "";
            if (bytes != null)
            {
                for (int i = 0; i < bytes.Length; i++)
                {
                    returnStr += bytes[i].ToString("X2");
                }
            }
            return returnStr;
        }

        public void listViewAddItems(DataTable dataTable, ListView listView)
        {
            int length = dataTable.Rows.Count;

            for (int i = 0; i < length; i++)
            {
                ListViewItem lvi = new ListViewItem(dataTable.Rows[i]["Line"].ToString());  //ListView的第一个Item作为主项需要单独添加

                lvi.SubItems.Add(dataTable.Rows[i]["Sno"].ToString());   //后面添加的Item都为SubItems ，即为子项
                lvi.SubItems.Add(dataTable.Rows[i]["Sname"].ToString());
                lvi.SubItems.Add(dataTable.Rows[i]["passGrade"].ToString());
                lvi.SubItems.Add(dataTable.Rows[i]["hardGrade"].ToString());
                lvi.SubItems.Add(dataTable.Rows[i]["Sgrade"].ToString());

                listView.Items.Add(lvi);//最后进行添加
            }
        }

        public void finishExper(DataTable data, String Eno)
        {
            String Sno;
            String grade;
            int Egrade;
            GradeWebServiceSoapClient gradeWebServiceSoapClient = new GradeWebServiceSoapClient();

            for(int i = 0; i < data.Rows.Count; i++)
            {
                Sno = data.Rows[i][1].ToString();
                grade = data.Rows[i][5].ToString();
                Egrade = Convert.ToInt32(grade);

                String updateAns = gradeWebServiceSoapClient.alterGrade(Sno, Eno, Egrade);

                if(updateAns != null)
                {
                    MessageBox.Show(updateAns, "Warning", MessageBoxButtons.OK);
                }
            }

            ExperInfoWebServiceSoapClient experInfoWebServiceSoapClient = new ExperInfoWebServiceSoapClient();
            String finishAns = experInfoWebServiceSoapClient.finishExper(Eno);

            if (finishAns != null)
            {
                MessageBox.Show(finishAns, "Warning", MessageBoxButtons.OK);
            }
        }

        public String[] homeSysInfo()
        {
            String[] str = {"双击快捷方式 感知层网络实验自动检查系统 打开程序，输入初始用户登录。",
                            "账户：admin 密码：admin",
                            "（注：登录程序通过MAC地址以及IP地址限制登录位置，因此请提前配置好MAC地址和IP地址信息）",
                            "登录成功后进入程序",
                            "程序包括 主页 / 学生管理 / 实验管理 / 成绩管理 / 帮助 工具栏。",
                            "主页工具栏包括主页按钮和关闭按钮。",
                            "点击主页按钮打开主页，主页主要显示系统相关信息。",
                            "点击关闭按钮关闭主页。",
                            "学生工具栏包括以下按钮：",
                            "菜单栏按钮打开班级菜单栏，双击菜单栏里的班级打开班级，查看学生信息。",
                            "查询按钮打开查询页面，可以通过学号或班级查询学生信息。",
                            "关闭按钮关闭菜单栏。",
                            "新建班级按钮进行新建班级操作，通过设置班级号，班长，学习委员等信息创建班级。",
                            "删除班级按钮通过班级号进行班级删除。",
                            "添加学生按钮通过学号，姓名，年龄，专业等信息添加学生。",
                            "删除学生按钮通过学号等信息删除学生。",
                            "起始，上一个，下一个，末尾按钮进行班级页面的选中操作。",
                            "导出按钮导出为xml文件。（当前版本未实现）",
                            "退出按钮关闭当前激活窗口。",
                            "实验工具栏包括以下按钮：",
                            "菜单栏打开实验列表操作。双击列表内实验名进行实验。（提前进行实验信息的配置）",
                            "查询按钮进行实验信息的查询操作，查看实验的完成情况，通过率等信息。",
                            "关闭按钮对实验菜单栏进行关闭。",
                            "起始，上一个，下一个，末尾按钮进行实验页面的选中操作。",
                            "添加实验通过配置实验名，实验号，实验编码等信息进行添加实验操作。",
                            "删除实验通过匹配实验号或实验名进行删除实验操作。",
                            "修改实验通过实验号或实验名检索实验并进行修改操作。",
                            "退出按钮关闭当前激活窗口。",
                            "成绩管理工具栏包括以下按钮：",
                            "菜单栏打开成绩菜单列表，双击班级名查看班级实验成绩。",
                            "查询按钮通过班级和学号进行成绩查询操作。",
                            "关闭按钮进行关闭菜单栏操作。",
                            "起始，上一个，下一个，末尾按钮进行成绩页面的选中操作。",
                            "导出按钮进行将当前页面导出为XML格式文件。（当前版本未实现）",
                            "退出按钮关闭当前激活窗口。",
                            "帮助工具栏查询ReadMe文件。"};

            return str;
        }

    }
}
