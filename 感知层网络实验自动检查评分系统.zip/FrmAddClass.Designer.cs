﻿namespace 感知层网络实验自动检查评分系统
{
    partial class FrmAddClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonPanel = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.TxtLearning = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.TxtMonitor = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.TxtClass = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.LbLearning = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbMonitor = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.LbClass = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.BtInsertClass = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.LbAns = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).BeginInit();
            this.kryptonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonPanel
            // 
            this.kryptonPanel.Controls.Add(this.LbAns);
            this.kryptonPanel.Controls.Add(this.TxtLearning);
            this.kryptonPanel.Controls.Add(this.TxtMonitor);
            this.kryptonPanel.Controls.Add(this.TxtClass);
            this.kryptonPanel.Controls.Add(this.LbLearning);
            this.kryptonPanel.Controls.Add(this.LbMonitor);
            this.kryptonPanel.Controls.Add(this.LbClass);
            this.kryptonPanel.Controls.Add(this.BtInsertClass);
            this.kryptonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.kryptonPanel.Name = "kryptonPanel";
            this.kryptonPanel.Size = new System.Drawing.Size(389, 307);
            this.kryptonPanel.TabIndex = 0;
            // 
            // TxtLearning
            // 
            this.TxtLearning.Location = new System.Drawing.Point(127, 78);
            this.TxtLearning.Name = "TxtLearning";
            this.TxtLearning.Size = new System.Drawing.Size(188, 27);
            this.TxtLearning.TabIndex = 6;
            // 
            // TxtMonitor
            // 
            this.TxtMonitor.Location = new System.Drawing.Point(127, 45);
            this.TxtMonitor.Name = "TxtMonitor";
            this.TxtMonitor.Size = new System.Drawing.Size(188, 27);
            this.TxtMonitor.TabIndex = 5;
            // 
            // TxtClass
            // 
            this.TxtClass.Location = new System.Drawing.Point(127, 12);
            this.TxtClass.Name = "TxtClass";
            this.TxtClass.Size = new System.Drawing.Size(188, 27);
            this.TxtClass.TabIndex = 4;
            // 
            // LbLearning
            // 
            this.LbLearning.Location = new System.Drawing.Point(12, 81);
            this.LbLearning.Name = "LbLearning";
            this.LbLearning.Size = new System.Drawing.Size(76, 24);
            this.LbLearning.TabIndex = 3;
            this.LbLearning.Values.Text = "学习委员";
            // 
            // LbMonitor
            // 
            this.LbMonitor.Location = new System.Drawing.Point(12, 48);
            this.LbMonitor.Name = "LbMonitor";
            this.LbMonitor.Size = new System.Drawing.Size(44, 24);
            this.LbMonitor.TabIndex = 2;
            this.LbMonitor.Values.Text = "班长";
            // 
            // LbClass
            // 
            this.LbClass.Location = new System.Drawing.Point(12, 15);
            this.LbClass.Name = "LbClass";
            this.LbClass.Size = new System.Drawing.Size(60, 24);
            this.LbClass.TabIndex = 1;
            this.LbClass.Values.Text = "班级号";
            // 
            // BtInsertClass
            // 
            this.BtInsertClass.Location = new System.Drawing.Point(12, 141);
            this.BtInsertClass.Name = "BtInsertClass";
            this.BtInsertClass.Size = new System.Drawing.Size(303, 61);
            this.BtInsertClass.TabIndex = 0;
            this.BtInsertClass.Values.Text = "添加";
            this.BtInsertClass.Click += new System.EventHandler(this.BtInsertClass_Click);
            // 
            // LbAns
            // 
            this.LbAns.Location = new System.Drawing.Point(13, 222);
            this.LbAns.Name = "LbAns";
            this.LbAns.Size = new System.Drawing.Size(6, 2);
            this.LbAns.TabIndex = 7;
            this.LbAns.Values.Text = "";
            // 
            // FrmAddClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 307);
            this.Controls.Add(this.kryptonPanel);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmAddClass";
            this.Text = "FrmAddClass";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel)).EndInit();
            this.kryptonPanel.ResumeLayout(false);
            this.kryptonPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtLearning;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtMonitor;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox TxtClass;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbLearning;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbMonitor;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbClass;
        private ComponentFactory.Krypton.Toolkit.KryptonButton BtInsertClass;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel LbAns;
    }
}

