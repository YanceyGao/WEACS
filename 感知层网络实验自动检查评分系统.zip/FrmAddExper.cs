﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using WeifenLuo.WinFormsUI.Docking;
using 感知层网络实验自动检查评分系统.ExperInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmAddExper : DockContent
    {
        public FrmAddExper()
        {
            InitializeComponent();
        }

        private void FrmAddExper_Load(object sender, EventArgs e)
        {
            kryptonTextBoxEcode.Text = "55AA03";
        }

        private void kryptonButtonAddExper_Click(object sender, EventArgs e)
        {
            String Eno = kryptonTextBoxEno.Text.ToString();
            String Ename = kryptonTextBoxEname.Text.ToString();
            String Ecode = kryptonTextBoxEcode.Text.ToString();
            String EansPass = kryptonTextBoxEansPass.Text.ToString();
            String EansBetter = kryptonTextBoxEansbetter.Text.ToString();

            ExperInfoWebServiceSoapClient experInfoWebServiceSoapClient = new ExperInfoWebServiceSoapClient();
            String ans = experInfoWebServiceSoapClient.addExper(Eno, Ename, Ecode, EansPass, EansBetter);

            if(ans == null)
            {
                kryptonLabelAns.Text = "添加成功";
            }
            else
            {
                kryptonLabelAns.Text = ans;
            }

            
        }

    }
}