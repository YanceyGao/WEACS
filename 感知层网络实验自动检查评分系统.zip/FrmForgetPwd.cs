﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ComponentFactory.Krypton.Toolkit;
using 感知层网络实验自动检查评分系统.UserInfoWebService;

namespace 感知层网络实验自动检查评分系统
{
    public partial class FrmForgetPwd : ComponentFactory.Krypton.Toolkit.KryptonForm
    {
        public FrmForgetPwd()
        {
            InitializeComponent();
        }

        private void BtnEnter_Click(object sender, EventArgs e)
        {
            //局域网实现
            UserInfoWebService.UserInfoWebServiceSoapClient userInfoWebSer = new UserInfoWebServiceSoapClient();
            String userId = TxtForgetUser.Text;
            String tip = userInfoWebSer.ForgetPwd(userId);

            if (tip.Equals("-1"))
            {
                TxtForgetUser.Text = "该用户不存在！";
            }
            else if (tip.Equals(""))
            {
                TxtForgetUser.Text = "抱歉，该用户没有提示信息！";
            }
            else
            {
                TxtForgetUser.Text = tip;
                BtnEnter.Enabled = false;
                LbForget.Text = "该用户的提示为：";
            }

            //本地连接方式
            //DBConnect dbCon = new DBConnect();
            //string key = dbCon.ForgetPwd(TxtForgetUser.Text);
            //if(key == "")
            //{
            //    MessageBox.Show("该用户不存在或用户没有提示", "提示");
            //}
            //else
            //{
            //    TxtForgetUser.Text = key;
            //    BtnEnter.Enabled = false;
            //    LbForget.Text = "该用户的提示为";
            //}

        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}